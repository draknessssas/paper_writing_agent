# Skeleton: DTC_survey
- Title: "Direct Torque Control of PWM Inverter-Fed AC Motors—A Survey"; venue: IEEE Transactions on Industrial Electronics, vol. 51, no. 4; year: August 2004 (as printed)
- Type: large review (taxonomy-driven), compact scale. Evidence: a field-classification figure on page one, technique-family sections each with variant subsections and closing feature lists, plus a separate application-axis section; borders on small comparative review because only three families are compared and the comparison is by bullet feature lists, not tables.
- Approximate paragraph count: ~50 true paragraphs (~35 extracted page chunks; five embedded bullet lists); taxonomy figure/table [y] (field-level classification figure; the review's own three-way split has no dedicated figure); comparison tables [n] (the only table is a technical lookup table); explicit RQs or hypotheses [n]; future-work section or paragraph [n] (one untraced outlook sentence at the very end)
- Extraction damage: paragraph breaks collapsed into page chunks; running headers, copyright/download notices and figure captions embedded in body text; all equations dropped leaving bare numbers; table body dropped (caption only); three subsection titles split mid-title so headings read as sentence fragments; numbered sub-items merged into one block; one empty page chunk (figure-only page).

## Section list
(Category labels abstracted to kinds per the hard rules; section numbering as in the paper.)
1. I. Introduction
2. II. Basic concepts — A. Basic principles (mechanism derivation); B. Generic scheme (block diagram, features vs reference method, two-way split by a design choice)
3. III. [Family 1: hysteresis, first flux-path kind] — A. Basic scheme; B. Modified schemes: 1) operating-regime fix, 2) ripple fix, 3) alternative regulated variable
4. IV. [Family 2: hysteresis, second flux-path kind] — A. Basic scheme; B. [Variant bridging to Family 3]
5. V. [Family 3: modulator-based, constant switching frequency] — A. Critical evaluation of Families 1–2; B–E. Four variants split by loop structure and coordinate frame; F. Variant by controller kind (predictive); G. Variant by controller kind (AI-based)
6. VI. [Application axis: by motor type] — A–D. Four motor-type subsections
7. VII. Conclusion
8. References

## Paragraph map
| Section | Para | Function | First-sentence template | What follows the claim | Citation pattern | Figures/tables referenced |
|---|---|---|---|---|---|---|
| Intro | 1 | intro-context + model-or-assumption | "[Machine], thanks to [well-known advantages], has found [wide application]" | mechanism sentence (contrast with older technology), then "These advantages, however, are superseded by [problems] when [condition]", then governing equations with symbol list | cluster of 7 (monographs) | equations only |
| Intro | 2 | taxonomy-overview (field level) | "[Topic] control methods can be divided into [A] and [B]" | figure callout, then definitional mechanism sentences per branch, "Thus," consequences | none | Fig. 1 |
| Intro | 3 | literature-category (dominant method) | "According to the definition above, [category] is a general [philosophy] implementable in [many ways]" | named originators, mechanism sentences, analogy to older technology | named-author single x2 | none |
| Intro | 4 | literature-category (alternative methods) | "[Established transformation] has a good physical basis because [analogy]" | "However, from the theoretical point of view, [alternatives] can be selected"; cluster; named proposals with method names; "recently" item | cluster of 3, named-author single x3, single | none |
| Intro | 5 | literature-category (historical turn to the topic) | "When, in [period], there was a trend toward [standardization], there appeared [innovative studies] of [originators], which depart from [prevailing idea]" | what they proposed (mechanism), naming of the strategy, note on continuous development since [year] with pointer to the reference list | named-author cluster of 3 + named-author single | none |
| Intro | 6 | approach-and-contributions (purpose + scope) | "The purpose of this paper is to [aim A] and to [aim B]" | scope restriction sentence; "However, some references are included concerning [out-of-scope item]" | single | none |
| Intro | 7 | model-or-assumption (working definition) | "Remark: Since there is no [shared terminology] regarding [topic], in this paper under [term] we refer to [definition]" | none | none | none |
| II-A | 1 | method-objective (reference-scheme baseline) | "In the standard version of [reference scheme], [quantity] is used as [control quantity]" | equation with symbol definitions, bracketed figure pointer | single | Fig. 2(a), eq. |
| II-A | 2 | mechanism (alternative control quantity) | "In the case of [drive type], however, not only [A] but also [B] may be used as [control quantity]" | equation; "Note that [B] is a state variable adjustable by [input]"; derived equations and vector definitions | none | Fig. 2(b), Fig. 3(a)(b), eqs. |
| II-A | 3 | mechanism (operating modes) | "For [operation mode], [output] constitutes [sequence], so that [state] moves along [path]" | contrast with second mode; figure pointers | none | Fig. 3(c)(d) |
| II-A | 4 | mechanism (thought experiment) | "From the point of view of [goal] it is [relative quantity] that is important" | "Suppose that [condition]" walk-through; "The important conclusion that follows from [analysis] is [relation]" | single | Fig. 4, eq. |
| II-A | 5 | design-implication (regime exceptions) | "In the range of [regime], [mechanism] is too slow to achieve [goal]" | alternative action; second regime where "[option] cannot be employed" and how control is then achieved | none | Fig. 4 |
| II-A | 6 | synthesis (bulleted properties) | "Summing up the outcomes so far obtained, [system] is characterized by the following properties" | bullet list of six property statements | none | none |
| II-B | 1 | taxonomy-overview + comparison | "The generic [scheme] for [drive] is shown in Fig. [n](a)" | block walk-through; "Compared to the conventional [scheme] [Fig.], the [scheme] has the following features" + 4 bullets; "Depending on how [design choice] is selected, two schemes are possible" | named-author single x2 | Fig. 5(a)(b), Fig. 6(a)(b) |
| V-A | 1 | cross-cutting-comparison / limitation (Families 1–2) | "The well-known disadvantages of [family] are: [list of five]" | implementation contrast (analog vs discrete), figure callout, condition equation, "However, it requires [cost]" | none | Fig. 10(a)(b), eq. |
| V-A | 2 | taxonomy-overview (Family 3) | "All the above [difficulties] can be eliminated when, instead of [component A], [component B] is used" | "Basically, [family] can be implemented by [scheme kind] with [three controller kinds]"; mechanism; "Therefore, differently from [conventional], [aspect] is neglected" | none | none |
| V-B | 1 | category-opener (variant 1) | "In the [scheme] of Fig. [n](a), [quantities] are calculated from [commands] according to the following equations" | equations; walk-through; back-reference "As mentioned in Section [x], [benefit]" | single (in caption) | Fig. 11(a), eqs. |
| V-C | 1 | category-opener via limitation (variant 2) | "The [scheme] of Fig. [n](a) requires [estimators] and, therefore, all [parameters] have to be known" | "To enhance [performance], a variant with [feature] can be used [Fig.] [refs]"; equation | cluster of 2 | Fig. 11(b), eqs. |
| V-D | 1 | category-opener via improvement (variant 3) | "Further improvement can be achieved when both [A] and [B] are controlled in [closed loop]" | figure callout with citations; equations; approximation; feedforward mechanism | cluster of 2 | Fig. 11(c), eqs. |
| V-E | 1 | category-opener + design-implication (variant 4) | "The outputs of [controllers] can be interpreted as [components] in [coordinates] giving the block scheme of Fig. [n](d)" | equations; "The above equations show that [component] only affects [X]"; "Note that ... requires ..."; comparative judgment "less noisy than [previous schemes]"; hybrid mention | cluster of 2, cluster of 2 | Fig. 11(d), eqs. |
| V-F | 1 | category-opener (controller kind: predictive) | "The main idea behind [scheme] is to force [quantities] to [reach references] in [one period] by [means]" | three named approaches, each with a mechanism relative clause; constraint limitation "Due to [limits], [approach] is not always possible"; equation; performance + condition; "Therefore, it can be used in [application]" | named-author cluster of 2, named-author single x2 | Fig. 11(d), eq. |
| V-G | 1–2 | category-opener via trend (controller kind: AI) | "In the last decade a fast development of [technology] has been observed" | cluster; "The combination of [A] and [B] has been proved to be powerful as it offers [advantages]"; cluster; named proposal; block walk-through; performance pointer in brackets | cluster of 4, cluster of 7, named-author single | Fig. 12(a)(b) |
| VI | 1 | category-opener (application axis) | "[Technique] adjusts [quantities] in a closed-loop fashion where [feedback] are estimated from [measurements]" | "Therefore, it is a general strategy independent of [parameters] and can be applied to [list]"; "In all cases both [Family 1] and [Family 3] can be used" | cluster of 5, cluster of 7, cluster of 4 | none |
| Concl | 1 | conclusion (restatement + positioning) | "This paper has reviewed [topic] for [application]" | judgment vs reference method; conditional "when [condition], [topic] is the natural solution" | none | none |
| Concl | 2 | synthesis (feature bullets) | "The main features of [topic] can be summarized as follows" | four bullets; last bullet carries a "however" limitation | none | none |
| Concl | 3 | synthesis (taxonomy restated) | "Starting from [scope], the [strategies] have been divided into three groups: [labels]" | three past-participle sentences: presented, examined, indicated | none | none |
| Concl | 4 | comparison → recommendation | "[Family] is preferred for [application class] and is very effective in [regime] where [properties] are achieved" | "Therefore, it is well suited for [applications]"; repeated per family; last family introduced with "Instead," | none | none |
| Concl | 5 | outlook (untraced) | "As a conclusion of the survey, it is the belief of the authors that [topic] will continue to [role]" | none | none | none |

## Summary-to-judgment turns
1. Opener of the Family-3 section (critical-evaluation subsection): "The well-known disadvantages of [family] are: [list]" — backed by an implementation-mechanism argument plus a figure, no citation; flat and strong ("well-known").
2. Same subsection, next paragraph: "All the above [difficulties] can be eliminated when [alternative component] is used" — backed by mechanism explanation only; absolute, unhedged.
3. End of the Family-2 section: "[Property] and [property] are the main reasons why [scheme] is convenient for [application]" — backed by a citation cluster of 3; moderate-strong.
4. Close of a modification sub-item: "However, the price for [benefit] is [cost]" — backed by argument only; flat trade-off; also "Note that [A] can be reproduced by [B] when [setting] [ref]" and "Note that ... requires ... Then, [scheme] is less noisy than [others]" (equation-backed).
5. Conclusion: "[Family] is preferred for [application] ... Therefore, it is well suited for [applications]" and "[Family] is an excellent solution for [applications]" — backed by earlier feature lists, no citations; strongest language in the paper; the only attributed opinion is the closing "it is the belief of the authors that".

## Figure and table roles
- Field-classification figure (one): taxonomy overview; claim stated before the callout ("can be divided into ... presented in Fig. [n]"); pointed at, then each branch defined in prose rather than walked through.
- Block diagrams (six, one multi-panel): category-opener anchor; the callout is the first sentence of the category subsection ("The block diagram of [scheme] is shown in Fig. [n](a)"); walked through signal by signal; one pairs the topic scheme with the reference scheme so a feature bullet list can follow; the multi-panel figure acts as the sub-taxonomy map for Family 3, each subsection anchored to one panel.
- Mechanism diagrams (vector paths, sector definitions, controller operation; five): claim first, bracketed pointer appended to the clause "[Fig. n(b)]"; interpreted via a "Suppose that" thought experiment or a "Fig. [n] illustrates [A] and [B]" contrast.
- Oscillograms (four): evidence for a performance claim; claim before callout ("The excellent [performance] is evident in Fig. [n](b), which shows [transient] for [condition]"); one number with condition and a hedge attached; the others merely pointed at ("is shown in", bracketed); one panel is never referenced in the text.
- Lookup table (one): pointed at in one clause ("selected according to Table I"), never walked through; no comparison table exists—bullet feature lists (four to six items) replace it.

## Introduction closing chain
- Paragraph count: 2 (purpose/scope paragraph, then a terminology remark), preceded by a historical-turn paragraph that introduces the topic.
- Gap form: no explicit gap; motivation accumulates in two single sentences—continuous development by many researchers (volume) and absence of shared terminology; no limitation of prior reviews stated; gap language weak.
- Contribution form: prose, one sentence, two task-worded aims ("to give [review] and to put in evidence [differences]"), plus a scope sentence and one out-of-scope pointer with a single citation; no numbering, no count.
- Organization paragraph: not observed.
- Mapping to sections: none in the Introduction; the three-way split is listed in the abstract and restated in the conclusion; the chain refers back to the originators named in the historical-turn paragraph.

## Taxonomy (reviews only; else "n/a")
- Axes: (1) field level, by control-principle kind (steady-state vs dynamic relations, then by decoupling approach), positioning the topic as one leaf; (2) topic level, by switching-mechanism/frequency kind (hysteresis vs modulator) and, within hysteresis, by flux-trajectory-shape kind attributed to two originators; (3) within the modulator family, loop-structure kind crossed with coordinate-frame kind, then controller kind (linear, predictive, AI-based); (4) an orthogonal application axis by motor-type kind.
- Justification: derived from mechanism—Section II derives operating properties, then "Depending on how [design choice] is selected, two different schemes are possible"; the third family is justified by the critical-evaluation limitation list ("All the above [difficulties] can be eliminated when ...").
- Exclusivity: top-level groups exclusive; hybrids acknowledged in one sentence (cluster of 2); the modulator sub-family is a loose matrix presented as an improvement progression.
- Depth: three levels (family → variant → modification).
- Announcement templates: "[Topic] methods can be divided into [A] and [B]. The general classification of [methods] is presented in Fig. [n]" (field level, Introduction); "Depending on how [design choice] is selected, two different [schemes] are possible. One, proposed by [author], operates with [property A] and the second one, proposed by [author], operates with [property B]" (Section II-B); "[family] can be implemented by means of [scheme kind] with [three controller kinds]" (Section V-A); the full three-group statement appears only in the abstract and conclusion.
- Placement: field figure sits with its announcement on page one; the review's own split has no figure; the multi-panel block-diagram figure serves Family 3 at the start of its subsections.
- Category sections open with a block-diagram callout or an improvement/limitation hinge; close with a bullet feature list and/or one application-recommendation sentence; several variant subsections end on a mechanism sentence without synthesis.
- Cross-cutting themes: family-wide modifications collected in a "Modified [scheme]" subsection with numbered sub-items; implementation (analog vs discrete) handled inside the critical evaluation; motor-type axis placed after the technique families and declared applicable to all families.
- Reuse: conclusion restates the three groups and assigns each an application class; not reused for future work.

## Comparison
- Dimension kinds: switching-frequency behavior, torque dynamic response, waveform/harmonic quality, operating-regime coverage (low speed, field weakening, overload), implementation demand (sampling rate, estimators, parameter knowledge), structural simplicity, noise, parameter sensitivity, application suitability (power level, application class).
- Table introduction: n/a (no comparison table); feature lists introduced as "The characteristic features of the [scheme] of Fig. [n] include:" / "Compared to the conventional [scheme] [Fig.], the [scheme] has the following features:"; disadvantage list as "The well-known disadvantages of [family] are: [list]".
- Trade-offs vs winner: trade-offs stated in-body ("However, the price for [benefit] is [cost]"; "However, it requires [cost]"); winner-per-application declared in the conclusion; strongest praise reserved for the modulator family.
- Differing conditions: a condition clause is attached to each performance claim ("even for [condition]", "although it depends on [condition]", "in [regime]"); a cross-family switching-frequency claim is backed by "as it turns out by comparing [figure a] and [figure b]".
- Rubric: not observed.
- Feeds a recommendation: yes, family → application class via "is preferred for", "is well suited for", "is an excellent solution for", "makes them suited to".

## Research questions
n/a — not observed; a two-aim purpose sentence only, never restated as questions.

## Results ladder
- Review mode: evidence from cited work is interpreted, not reported. Ladder per category paragraph: mechanism (equation or block walk-through) → property statement (feature bullets or one performance sentence) → application implication ("Therefore, it can be used in [application]"). Observation/evidence verbs: is shown, is evident, illustrates, exhibits, is characterized by. Mechanism verbs: causes, results in, owing to, because, leads to, determines, "it follows from (n) that". Implication verbs: is convenient for, is preferred for, is well suited, can be used in.
- Interpretation sits in the same paragraph, immediately after the callout; a single number carries a hedge and a condition. Cited proposals are summarized as "[authors] have proposed [algorithm], which uses [feature]" or "based on [X] instead of [Y]". Anomalies: not observed; limitations arrive as "However," sentences followed at once by the fix.

## Future work derivation
- not observed as items. One closing outlook sentence: [topic will keep a strategic role] -> [no requirement stated] -> untraced; placement: last sentence of the conclusion; wish-list style, one sentence.
- Untapped traces present in the body without follow-up: parameter sensitivity of one modification; performance dependence on estimation quality (final feature bullet); predictive control "not always possible" under actuator limits; startup problems for one motor type.

## Section endings and synthesis (reviews only; else "n/a")
- Family sections end with a bullet feature list (Families 1, 2) plus, for Family 2, an application sentence backed by a cluster of 3; variant subsections mostly end on a mechanism or hybrid mention with no synthesis; the bridging subsection ends with a forward pointer ("will be presented in the next section").
- The synthesis of Families 1–2 is placed as the opener of Family 3's section (critical evaluation), not as the ending of Family 2; one in-body cross-family relation ("[A] can be reproduced by [B] when [setting]").
- Final synthesis: conclusion restates the split with past-participle verbs, then relates categories by assigning each an application class with property → "Therefore," → application, using "Instead," to contrast the last; no research agenda.

## Language signals
- Register: "this paper" for purpose and conclusion; one "we refer to" in the definition remark; "the authors" for the closing opinion; otherwise agentless passive. Present tense for mechanisms and scheme descriptions (passive: is shown, is selected, are compared; active with inanimate subjects: the controller imposes/determines); present perfect for literature ("has been proposed", "have been proposed", "has been observed", "has been proved") and for the conclusion's restatement ("has reviewed", "have been divided/presented/examined/indicated"); past simple only in the historical narrative. Formal but evaluative adjectives allowed (excellent, interesting, innovative, very convenient). Sentence length mean ≈ 22–26 words, spread ≈ 8–50, long tails from symbol lists and bracketed figure pointers. Paragraphs 4–9 sentences; many single-paragraph subsections; five embedded bullet lists (3–6 items).
- Section openers: Introduction: "[Machine], thanks to [advantages], has found [wide application]"; principles: "In the standard version of [reference scheme], [quantity] is used as [role]"; category/scheme: "The block diagram of the [scheme] is shown in Fig. [n](a)"; modifications: "Many modifications of the basic [scheme] aimed at improving [list] have been proposed during [period]"; sub-item: "During [conditions] the basic [scheme] [does X] resulting in [drawback] owing to [cause]"; bridge: "In contrast to [family A], [family B] has been studied mainly by [group] [refs]"; critique: "The well-known disadvantages of [family] are: [list]"; improvement variant: "Further improvement can be achieved when [A] and [B] are [closed-loop]"; limitation variant: "The [scheme] of Fig. [n] requires [X] and, therefore, [consequence]"; idea variant: "The main idea behind [scheme] is to [goal] by [means]"; trend: "In the last decade a fast development of [technology] has been observed"; application section: "[Technique] adjusts [quantities] in a closed-loop fashion where [feedback] are estimated from [measurements]"; application subsection: "In contrast to [motor A], [property] in [motor B] is [different]" / "The main motivation in usage of [motor] is [property]"; conclusion: "This paper has reviewed [topic] for [application]".
- Gap/limitation shapes: "These advantages, however, are superseded by [problems] when [condition]"; "This drawback can be avoided by using either [A] or [B]"; "However, the price for [benefit] is [cost]"; "Due to [constraint], [approach] is not always possible"; "[Scheme] requires [X] and, therefore, [parameters] must be known"; "However, for precise control, more complex calculation is required [refs]"; "this often causes [problem A] and [problem B]"; "[task] is more difficult than for [alternative] [refs]". Verbs: superseded by, requires, cannot be employed, causes, results in, is limited by, is not always possible. Proportion: about one limitation sentence per category paragraph, each followed at once by the fix; family-level limitations collected once as a list.
- Contribution phrasing: prose, one sentence, two task-worded aims ("to give [review] ... and to put in evidence [differences]"), plus scope sentence; conclusion restates with "have been systematically presented / briefly examined / indicated".
- Transitions: "However," (~12, also mid-sentence "however,"), "Therefore," (~8), "Thus," (~4), "Also," (~3), "In contrast / Contrarily / Instead," (~4), "Note that" (3), "In such a case" (2), "In this scheme" (2), "According to [the previous discussion / the definition above]" (2), "Moreover," / "Furthermore," / "On the other hand" / "In any case" / "Summing up" (1 each), "As mentioned in Section [x]" (1). Paragraphs link mainly by content (figure callout or scheme name as first sentence; improvement chain "To enhance ... / Further improvement ..."); one explicit forward bridge.
- Hedging: mechanisms and features stated flat; modal possibility for options ("can be used", "may be used", "can be achieved"); softeners "basically", "nearly", "quite similar/different", "in most cases", "often", "not always"; the one number carries "about [value], although it depends on [condition]"; cited performance stated flat with a condition ("exhibits good [performance], even for [condition]"); evaluative judgments unhedged ("excellent", "very effective", "considerably", "is the natural solution"); opinion attributed once ("it is the belief of the authors").
- Callout templates: figures: "The [block diagram] of [X] is shown in Fig. [n](a)"; "[Item] is illustrated in Fig. [n](a) and (b), respectively"; clause-final bracket "[Fig. [n](b)]"; "Fig. [n] illustrates [item] in [A] [Fig. n(a)] and [B] [Fig. n(b)]"; "The [performance] is evident in Fig. [n](b), which shows [transient] for [condition]"; "as it turns out by comparing [item] in Figs. [a] and [b]". Tables: "[item] is selected according to Table [n]". Equations: "the [system] equations are [refs] (n)–(m) where [symbols] are [meanings], respectively"; "as given by (n)"; "It follows from (n) that (m)"; "can be calculated as [ref] (n)"; "according to the following equations: (n)"; "With the approximation (n), Equation (m) can be written in the form (k)"; "The above equations show that [component] only affects [X]"; "Note that calculation of [X] by (n) requires [Y]".
- Comparison shapes: "Compared to the conventional [scheme] [Fig.], the [scheme] has the following features:" + bullets; "In contrast to [A], [B] [property]"; "[quantity] is lower than in [scheme] because [reason], as it turns out by comparing [figures]"; "[scheme] is less noisy than [previous schemes] that are based on (n)"; "[motor] are fully competitive with [motor] in terms of [dimensions]"; "differently from [conventional], in [scheme] [aspect] is neglected"; "[A] can be reproduced by [B] when [setting] [ref]"; "[Family] is preferred for [application] ... Therefore, it is well suited for [application]"; "Instead, [property] required by [family] makes them suited to [application] because of [reason]".
- Conclusion shape: five moves—(1) "This paper has reviewed [topic]" plus positioning vs the reference method with a conditional "when [condition], [topic] is the natural solution"; (2) bulleted feature summary "can be summarized as follows"; (3) taxonomy restated with past-participle verbs; (4) per-family application recommendation (property → "Therefore," → application, "Instead," for the last); (5) one-sentence attributed outlook. No limitations of the review, no future work.
- Generic connective phrases: "The purpose of this paper is to"; "According to the previous discussion,"; "As mentioned in Section [x],"; "From the point of view of"; "In such a case,"; "Summing up the outcomes so far obtained,"; "The important conclusion that follows from"; "will be presented in the next section"; "can be summarized as follows"; "As a conclusion of the survey,"

## Roles shown
- intro-context: 1
- literature-category: 4
- limitation: 5 (sub-item openers, critical evaluation, limitation-hinged variant opener, constraint sentence, application-problem opener)
- gap: not observed as a paragraph (two motivation sentences only)
- approach-and-contributions: 1
- contribution-list: not observed (prose aims inside the purpose paragraph)
- research-questions: not observed
- organization: not observed
- method-objective: 1
- model-or-assumption: 2 (governing equations; working definition)
- mechanism: 9
- design-implication: 3
- setup: not observed (block-diagram walk-throughs folded into category-opener)
- results: not observed as standalone paragraphs (oscillogram evidence sentences inside 4 category paragraphs)
- comparison: 3
- discussion-or-limitation: 1 (trade-off close of a sub-item)
- conclusion: 5 (multi-move single section)
- abstract: 1
- caption: 13 retained by the extractor (12 figures, 1 table); weakly learnable
- taxonomy-overview: 3
- category-opener: 14
- cross-cutting-comparison: 1
- synthesis: 3
- research-agenda: not observed (one untraced outlook sentence)
