# Skeleton: SmartGrid_Survey
- Title: "Smart Grid – The New and Improved Power Grid: A Survey"; venue: IEEE Communications Surveys & Tutorials, vol. 14, no. 4; year: 2012 (fourth quarter)
- Type: large review. Evidence: one whole-paper classification tree plus seven branch-level classification trees (references sit in leaf boxes); ≈270 references; five category sections each closed by a "Summary and Future Research" subsection.
- ≈140 body paragraphs (extractor yields 45 page-level blocks); taxonomy figure/table: y (8 classification figures); comparison tables: y but weak (one old-vs-new attribute-contrast table in the Introduction, one project catalogue table in an appendix; no method-vs-method table); explicit RQs/hypotheses: n (rhetorical open questions only); future-work: y (one subsection per category section, plus "lessons" in the Conclusion)
- Extraction damage: paragraphs merged into page-level blocks; Section II and III headings not recovered (merged into the Introduction block); several run-in headers and numbered future-work items promoted to spurious "##" headings; classification-figure trees flattened to token strings; page footer repeated in every block; tables inline; math negligible (one inline distribution notation intact).

## Section list
1. Abstract
2. I Introduction (term definition, old/new contrast, taxonomy bullets, prior surveys, contributions, organization)
3. II Definition-and-scope section (concept history; authority-defined benefit list; external reference model with figure and table; own three-branch split with whole-paper taxonomy figure)
4. III Policy, standards, projects overview (legislation; roadmap list; one standard described; project catalogue table in appendix; project map figure)
5. IV Branch 1, subsystem 1 (physical-resource subsystem): A–C three grid-stage subsections; D two cross-cutting new paradigms; E Summary and Future Research (3 items)
6. V Branch 1, subsystem 2 (information subsystem): A metering/measurement split by device type; B data modeling; C analysis, integration, optimization; D Summary and Future Research (2 items)
7. VI Branch 1, subsystem 3 (communication subsystem): A overview with requirements list; B wireless technologies (6 run-in headers + "Remarks"); C wired technologies (2 run-in headers); D end-to-end management; E Summary and Future Research (3 items)
8. VII Branch 2 (management): A by objective (3 classes + 2 cross-cutting run-ins); B by method family (4 families); C Summary and Future Research (2 envisioned services + 4 challenges)
9. VIII Branch 3 (protection): A unintentional-failure side (reliability; failure lifecycle phases; paradigm-specific protection run-in); B deliberate-attack side, by asset location and security-vs-privacy; C Summary and Future Research (5 items)
10. IX Conclusions and Lessons
11. Acknowledgment; Appendix A abbreviations table; Appendix B project catalogue table; References
Noise removed: affiliation line, table-caption fragments, three "Measurement" figure-label fragments, two reference-fragment headings, promoted run-in headers.

## Paragraph map
| Section | Para | Function | First-sentence template | What follows the claim | Citation pattern | Figures/tables referenced |
|---|---|---|---|---|---|---|
| I | 1 | intro-context (term definition + old/new contrast) | "Traditionally, [term] is used for [system] supporting [operations]" | definition → contrast sentence → table callout → capability claim → two worked examples | none in prose (table caption single) | Table I |
| I | 2 | intro-context (formal definition) | "More specifically, [topic] can be regarded as [system] using [technologies] to achieve [properties]" | scope sentence + single citation | single | none |
| I | 3 | taxonomy-overview (vision → own split) | "The ultimate [topic] is a [abstraction]" then "Given the vast landscape of [field], different researchers may express different visions" | announcement "in this survey, we explore [n] major systems from [perspective]:" + bulleted branch definitions | none | none |
| I | 4 | literature-category (prior surveys) | "Other surveys on [topic] were done in [cluster]" | cluster of 12, then one sentence per survey: [Author] et al. [n] [verb] [object] | cluster of 12 + named-author single ×9 + unnamed cluster of 2 | none |
| I | 5 | approach-and-contributions + contribution-list (same paragraph) | "Our survey complements [prior surveys] in that we: 1) [task]; and 2) [task]" | one novelty sentence naming [n] aspects | none | none |
| I | 6 | organization | "This survey is structured as follows" | one sentence per section, plus appendix pointer | none | none |
| II | 1 | intro-context (concept history) | "The initial concept of [topic] started with [idea] aiming at [goals]" | "However, new requirements drove [actors] to rethink [scope]" → policy-act sentence | single | none |
| II | 2 | model-or-assumption (authority-defined requirements) | "Although a precise definition of [topic] is lacking, according to [authority], the anticipated [benefits] are:" | long numbered list (>10 items) | single (authority) | none |
| II | 3 | model-or-assumption (external reference model) | "To realize [paradigm], [authority] provided [reference model] (as shown in Fig. N)" | model description → table callout → pointer to source appendix | single | Fig. 1, Table II |
| II | 4 | taxonomy-overview (own split vs external model) | "Note that [authority] proposed this model from [perspective]. In contrast, our survey, from [other perspective], divides [topic] into [n] systems" | list of branch labels | none | none |
| II | 5 | category definition (branch 1) + sub-split | "1) [Branch]: The [branch] is the [resources] underlying [topic]" | mechanism explanation with examples; forward reference; bulleted sub-split; justification note (complexity handle, standard compliance) | single (standard) | none |
| II | 6 | category definition (branch 2) | "2) [Branch]: The [branch] is the subsystem that provides [services]" | "The key reason why [X] is [driver]" → current-objectives sentence | none | none |
| II | 7 | category definition (branch 3) | "3) [Branch]: The [branch] is the subsystem that provides [services]" | necessity claim "must not only [A] but also [B]" | none | none |
| II | 8 | taxonomy-overview (figure callout) | "Fig. N shows the detailed classification of these [n] systems" | "In this paper, we will describe [topic] using this classification" + reader guidance to refer back | none | Fig. 2 |
| VII | 1 | category-opener (context + misconception correction) | "In [topic], [foundation] is supported, which lays the foundation for [objectives]" | "A common superficial understanding is [X]. This is not true." → corrected claim | none | none |
| VII | 2 | mechanism (worked example with data figure) | "For example, let us consider [concept], one of the most important [category]" | old approach → "However, this may be [drawbacks]" → "This is because [mechanism]" → figure callout → "As we can see, [observation]" → new approach | single (data source) | Fig. 13 |
| VII | 3 | organization (section-level) | "In this section, we explore [topic]" | "We first classify [works] according to [axis A] and then according to [axis B]" | none | none |
| VII-A | 1 | category-opener + taxonomy figure | "Within the framework of [topic], many [goals], difficult in [old system], become possible" | "So far, the works mainly focus on [n] objectives: 1)…" → figure callout | none | Fig. 14 |
| VII-A | 2 | category-opener (sub-objective 1) | "The research on [objective] mainly focuses on two topics" | definition → cluster of 10 → "As discussed before, [mechanism]" → "Next we briefly describe these research works" | cluster of 10 | none |
| VII-A | 3 | literature-category (per-paper enumeration) | "[Author] et al. [n] designed [artifact] and focused on [aspect]" | ~10 consecutive named singles, each verb + object + one clause | named-author single ×10 | none |
| VII-A | 4 | literature-category (sub-objective 2) | "The second topic of [objective] is [sub-objective]" | "However, [new condition] makes this problem more complicated" → 3 named singles | named-author single ×3 | none |
| VII-A | 5 | literature-category (objective 2, cluster-sorted by level) | "We have reviewed the works on [objective 1] in the above" | "[Objective 2] is also important … at [level] [cluster], [level] [cluster], [level] [cluster]" → one single with reason | clusters of 9, 2, 10 + single | none |
| VII-A | 6 | literature-category + limitation (objective 3) | "[Objective 3], another important [category], has a significant influence on [domain]" | "However, note that [A] is not directly equivalent to [B]. This is because [mechanism]" → "as suggested by [Author]" → 4 named singles | named-author single ×5 | none |
| VII-A | 7 | cross-cutting-comparison (run-in theme 1) | "Considering the importance of [themes], we particularly list the works on them" | run-in header; 2 named singles with "The results showed that"; "A review of [X] can be found in [ref]" | named-author single ×2 + single | none |
| VII-A | 8 | cross-cutting-comparison (run-in theme 2) | "As stated in Section [X], in [theme], [problem]" | method-sorted mini-clusters "using [method] [refs], [method] [refs]" → "Recall that [method] can [property]" → named singles → "Therefore, a key question is how to [task]" | clusters of 2 + named-author single ×4 | none |
| VII-B | 1 | category-opener + taxonomy figure | "In order to solve [objectives], researchers have adopted various [methods]" | "Thus far, researchers mainly use [n] families" → figure callout | none | Fig. 15 |
| VII-B | 2 | literature-category (family 1, cluster-sorted) | "For [family] approaches, the commonly used tools are [X] [cluster] and [Y] [cluster]" | "Since [condition], other techniques such as [Z] [cluster] are also widely used" | clusters of 4, 4, 6, 1, 4 | none |
| VII-B | 3 | literature-category + synthesis (family 2) | "[Family] focuses on [definition]" | 2 named singles (one "they proved that") → "Considering that [scale], we believe that [family] will play an important role" | named-author single ×2 | none |
| VII-B | 4 | literature-category (family 3, reason-led) | "[Family] is also a strong analysis tool for [topic]" | "One reason is that … For example, [Author] … Another reason … For example, [Author]" | named-author single ×3 | none |
| VII-B | 5 | literature-category (family 4) | "[Family] may also be popular in the emerging [topic]" | mechanism sentences → "The authors of [cluster] proposed [scheme]" → "Recall that [concept]" | cluster of 2 | none |
| VII-C | 1 | synthesis | "Within the framework of [topic], many [goals] … become easy and possible" (re-uses the VII-A opener) | "As reviewed [here], we found that most works aim to [objectives]" → "We believe that [forecast]" → "We present [n] possible [services]" | none | none |
| VII-C | 2–3 | research-agenda (envisioned services) | "[n]) [Service label]: [definition of enabling technology]" | worked example; analogy "Like [consumer platform] [ref]" | single | none |
| VII-C | 4 | research-agenda opener | "Although [system] is promising, we still face many challenges" | "We summarize the important challenges and [directions] worth exploring" | none | none |
| VII-C | 5–8 | research-agenda (numbered challenges) | "[n]) [Challenge label]: As mentioned before, [prior claim] … it is a challenge to [task]" | reason → example → "we suggest / we thus need to consider [approach]" → back-reference to an earlier section | cluster of 3 / single / none | none |
| IV-E, V-D, VI-E, VIII-C | opener ×4 | synthesis (section-ending) | "In this section, we [have] reviewed the works on [topic]" | "We list the following challenges and [directions] worth exploring" → numbered items | none | none |
| IX | 1 | conclusion (scope recap) | "Due to the potential importance of [topic], this survey comprehensively explores [scope]" | "We have surveyed [items] … We have outlined [challenges] for each" | none | none |
| IX | 2 | conclusion (branch-1 recap + judgment) | "We further divided [branch] into [n] subsystems" | "For [sub], we have reviewed [topics]" ×3 → "In brief, in the transition [A→B], [judgment]" + single | single | none |
| IX | 3 | conclusion (branch-2 recap + forecast) | "For [branch 2], most of the existing works aim to [objectives] by using [methods]" | "We believe that [services] would emerge and eventually [transform users' lives]" | none | none |
| IX | 4 | conclusion (branch-3 recap + double-edged judgment) | "For [branch 3], we have reviewed [topics]" | "However, we must note that [X] on one hand [benefit], on the other hand [risk]" → "More thorough research on [branch] is desirable" | none | none |
| IX | 5 | lessons opener | "From the existing efforts on [topic], we have also learned some useful lessons" | "we list these lessons from [n] perspectives: [list]" | none | none |
| IX | 6 | lesson 1 (deployment) | "First, [practical deployments] should be well-analyzed before [initiative] begins" | cautionary case with number + condition → "One possible reason … is that [cause]" → "Therefore, although [positive], we still need to [action]" | single | none |
| IX | 7 | lesson 2 (infrastructure) | "Second, the current projects are mainly led by [actor] (refer to Table N)" | "They probably may not have [expertise]. However, [system nature]. The evolution may ask for [actors]" | none | Table IV |
| IX | 8 | lesson 3 (management) | "Third, the term [keyword] implies that [property]" | "However, thus far, as stated in Section [X], [state]. The experience in [other sector] tells us that [rule]. [Topic] is no exception." | none | none |
| IX | 9 | lessons 4a/4b (protection) | "Fourth, for [branch], we have the following two lessons" | quoted rhetorical question; cross-references to two earlier sections; "The second lesson is that [rule]" | single | none |
| IX | 10 | conclusion (closing) | "In summary, there is no doubt that [topic] will lead to [benefits]" | "However, [we] still have a long way to go" → closing metaphor | none | none |

## Summary-to-judgment turns
1. Intro, after prior-survey enumeration: "Our survey complements [these surveys] in that we: [numbered tasks]" + "The novelty of this survey is in [aspects]". Backed by the task list itself (scope, volume, future directions). Moderate, flat; no prior survey is criticised.
2. IV-A, after benefits of a paradigm: "However, implementing [X] in practice is not easy, due to [n] reasons. First, [reason]. Second, the authors of [cluster] indicated that [cost]." → "a systematic research on how to balance [A] and [B] is essential". Backed by two cited reasons. Moderate.
3. VI-B, run-in "Remarks:" after the technology catalogue: "It is clear that [class] is important for [topic], and that different technologies might be applicable" → deferral to a cited assessment methodology (named single). Strong opener, hedged body.
4. VI-C, wired: "The debate on [X]'s actual role is still open. Some advocate [cluster of 2], while others express concerns [cluster of 2]. Although [caveat], without a doubt, [X] is the only [class] with [property] [single]" → "The most urgent task for [research on X] might be [need]". Backed by a cited debate; mixed strength ("without a doubt" vs "might be").
5. VII-B, after two named singles: "Considering that [deployment scale], we believe that [family] will play an important role in [tasks]". Backed by argument from expected data volume; hedged author opinion. Also recurrent: "[X] on one hand [enables], but on the other hand [opens vulnerabilities]" (VIII-B opener, VIII-C, IX).

## Figure and table roles
- Whole-paper classification tree: taxonomy overview; placed in Section II after the three branch definitions; callout after the prose split ("Fig. N shows the detailed classification of these [n] systems"); pointed at, with a reading instruction; its caption also maps branches to sections.
- Branch-level classification trees (7): taxonomy at (sub)section level, references sit in leaf boxes; split announced in prose first, then "Fig. N shows a classification of the works on [topic]"; pointed at, then the prose walks the leaves in order.
- Example/mechanism illustrations (4): "Fig. N shows an example of [system]"; pointed at; long captions carry the interpretation (layers, flows).
- External data figures (3, from cited sources): evidence for context claims; one is interpreted after the callout ("As we can see, [observation]"), the others are pointed at with the claim stated before ("As [trend], it is expected that [forecast]. Fig. N shows [data]").
- External reference-model figure + its definition table: model-or-assumption; pointed at with pointer to source appendix.
- Project map figure: summary of the field; interpreted ("We can observe that [observation], although [caveat]") and reinforced with a named-author single.
- Attribute-contrast table (old vs new): comparison; "Table N gives a brief comparison between [A] and [B]"; not walked through.
- Appendix catalogue table (name, organisation, country, period, description, category): summary of the field; introduced with "we summarize [n] major [items], shown in Table N of Appendix B. They cover [category list]"; reused as evidence in Conclusion lesson 2.

## Introduction closing chain
- Closing chain: 3 paragraphs (prior surveys → contributions → organization), preceded by the taxonomy bullets, so 4 paragraphs from the split announcement onward.
- Gap form: implicit, one sentence, framed as complement ("Our survey complements … in that we …"); prior surveys are summarised one per sentence with no limitation stated; gap = scope contrast (breadth, systematic classification, per-branch future directions).
- Contribution form: inline numbered in prose (1), 2)), task-worded (survey, classify, outline), count 2; followed by one novelty sentence listing 3 aspects.
- Organization paragraph: present; one sentence per Section II–IX plus appendix pointer; contribution 1 (classification) maps to the category sections, contribution 2 (future directions) is not mapped explicitly (it lives in each section's closing subsection); the chain refers back to the three bulleted branches by name.

## Taxonomy
- Axes (kinds): top level by system function/layer (infrastructure vs management vs protection), 3 branches. Branch 1 by resource type (physical energy / information / communication); within: by grid stage (3) + a "new paradigms" bin; by data-lifecycle stage then by device type and by processing step; by medium (wireless/wired) then by technology + an end-to-end management bin. Branch 2 by two parallel axes: by objective (3 classes) and by method family (4), matrix-like, same works cited under both. Branch 3 by threat class (unintentional vs deliberate), then by failure-lifecycle phase, by asset location, and by security-vs-privacy.
- Justification: explicit contrast to an external role-based reference model ("[authority] proposed this model from [perspective]; in contrast, our survey, from a technical viewpoint, divides …"); sub-split justified by complexity management and compliance with a named standard.
- Exclusivity: top levels exclusive by construction; branch 2 is a matrix; two cross-cutting paradigms recur in three branches and are handled as bold run-in subsections ("Considering the importance of [themes], we particularly list the works on them") with back-references ("As stated in Section [X]").
- Depth: 4 levels (system → subsystem → topic → subtopic); figures show 3–4 levels.
- Announcement templates: Intro: "in this survey, we explore [n] major systems from [perspective]:" + bullets; Sec II: "our survey … divides [topic] into [n] major systems: [list]" → "Fig. N shows the detailed classification of these [n] systems"; per branch: "Study in [topic] can be classified into [A] and [B] as shown in Fig. N".
- Placement: whole-paper figure sits in Section II after the definitions (about a page after the Intro bullets); branch figures sit at the start of each (sub)section right after the split sentence.
- Category sections open with context + "In this section, we [verb] [topic]. We first … We then … We finally outline [directions]" and close with a "Summary and Future Research" subsection; sub-subsections open with a definition or importance claim and often close with "In brief, [wrap-up]" or "However, [drawback]".
- Reuse: Conclusion recaps branch by branch in taxonomy order; future-work items are listed per branch; the lessons are organised by four perspectives mirroring the taxonomy (deployment, infrastructure, management, protection).

## Comparison
- Dimension kinds: qualitative attribute pairs (old vs new); per-technology cost, deployment speed, coverage, data rate, delay, reliability, security, environmental sensitivity (prose pros/cons); two organisational approaches contrasted by advantages/disadvantages.
- Table introduction template: "Table N gives a brief comparison between [A] and [B]" (not interpreted); catalogue: "we summarize [n] major [items], shown in Table N".
- Trade-offs stated, not winners; one flat superlative on deployment cost attributed to a single citation; pairwise shape "Compared with [A], the biggest strength of [B] is [property]".
- Differing conditions handled by scenario qualifiers ("in [rural/remote] areas", "where no infrastructure exists", "for [application], it is recommended to use [X] or [Y] [ref]").
- Rubric: not observed.
- Recommendation: application-to-technology mapping ("[X] is a good solution for [scenario], since [property]"); suitability assessment deferred to a cited methodology.

## Research questions
n/a. No explicit RQs or hypotheses. Rhetorical/open questions frame one subsection ("The most important question in [subsystem] is, '[question]?'") and appear inside future-work items ("we ask two questions: 1) From [stakeholder A]'s perspective, which [X]? 2) From [stakeholder B]'s perspective, which [Y]?"); none is answered; they are left as open questions.

## Results ladder
Review mode. Cited evidence is reported as "[Author] et al. [n] [verb] [object], [one clause]" with observation verbs proposed, presented, studied, developed, investigated, analyzed, explored, reviewed; finding verbs showed, found, pointed out, indicated, concluded, proved, discovered. Author-side interpretation follows in a separate sentence with mechanism markers "This is because", "since", "Thus", "Therefore", "Hence", "As a result", "In other words", or as an aside ("Note that [definition]", "Recall that [property]"). Interpretation sits at paragraph end or in a "Remarks" run-in. Counter-evidence: "However, [drawback]"; "Some advocate [cluster], while others express concerns [cluster]"; debates marked "still open"/"still not clear". Ladder ends in a need statement ("is essential", "is desirable", "is of great importance") or a forecast ("we believe [X] will play an important role").

## Future work derivation
Placement: own "Summary and Future Research" subsection at the end of each of five category sections (numbered items), plus five "lessons" in the Conclusion. Item template: "[n]) [Label]: [problem statement]. [Reason]. [Example]. We suggest / A possible solution is / We need to consider [approach]. A complete solution along this line is desired." Mostly derived; two wish-list items.
- IV-E.1 renewable output intermittency → statistical/Markov/online-learning modelling + reserve deployment → limitation (generation subsection)
- IV-E.2 EV charging load and availability uncertainty → large-scale stochastic analysis (probability, queueing) → limitation (paradigms subsection)
- IV-E.3 large-scale deployment inexperience → top-down vs bottom-up study, self-organisation, scalable open standards → open question raised earlier (Sec III standards)
- V-D.1 what to store from massive sensed data → mining/learning/compression/database tools → limitation (information-optimisation subsection)
- V-D.2 outsourcing information management to cloud → benefits, then security and partition questions → untraced cell (not in the classification), tied loosely to the "islands of information" limitation
- VI-E.1 interoperability among heterogeneous technologies → cross-layer trade-off study → limitation (overview requirements)
- VI-E.2 topology dynamics from mobile/plug-in devices → protocol + dynamic resource-allocation design → open question ("has not been fully explored"), cross-branch from Sec IV paradigms
- VI-E.3 legacy protocol migration → two-stage transition by analogy with network-address migration → limitation (end-to-end subsection, single citation)
- VII-C services (2): pervasive-computing integration; app-store platform → untraced (wish-list from the "explosion of functionality" forecast)
- VII-C.1 regulating new local markets → truthful auction via classic scheme (cluster of 3) → taxonomy cell (auction family)
- VII-C.2 distributed management sub-optimality → optimal subgrid size, timely information → limitation (distributed paradigm)
- VII-C.3 ad-hoc/plug-and-play organisation → self-configuration, cross-subgrid resource allocation → open question (Sec II definitions)
- VII-C.4 renewables uncertainty in management → stochastic/robust programming, Markov/online learning → explicit back-reference to IV-E.1
- VIII-C.1 cryptographic interoperability → layered PKI approach from a cited survey → limitation (heterogeneity, Sec VI) + single citation
- VIII-C.2 privacy vs accessibility → tiered privacy levels like access control → limitation (privacy subsection)
- VIII-C.3 complexity and expanded paths → autonomous subgrids with interconnectivity → the double-edged statement at VIII-B opener
- VIII-C.4 rising consumption/asset utilisation → margin computation + real-time monitoring → limitation (reliability subsection, single citation)
- VIII-C.5 complex fast decision-making → distributed decision systems, response-time vs optimality balance → limitation (failure-processing work)
- IX lessons (5): project planning (cited case with number), ICT expertise (table back-reference), customer-oriented functionality (Sec VII back-reference + sector analogy), utility trust (Sec V back-reference), risk assessment of new technology (Sec VIII back-reference)

## Section endings and synthesis
- All five category sections end with a synthesis subsection: one- or two-sentence recap ("In this section, we [have] reviewed the works on [topic]"), then "We list the following challenges and [directions] worth exploring", then numbered items. VII variant re-uses its own section-opener sentence, adds "we found that most works aim to [objectives]" plus a belief forecast and two envisioned services before the challenges; VIII variant adds a concession ("Although [goals] are the principle characteristics, realizing them poses many challenges").
- Sub-subsections end with "In brief, [wrap-up]", "However, [drawback]", or "Therefore, one important application of [X] is [use]"; no bridge sentence to the next category.
- Final synthesis (Conclusion): scope recap → branch-by-branch recap in taxonomy order with one judgment or forecast per branch → lessons by four perspectives mirroring the taxonomy, each with an example and a section or table back-reference → "In summary, there is no doubt that [benefits]. However, [long way to go]" → closing metaphor.

## Language signals
- Register: "we" throughout ("we explore", "we list", "we suggest", "we believe"); artifact named "this survey"/"our survey"; "In this paper" once; readers addressed directly ("the readers"); inclusive imperatives ("Let us consider", "Let us recall"). Tense: present for definitions and state of field; simple past for cited works; present perfect in recaps; future for forecasts. Voice: active dominant; passive for consensus ("is widely regarded as", "have been proposed in [cluster]"). Formality moderate with conversational asides and one rhetorical question in quotes. Sentence length: mean ≈24 words, wide spread (4-word assertions to 50+-word list sentences). Paragraphs 6–14 sentences; catalogue paragraphs up to ≈20.
- Section openers: category section: "[Foundational property] lays the foundation for [topic]" or "The evolution of [topic] relies on not only [X], but also [Y]" → "In this section, we [explore topic] and outline [directions]"; subsection: "[Term] is the process/ability of [definition]" or "For [subsystem], the most important problem is how to [task]" or "The most important question in [subsystem] is, '[question]?'"; technology paragraph: "[Tech]: [Tech] is [definition] [ref]. [maturity]. [benefit for topic]. [named singles]. However, [drawback]"; aphorism opener for the security subsection: "[Field] is [metaphor]. [Topic] is no exception."; summary: "In this section, we [have] reviewed the works on [topic]"; conclusion: "Due to the potential importance of [topic], this survey comprehensively explores [scope]".
- Gap/limitation shapes: "However, implementing [X] in practice is not easy, due to [reasons]"; "Although [positive], [negative]"; "The debate on [X] is still open"; "[X] has not been fully explored"; "[X] is still an open question"; "is not a trivial task/problem"; "is challenging"; "may not be good enough". Verbs: poses, suffers, is not clear, remains open. Proportion: nearly every future-work item and about half the technology paragraphs carry one; prior surveys receive none (complement, not critique).
- Contribution phrasing: "Our survey complements [prior surveys] in that we: 1) [task]; and 2) [task]" + "The novelty of this survey is in [aspects]"; abstract: "we survey [scope]", "we explore [branches]", "we also propose possible future directions".
- Transitions: "However" very frequent (about one per paragraph); "For example/For instance" very frequent; "Note that" very frequent (≈30); "Therefore/Thus/Hence" frequent; "In addition/Furthermore/Moreover" frequent; "As stated/mentioned/discussed in Section [X]" frequent back-references; "Recall that", "In other words", "More specifically", "Thus far/So far", "In brief/In summary", "On one hand … on the other hand", "First, … Second, … Third, …" occasional. Paragraph links are mostly content-linked via topic labels and run-in headers; explicit hand-overs: "We have reviewed [A] in the above. [B] is also important", "Next we briefly describe these research works".
- Hedging: "it is expected that", "is expected to", "may", "might", "could", "it is believed that", "we believe that", "It is likely that", "probably" attach to forecasts and author suggestions; flat for definitions, reported findings ("They found that [result]"), and strong assertions ("It is clear that", "without a doubt", "there is no doubt that", "It is easy to see that", "This is not true", "must", "is of great importance", "It is well-known that").
- Callouts: "Table N gives a brief comparison between [A] and [B]"; "Fig. N shows a classification of the works on [topic]"; "Fig. N shows an example of [system]"; "as shown in Fig. N"; "we use Fig. N to show [content]"; "(described in Section [X])"; "Refer to [ref] for [detail]"; "[More works] can be found in [ref]"; "As we can see, [observation]"; "We can observe that [observation], although [caveat]"; equations: not observed.
- Comparison shapes: "In contrast with [A], [B] is more [property]"; "Compared with [A], the biggest strength of [B] is [property]"; "[A] differs from [B] in that it enables [feature]"; "[A] not only offers [benefits] over [B], such as [list], but is also more suitable for [use]"; "[A] has a substantially higher [metric] than [B]"; "Some advocate [X] [cluster], while others express concerns [cluster]"; "These two [standards] are similar in functionality, and therefore either is suitable"; "[X] is a good solution for [scenario], since [property]"; "The advantages and disadvantages of both [A] and [B] need to be investigated".
- Conclusion shape: importance-led opener → scope recap → branch-by-branch recap with one forecast/judgment each → numbered lessons by perspective, each with example and back-reference → "In summary, there is no doubt that [X]. However, [long way to go]" → metaphor.
- Generic connective phrases: "In this section, we explore"; "We list the following challenges"; "worth exploring"; "Note that"; "Recall that"; "As stated in Section"; "Let us consider an example"; "In brief,"; "Thus far,"; "A complete solution along this line is desired".

## Roles shown
- intro-context: ≈6
- literature-category: ≈35
- limitation: ≈12
- gap: 1 (implicit, scope-contrast form)
- approach-and-contributions: 1
- contribution-list: 1 (same paragraph as above)
- research-questions: not observed (≈4 rhetorical open questions only)
- organization: ≈7 (1 paper-level, 6 section-level)
- method-objective: not observed
- model-or-assumption: 2
- mechanism: ≈10
- design-implication: ≈4 (requirements lists)
- setup: not observed
- results: not observed (no own results)
- comparison: ≈5
- discussion-or-limitation: ≈6
- conclusion: ≈10
- abstract: 1
- caption: ≈5 (long interpretive captions)
- taxonomy-overview: ≈9 (2 paper-level, 7 branch-level figure openers)
- category-opener: ≈18
- cross-cutting-comparison: ≈4
- synthesis: ≈8
- research-agenda: ≈24
