# Skeleton: Design_Approaches_EV_Machines_Review
- Title: "Design Approaches and Control Strategies for Energy-Efficient Electric Machines for Electric Vehicles—A Review"; venue: IEEE Access, vol. 8; year: 2020 (as printed)
- Type: large review. Evidence: taxonomy-driven survey with four second-level splits (by machine type, by control principle, by design-method strategy, by topology family), >100 references, no experiments of its own.
- Approx. 45 body paragraphs (inferred; breaks lost) + 1 abstract; taxonomy figure/table: n (a comparison figure doubles as the type split); comparison tables: y (data-compilation tables, values dropped); explicit RQs: n; future-work section: n (embedded statements only)
- Extraction damage: every section collapsed into one P1 block (paragraph breaks lost); running headers inserted as "##" headings splitting sections; table values dropped (captions inlined mid-sentence); figure captions and page numbers inlined; Roman section numbers lost; three all-caps heading continuations pushed into body text; one reference author list became a heading; editor line injected inside Intro P1.

## Section list
1. Abstract (Front Matter)
2. Introduction
3. Specifications/requirements section (roadmap targets, desirable characteristics, benchmark data, torque envelope, cooling, efficiency-map tool)
4. Design-parameter section (intro + 4 sub-sections, one per machine type)
5. Control-method section (single section, internal 3-way classification)
6. Design-methodology section (single section, implicit 3-way split)
7. Emerging-technology section: opener + A) layout sub-section + B) topology sub-section with 5 sub-sub-sections (one per topology family)
8. Conclusion (bulleted)
9. References

## Paragraph map
Paragraph boundaries inferred from content because breaks were lost. Technical section chosen: control-method section. Taxonomy section: design-parameter section (intro + four category sub-sections) plus emerging-technology section.

| Section | Para | Function | First-sentence template | What follows the claim | Citation pattern | Figures/tables referenced |
|---|---|---|---|---|---|---|
| Intro | P1 | intro-context | [Drivers] are making [technology] increasingly competitive for [mainstream use] | citation cluster, then trend + example + "However, new challenges arise as [condition]" | cluster of 2, cluster of 3 | none |
| Intro | P2 | intro-context (industry landscape) | Table [n] illustrates the main [specifications] of [representative items] | figure/table callout, then market statistic + layout description + product example | single, cluster of 3 | T1 |
| Intro | P3 | literature-category (by machine type) | As [core components], [technologies] have been extensively researched in terms of [aspects] | citation cluster, then per-type contrast sentences, then a problem sentence | cluster of 5, then cluster of 2 ×3, single ×4 | none |
| Intro | P4 | gap + approach-and-contributions + organization (fused) | To increase [outcome], [property] is key in [system] | factor list, one prior-review example, gap sentence, enumerated focus items with section pointers | single | none |
| Intro | P4 tail | source-type note (possibly own paragraph) | The cited [source type A] give [role], whilst [source type B] provide [role] | none | none | none |
| Control | P1 | taxonomy-overview + comparison | On [platform], [component] needs to output [requirement] at [condition] | mechanism sentence, then 3-way classification i)–iii), then trade-off pair from a cited review | single (a review) | none |
| Control | P2 | model-or-assumption + results (cited) + limitation | The selected [variable] must have dominant influence on [loss]; its optimum is obtained by [analytic condition] or [search] | table callout, two studies with number+condition, method contrast, closing limitation | single ×2 (each cited twice) | T4 |
| Control | P3 | model-or-assumption + limitation | Although for simplicity [parameters] are mostly assumed constant, during real operation their variations with [factors] are significant in [application] | citation cluster of estimation techniques, then a cited magnitude | single ×5 | none |
| Control | P4 | results (cited evidence) | In terms of [results] during [cycles], in [cite] the [metric] under [control] is increased by [range] depending on [cycle] | number+condition, second number+condition | single ×2 | none |
| Design intro | P1 | cross-cutting-comparison | [Property] is predominantly determined by [primary factor] | figure callout, then one efficiency-region sentence per type, each cited | single ×5 | F1 |
| Design intro | P2 | taxonomy-overview | Although [shape] is determined by [type], subtle changes can be made through [levers] within [constraints] | announcement sentence listing the four types | none | none |
| Design A | P1 | category-opener + mechanism | [Category] technologies are [mature]; however, [capability] is restricted by [thermal issue] | loss-mechanism sentences, design principle "similar [loss A] and [loss B]" | single ×3 | none |
| Design A | P2 | design-implication | The design and requirements of [variant A] differ from those of [variant B] | conventional-vs-new contrast with figure panels, cited suggestion, caveat, single-study number | single ×3 | F2 panels |
| Design A | P3 | design-implication + limitation | [Technique] are a proven technology to increase [metric] by [range] over [alternative], by [mechanism] | production example, then "However, [manufacturing challenge]" | single | none |
| Design B | P1 | category-opener + mechanism | [Category] have relatively recently become attractive to [market] | sub-split with figure, loss dominance by speed region, design principle | single ×3 | F3 |
| Design B | P2 | design-implication | The numbers of [parameters] have high impact on [performance] and [dimensions] | cited analytical rule, number+condition, mechanism, "However, [trade-off] may be compromised" | single ×2 | none |
| Design B | P3 | design-implication + literature | Great progress has been made with respect to [component design] | production examples, benefit list, harmonic caveat, mitigation, second trend, number+condition, fix | single ×6 | none |
| Design B | P4 | design-implication + comparison | The [rotor feature] is essential for limiting [losses] in [sub-type] | figure+table callouts, cited comparisons with condition, design caution, review pointer, number+mechanism | single ×8, cluster of 2 | F4 panels, T3 |
| Design C | P1 | category-opener + limitation | [Category] are widely investigated for [application] because of [merits] | mechanism, restrictions list, "however, recent literature shows notable advances" | single ×2, cluster of 3 | none |
| Design C | P2 | design-implication | The most effective method to improve [metrics] is to use [material class] with [properties] | cited design number vs production machine, geometry trade-offs "at the price of", caveat | cluster of 2, single ×3 | none |
| Design C | P3 | design-implication + research-agenda | The operation of [category] relies on precise [control], compliant with [configuration] | cited result contrast, "researches on [topics] are ongoing" | single | none |
| Design D | P1 | category-opener + mechanism | The [category] derives from [parent] by [modification], see Figure [n], to improve [properties] | alternative framing, loss components vs sibling type | cluster of 3 | F5 |
| Design D | P2 | design-implication | The [geometry] plays a key role in restricting [harmonics], and thus [ripple] and [losses] | cited suggestion + figure panel, cited parameter ranking, recommendation, number, ratio rule | single ×4 | F5(b), F6 |
| Design D | P3 | design-implication | The numbers of [slots] have high impact on both [losses] and [ripple] | mechanism sentence, cited analytical evaluation, "The conclusion is that [rule A], while [rule B]" | single | none |
| Emerging | P0 | taxonomy-overview (one sentence) | Novel [technologies] for [system] have been proposed to increase [objectives] | none | none | none |
| Emerging A | P1 | category-opener + mechanism | [Technology] brings significant potential innovations: i) [item], see Figure [n]; ii) [item]; iii) [item] | enumerated benefits each cited, mechanism "is caused by the absence of [dynamics]" | single ×4 | F7 |
| Emerging A | P2 | literature-category (state of practice) | Past academic studies suggest combining [technology] with [machine types] | vendor list with table pointer, "However, all of them have yet to be [adopted]" | cluster of 2 ×2 | T3 |
| Emerging A | P3 | discussion-or-limitation + gap + research-agenda | The [system] efficiency is potentially improved by [feature]; however, [variant] tend to be less efficient than [conventional] | gap sentence, preliminary-result cite, ongoing project, challenges list | single ×4 | none |
| Emerging B | P0 | taxonomy-overview | In recent decades, several [topologies] have been proposed for [application], including [list] | none | single | none |
| Emerging B.1 | P1 | category-opener + limitation | With [feature], [topology] inherit merits of both [A] and [B], and overcome [problem] of [C] | side-effects list i)–ii) | single | none |
| Emerging B.2 | P1 | category-opener + mechanism | To overcome [restriction] owing to [cause], [topology A] and [topology B] are proposed by [means A] and [means B], respectively | expected benefit with hedge | single | none |
| Emerging B.3 | P1 | category-opener + comparison + limitation | [Topology] have drawn wide attention due to [intrinsic features] | review pointer, cited near-equality, conditional advantage, "However, [cost/reliability] should be evaluated" | single ×3 | none |
| Emerging B.4 | P1 | category-opener + gap | [Topology] have been proposed to achieve [operation mode] based on [effect] | cited topology list, unifying theory cite, gap sentence with knowledge hedge | single ×4 | none |
| Emerging B.5 | P1 | category-opener + mechanism + limitation | [Technique] were originally developed to achieve [purpose] in [type] | "However, they can also be adopted in [type] to [benefit], see Figure [n]", cited evaluation, challenges list | single ×3 | F8 |
| Conclusion | P1 | conclusion + synthesis | This literature review discussed [topics], with focus on [objective] over [conditions] | "The following aspects were highlighted:" then 8 bullets, one per section, in order | none | none |

## Summary-to-judgment turns
1. Specifications section, last paragraph: "However, these [tools] are usually generated from [steady-state data], which are incomplete for [purpose]." Backed by one citation that addresses it; moderate ("incomplete", "essential").
2. Control section P2, closing sentence: "However, in the above studies these [methods] were only [tested] in [conditions]." Backed by argument, then a cited magnitude in the next paragraph; flat, unhedged.
3. Design-methodology opener: "Thus, the conventional [methods] are not the most suitable for [application]; instead, [approach] are highly recommended." Backed by mechanism argument (operating points far from rated); strong.
4. Emerging A P3: "The literature misses a systematic [comparison] of [A] and [B]." Backed by a preliminary-result cite and an ongoing project; strong, flat.
5. Emerging B.4: "Although [cite] states that [claim], an objective [comparison] is currently missing, to the best of our knowledge." Backed only by the knowledge hedge; moderate.
Turns sit at paragraph ends, almost always opened by "However," and are followed by a cite that partially answers the judgment.

## Figure and table roles
- Data-compilation tables (T1, T3): carry "state of practice" claim; callout first ("Table [n] illustrates/presents [content]"), then narrative; pointed at, later reused as evidence via "(see Table [n])" and "including many of those in Table [n]". Table replaces prose; values never walked through.
- Targets table (T2): callout embedded mid-sentence ("[source] sets the targets in Table [n] for [scope]"); text then partially walks through targets; reused later ("according to the roadmaps in Table [n]").
- Formulation-summary table (T4): "Table [n] summarizes [variables and models] for [types]"; pointed at, then representative studies discussed; referred back to ("the [formula] in Table [n]").
- Cross-type comparison figure (F1): claim stated BEFORE callout ("[Property] is determined by [type]. Figure [n] overlays..."); interpreted type by type with a cite per type; first pointed at in the specifications section, interpreted only in the design section.
- Geometry/topology illustration figures (F2–F6): parenthetical "(Figure [n](a))" attached to nouns, or "[parameter], defined in Figure [n]"; pointed at, never interpreted; visual glossary for design options.
- Product photo figure (F7): "see Figure [n]"; pointed at only.
- Cited-result figure (F8): claim before "see Figure [n] [cite]"; one interpreting sentence.

## Introduction closing chain
- 1 paragraph (possibly 2 if the source-type note is separate); preceded by 3 context/category paragraphs, none ending with its own limitation.
- Gap form: one sentence, knowledge-hedged ("to the authors' best knowledge, no [work] comprehensively [does X]"), immediately after a single prior-review example.
- Contribution form: prose, task-worded (provides guidelines, focuses on, presents, draws), inline roman enumeration i)–iii) with "(Section n)" after each item, plus two further sections in a "Moreover, ... whilst ..." sentence; 3 focus items + 2 sections.
- Organization paragraph: absent; fused into the contribution sentence. Mapping one-to-one, contribution order = section order. No explicit back-reference to the intro categories.

## Taxonomy
- Axes: level 1 by efficiency lever (design-time geometry/materials, run-time control, design-process methodology, emerging technology); level 2 by machine type (design section), by algorithm principle (control), by computation-reduction strategy (methodology, implicit), by layout vs topology family (emerging); level 3 by topology family. Depth 3. Exclusive at every level.
- Justification: machine-type split justified by a stated claim ("[property] is predominantly determined by [type]") plus the comparison figure; control split justified via a cited review's comparison dimensions; methodology split unannounced, paragraphs open "To accelerate ..., an option is ..." / "Another method ...".
- Announcement templates: "The following sub-sections discuss [aspects] for the [n] most relevant [types], i.e., [list]." and "These methods can be classified into [n] categories: i) [type], which [feature]; ii) [type], based on [feature]; and iii) [combination]."
- No taxonomy figure/table; the cross-type comparison figure precedes the announcement by one paragraph.
- Category sections open with "[Category] are/have [status] because of [merits]; however, [restriction] [cite]", then loss-mechanism sentences, then one paragraph per design parameter. They close with a caveat ("However, [challenge]") or "[research] is ongoing"; no synthesis paragraph, no bridge.
- Cross-cutting themes (cooling, torque envelope, efficiency-map validity) are placed in the specifications section before the taxonomy; the driving-cycle theme is promoted to its own section.
- Reuse: conclusion bullets mirror the taxonomy one bullet per section; no separate comparison or future-work reuse.

## Comparison
- Dimension kinds: efficiency-region location on the torque–speed plane; dominant loss component by speed region; manufacturing ease; cost; ripple/noise; overload capability; for control methods: convergence speed, parameter dependence, accuracy; for design methods: computation time vs accuracy.
- Table introduction template: "Table [n] presents [test results] from [benchmark source] carried out for [items] [cites], as well as [available data] for [items] [cluster]."
- Trade-offs stated, no overall winner; one machine type is called an "attractive option" (hedged). Trade-off shapes: "[A] has higher [x] in [region], but lower [x] in [other region]"; "at the price of [loss]".
- Differing conditions: each cited number carries its own condition ("at [point]", "along [cycle]", "under the same specifications", "with respect to [baseline]"); no normalization across sources.
- Rubric: not observed. Feeds recommendation in the conclusion bullets ("should be selected as a trade-off between [criteria]"; "[approach] are essential").

## Research questions
n/a (none explicit).

## Results ladder
- Review mode: cited evidence reported with attribution ("In [cite] a [design] achieves [value] along [cycle]"), then a mechanism sentence ("In fact, [loss contents] differ ..."; "because of [feature]"), then a scope or design implication ("According to [cite], the benefit is negligible for [case], whereas significant for [case]"; "should", "are preferable", "is suggested").
- Observation verbs: achieves, yields, improves, reduces, increases, shows. Mechanism verbs: because of, owing to, due to, caused by, since, which in turn. Implication verbs: should, is suggested, are preferable, is recommended, is essential.
- Typically one sentence per rung; interpretation follows immediately in the same paragraph. Counter-evidence handled by "However, [benefit] can be compromised by [effect] at [condition]". Ladder ends in a design rule or a caveat.

## Future work derivation
1. [no systematic efficiency comparison of two powertrain layouts] -> [comprehensive analyses; ongoing project cited] -> traced to limitation stated in the same sub-section; repeated in a conclusion bullet.
2. [no objective efficiency comparison for one topology family] -> [comparison against other topologies] -> traced to a knowledge-hedged gap in that sub-section; not in conclusion.
3. [driving-cycle optimization is computation-heavy] -> [reduce burden while keeping accuracy; "significant work is ongoing"] -> traced to the "time-consuming" limitation in the methodology section; conclusion bullet.
4. [one machine type limited by ripple/noise/control] -> [current shaping and winding research "ongoing"] -> traced to the restriction list in its category opener; not in conclusion.
5. [novel topologies as "potentially efficient candidates"] -> nothing specified -> untraced (wish-list bullet).
Placement: last sentences of category sub-sections and inside conclusion bullets; no dedicated section; one sentence each; derived from stated gaps except item 5.

## Section endings and synthesis
- Category sections end with a caveat sentence, an ongoing-research sentence, or a cited design rule; no synthesis paragraph, no bridge to the next category.
- Final synthesis = conclusion bullet list, one takeaway per section in section order; categories related only by trend statements ("the general recent trend is toward [type]") and two "missing/ongoing" agenda statements; no ranking table.

## Language signals
- Register: "this survey", "this literature review", "the paper", "the authors' best knowledge" (one "our knowledge"); never "we". Present tense for state of art and cited findings, past for cited implementations and in the conclusion lead; passive for cited work ("is presented in [n]", "are summarized in [n]", "are reviewed in [n]") alternating with citation-as-subject actives ("Reference [n] suggests/shows/proposes", "The authors of [n] added", "The study in [n] evaluates"). No authors named in prose; organizations and product names named instead. Formal, heavy "i.e./e.g." and inline roman enumeration. Sentence length mean ~27 words, spread ~8–55. Paragraph length 5–10 sentences (main), 2–4 (topology sub-sub-sections), 1–3 per conclusion bullet.
- Section openers: Abstract: "[Market trend] is going to increase; however, [limitation] remains; hence [industry effort]" then "This literature survey reviews [X]". Intro: "[Drivers] are making [technology] increasingly competitive for [use]". Requirements: "Several [agencies] have analyzed [trends] in terms of [performance]". Taxonomy intro: "[Property] is predominantly determined by [factor]". Category: "[Category] are widely investigated for [application] because of [merits]". Control: "On [platform], [component] needs to output [requirement] at [condition]". Methodology: "Conventional [methods] focus on [rated condition], especially for [steady applications]". Emerging: "Novel [technologies] have been proposed to increase [objectives]". Conclusion: "This literature review discussed [topics], with focus on [objective]".
- Gap/limitation shapes: "there are no [published works] that comprehensively [do X]"; "The literature misses a systematic [comparison]"; "an objective [comparison] is currently missing"; "were only [tested] in [conditions]"; "[benefit] can be compromised by [effect]"; "these designs imply [tight tolerances]"; "pose [manufacturing challenges]"; "have yet to be [adopted]"; "Challenges remain with respect to [requirements]". Verbs: misses, is missing, there are no, were only, can be compromised, pose, remain, should be carefully evaluated. "However" opens roughly one sentence per two paragraphs; nearly every category paragraph carries one caveat.
- Contribution phrasing: task-worded prose with inline i)–iii) and "(Section n)" pointers; verbs provides, focuses on, presents, draws; abstract uses "the review discusses [list]" and "Moreover, the paper covers: i) ...; and ii) ...".
- Transitions: However (~20), Therefore (~8), Moreover (~6), Besides (~3), In this respect (~3), In particular (~3), In fact (~2), Thus (~2), Furthermore (1), Vice versa (1), On the other hand (1), In this context (1), whilst (2); attribution openers "According to [n]", "As discussed/stated/pointed out in [n]" (~8). Paragraphs mostly content-linked by a topic noun ("The [parameter] ...", "The [component] ..."); connective-linked only in the methodology section ("To accelerate ...", "Another method ...").
- Hedging: "tend to", "generally", "typically" for cross-type comparisons; "potentially", "can be expected", "may be compromised" for emerging-topology promise; "to the authors' best knowledge" for gap claims. Cited numbers stated flat with attribution and condition. Design rules stated flat as recommendations ("should", "are preferable", "is suggested").
- Callout templates: tables "Table [n] illustrates/presents/summarizes [content] of/for [scope]", "[source] sets the targets in Table [n]", "(see Table [n])"; figures "Figure [n] overlays [content] for [types] [cite]", mid-sentence ", see Figure [n],", parenthetical "(Figure [n](a))", "[parameter], defined in Figure [n],"; equations: not observed (inline symbols only).
- Comparison shapes: "[A] tend to have higher [x] than [B], and thus are becoming [attractive] [cite]"; "In comparison with [A], [B] are easier to [do] and have lower [loss] at [condition], because of [feature]"; "Compared with [baseline], the [method] in [cite] improves [metric] by [value] at [condition]"; "[A] has higher [x] in [region], but lower [x] in [region] [cite]"; "[method] reduces [time] by up to [magnitude] with respect to [baseline]"; "[A] yields [max] at [condition] than [B] designed under the same specifications".
- Conclusion shape: one scope sentence + "The following aspects were highlighted:" + 8 bullets (trend, trend, targets, design rules, control trade-off, methodology need, layout trade-off + gap, novel candidates); no closing sentence; no separate future work.
- Generic connective phrases: "In this respect,"; "To the authors' best knowledge,"; "to the best of our knowledge"; "In comparison with"; "with respect to"; "under the same specifications"; "at the price of"; "In this context,"; "As discussed in [n],"; "which in turn".

## Roles shown
- intro-context: 2
- literature-category: 2
- limitation: 3 (embedded as paragraph-closing sentences, no standalone paragraph)
- gap: 3 (embedded; one in Intro, two in emerging section)
- approach-and-contributions: 1 (fused with gap and organization)
- contribution-list: 0 standalone (inline enumeration inside the approach paragraph)
- research-questions: 0
- organization: 0 standalone (fused)
- method-objective: 0
- model-or-assumption: 2
- mechanism: 6
- design-implication: 9
- setup: 0
- results: 1 (cited evidence, not own)
- comparison: 3
- discussion-or-limitation: 3
- conclusion: 1
- abstract: 1
- caption: present but inlined; descriptive "[Content] of [items] (adapted from [n])"
- taxonomy-overview: 4
- category-opener: 10
- cross-cutting-comparison: 1
- synthesis: 1 (conclusion bullets only)
- research-agenda: 0 standalone (embedded in 3 paragraphs)
