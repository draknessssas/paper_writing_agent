# Skeleton: Sensorless_IM_drives
- Title: "Sensorless Control of Induction Motor Drives"; venue: Proceedings of the IEEE, vol. 90, no. 8 (Invited Paper); year: 2002
- Type: large review (strong tutorial character). Evidence: a taxonomy figure announced in the Introduction organizes the section sequence; every cited method is re-derived in the author's own notation and signal-flow-graph representation before its reported performance is attached; the closing section compares methods on a two-axis chart.
- Approximately 75 extracted page-chunks, roughly 150 real paragraphs by sentence density; taxonomy figure/table [y: one tree figure]; comparison tables [n: one comparison chart, no tables]; explicit RQs or hypotheses [n: one rhetorical question inside a fundamentals subsection]; future-work section or paragraph [n: one outlook sentence closing the summary]
- Extraction damage: the file DOES contain "## " headings, but section numerals are stripped, several subsection titles are split mid-title with the tail starting the next block, run-in numbered items are promoted to headings, figure captions and page headers are inlined mid-paragraph, equations survive only as "(n)" markers, real paragraph breaks are lost (blocks are page-sized), and one internal figure cross-reference is off by one (original or extraction).

## Section list
(numerals inferred from in-text cross-references such as "Section VII-D"; sub-items marked 1)–4) are run-in headings)
- Abstract; Keywords; Nomenclature
- I. Introduction
- II. Induction Machine Dynamics: A. Space Vectors; B. Machine Equations; C. Stator Current and Rotor Flux as State Variables; D. Speed Estimation at Very Low Stator Frequency; E. Dynamic Behavior of the Uncontrolled Machine
- III. Constant V/Hz Control: A. Low Cost and Robust Drives; B. Drives for Moderate Dynamic Performance
- IV. Machine Models: A. The Rotor Model; B. The Stator Model
- V. Rotor Field Orientation: A. Principle; B. MRAS Based on Rotor Flux; C. MRAS Based on Induced Voltage; D. Feedforward Control of Stator Voltages; E. Improved Stator Model; F. Adaptive Observers (1) full-order, 2) sliding mode, 3) Kalman, 4) reduced-order)
- VI. Stator Field Orientation: A. Impressed Stator Currents; B. Dynamic Decoupling; C. Speed Estimation Based on Rotor Slot Harmonics
- VII. Performance of the Fundamental Model at Very Low Speed: A. (opening, heading lost); B. Data Acquisition Errors; C. PWM Inverter Model (with parameter identification sub-item); D. Stator Flux Estimation; E. Stator Resistance Estimation; F. Low-Speed Performance by Improved Models; G. Low-Speed Estimation by Field Weakening
- VIII. Sensorless Control Through Signal Injection: A. Anisotropies; B. Signal Injection; C. Revolving Carrier (1) speed/position estimation); D. Alternating Carrier (1) quadrature impedances, 2) elliptic trajectories); E. PWM-Switching Excitation (1) INFORM, 2) instantaneous rotor position)
- IX. Summary and Performance Comparison (serves as conclusion)
- Appendix: Normalization; References (37 entries); author biography

## Paragraph map
(Para numbers are inferred real paragraphs, not the extractor's blocks.)
| Section | Para | Function | First-sentence template | What follows the claim | Citation pattern | Figures/tables referenced |
|---|---|---|---|---|---|---|
| I | 1 | intro-context | "[Technology class] has reached the status of [maturity]." | number+condition (market size), then research-trend sentence | single | none |
| I | 2 | intro-context (motivation) | "The advantages of [sensorless variant] are [benefit list]." | example (application that forces the need) | none | none |
| I | 3 | approach-and-contributions + taxonomy-overview | "A variety of [solutions] for [problem] have been proposed." | figure/table callout (taxonomy figure) | none | Fig. 1 |
| I | 4 | literature-category (embedded limitation) | "A basic [approach] requires only [algorithm] to make [sensor] obsolete." | mechanism sentence; closes with limitation clause | none | none |
| I | 5 | literature-category (embedded gap) | "[High performance] is achieved by [method], also called [alias]." | mechanism sentence; difficulty statement; figure callout; sub-split | none | Fig. 1 (lower portion) |
| I | 6 | organization | "Discussing [topic] requires an understanding of [prerequisite], treated in [first section]." | none | none | none |
| IV | 1 | method-objective | "[Models] are used to estimate [quantity A] and to identify [quantity B]." | mechanism sentence (how the model runs in real time) | none | none |
| IV | 2 | model-or-assumption / limitation | "The accuracy of [model] depends on [degree of match]." | mechanism sentence (parameters drift with [condition]) | none | none |
| IV | 3 | model-or-assumption (notation) | "[Representations] are used in this paper to represent [dynamics]." | none (convention note) | none | none |
| IV | 4 | category-opener | "Suitable [models] for [task] are [model A] and [model B]." | figure callout; "each has merits and drawbacks" | none | Figs. 10, 11 |
| IV-A | 1 | mechanism | "[Model] is derived from [governing equation]." | equation, then figure callout walked through | none | Fig. 10 |
| IV-A | 2 | discussion-or-limitation | "The accuracy of [model] depends on [parameter settings] in ([eq])." | mechanism sentence (which parameter matters, why) | none | Fig. 10 |
| IV-B | 1 | method-objective | "[Model] is used to estimate [quantity], without requiring [signal]." | equation chain, figure callout | none | Fig. 11(a) |
| IV-B | 2 | limitation + mechanism (remedy) | "[Model] is difficult to apply in practice since [error accumulation]." | mechanism sentence; remedy; equation | none | Fig. 11(a),(b) |
| IV-B | 3 | limitation | "The decisive parameter of [model] is [parameter]." | number+condition (parameter range) | none | Fig. 11 |
| IV-B | 4 | synthesis | "To summarize, [model] is [adequate] at [condition]." | two-item deficiency list; number+condition (lower limit) | none | none |
| V-F | 1 | category-opener (limitation of prior class) | "The accuracy of [prior method class] reduces as [condition] reduces." | mechanism sentence; remedy claim | none | none |
| V-F | 2 | mechanism (item 1) | "A [observer type] can be constructed from [machine equations]." | equation; figure callout; named-author design choice; ends number+condition "is reported" | named-author single | Fig. 21 |
| V-F | 3 | mechanism (item 2) | "The effective [gain] can be increased by using [controller type]." | "This method is proposed by [Authors] [n]"; figure callout; ends number+condition | named-author single | Fig. 22 |
| V-F | 4 | mechanism + discussion-or-limitation (item 3) | "[Technique] are based on [complete model], which is [structure in Fig. n]." | mechanism; named-author experimental note; flat judgment on computational cost | single, then named-author single | Figs. 21, 5 |
| V-F | 5 | mechanism (item 4) | "[Authors] et al. [n] use a [observer type] for [task]." | figure callout; equation; property claim with citation | named-author single | Fig. 23 |
| IX | 1 | synthesis (category A) | "A large variety of [schemes] are used in [industrial context]." | mechanism sentence; trade-off (robustness vs dynamics) | none | none |
| IX | 2 | synthesis (category B) | "[High-performance schemes] require [estimator] to identify [quantity]." | mechanism; number+condition (achievable range) | none | none |
| IX | 3 | synthesis (bounded claim) | "[Operation at limit condition] can be established even when using [model], provided that [conditions]." | condition clause; "however" limitation (observability) | none | none |
| IX | 4 | synthesis + design-implication | "[Steady-state metric] depends on [parameter adjustment]." | mechanism; cost-driven preference sentence | none | none |
| IX | 5 | comparison | "The graph in Fig. [n] gives a comparison of [methods] in terms of [metric A] and [metric B]." | figure callout; caveat on differing test conditions; scope restriction | none (refers to "cited references") | Fig. 66 |
| IX | 6 | synthesis (category C) + research-agenda | "Improved [performance] can be achieved by exploiting [physical property]." | mechanism sentence; outlook sentence | none | none |

## Summary-to-judgment turns
1. End of IV-B: marker "To summarize, [model] is [adequate] at [condition]. Two basic deficiencies let [model] degrade as [condition]: [A] and [B]." Backed by the preceding mechanism argument plus a number+condition. Flat, unhedged.
2. Last sentence of VIII-C: marker "Current publications on [method class] show that [side effects] require [processing] to get more involved, while [dependence] persists." Backed by the walkthrough of three or four singly cited papers. Strong, no hedge; closes the category section.
3. Opener of VIII-D-2: marker "The [methods] described so far suffer from certain drawbacks. We have [drawback A] of [class A] and [drawback B] of [class B]." Backed by earlier subsections' own statements. Strong; functions as a bridge into the next method.
4. End of V-F item 3: marker "[Technique] are generally avoided due to [cost]." Backed by one named-author implementation note. Flat generalization.
5. End of VIII-D-1: marker "Measured characteristics from [machine] show that [difference] is small when [condition] [n]." then "It is therefore preferable to restrict [use] to [condition], as demonstrated in [n]." Backed by the cited paper's curves and an oscillogram. Moderate ("may not be guaranteed"), then a recommendation.

## Figure and table roles
- Taxonomy tree (1 figure): carries the field map; announced in the Introduction, then walked branch by branch in the same paragraphs; interpreted.
- Signal flow graphs (about 30): mechanism illustration and the paper's primary argumentative device; the equation (claim) comes before the callout, then the graph is walked region by region ("upper portion", "shaded area", "left-hand side"); heavily interpreted.
- Physical sketches and vector diagrams (about 10): mechanism; pointed at with "as shown in Fig. [n]" then explained.
- Oscillograms and measured traces (about 18): evidence for a result at a condition; claim stated before the callout ("The oscillogram in Fig. [n] demonstrates [performance] at [condition]"); traces read one by one; anomalies explained by a secondary mechanism.
- Characteristic curves, Bode plot, spectra (about 5): evidence for a mechanism claim; interpreted with a judgment attached.
- Performance comparison chart (1): summary of the field on two axes; claim and caveat stated before the callout; pointed at, not walked through; no individual method discussed.
- Tables: not observed in the body (nomenclature list and normalization appendix only). Captions are extracted inline and carry the operating conditions.

## Introduction closing chain
- Chain length: 4 of about 6 paragraphs (approach/taxonomy announcement -> category -> category -> organization).
- Gap form: accumulated implicitly; each category paragraph ends with a limitation or difficulty clause; no explicit gap sentence and no "no prior review" move.
- Contribution form: prose, task-worded, one item (review of merits and limits from a literature survey); the abstract adds the representational device as a second, method-worded contribution; not numbered.
- Organization paragraph: one sentence; points only to the next (fundamentals) section; no section-by-section roadmap.
- Mapping to sections: implicit, through the taxonomy figure's branches, which become Sections III, IV-VI and VIII; the chain refers back to categories via "the lower portion of Fig. [n]".

## Taxonomy
- Axes (3 kinds): by control principle / required dynamic performance (open-loop scalar vs closed-loop vector control); by orientation reference (which flux quantity the control frame aligns to); by estimation mechanism (open-loop model vs closed-loop observer; fundamental-wave model vs parasitic-effect / anisotropy methods). Depth 3, plus run-in numbered items as a fourth level.
- Justification: axis 1 by performance requirement; the fundamental-vs-anisotropy split by an observability argument the author derives himself in the fundamentals section; axis 2 with "each method has its own merits".
- Exclusive tree, not a matrix. Cross-cutting themes (parameter adaptation, inverter nonlinearity, data-acquisition errors, low-speed limits) get a separate theme-organized section placed between the model-based branches and the anisotropy branch.
- Announcement template: "Fig. [n] gives a schematic overview of the [methodologies] applied to [problem]." Figure sits in the Introduction at the announcement and is walked through immediately.
- Category sections open with a definitional sentence tied back to the figure ("It is one of [k] basic subcategories of [parent] shown in Fig. [n].") or with the limitation of the previous category; they close with a reported performance number at a condition from the cited source, or a one-sentence judgment.
- Reuse: the summary walks the branches in taxonomy order; the comparison chart's scope is defined by a branch ("excluding [branch]"); the outlook points at the newest branch.

## Comparison
- Dimension kinds: chart uses a dynamic-response metric vs a low-speed operating limit; qualitative dimensions across the text: parameter sensitivity/robustness, computational load and hardware cost, signal-to-noise ratio, commissioning effort, steady-state accuracy, application fit.
- Introduction template: "The graph in Fig. [n] gives a comparison of [methods] in terms of [metric A] and [metric B]."
- Trade-offs stated throughout; no winner declared; the nearest verdict is the outlook sentence on the newest branch.
- Differing conditions: explicit caveat "The data are taken from [cited references]; [results] should be considered approximate, since [test conditions] may differ." plus a scope restriction "Only methods that use [model class] are compared."
- Rubric: not observed.
- Feeds recommendation: a cost/implementability preference sentence in the summary; application-specific fits stated inside category sections (template "[Method] is adequate for [applications] and tolerable for [others] if [condition]").

## Research questions
- Explicit RQs: not observed. One rhetorical question in a fundamentals subsection: "if [condition], can [quantity] be detected without [sensor]?"
- Answered in the same subsection by derivation, marked "It is concluded, therefore, that [quantity] is not observable at [condition]."; the answer then licenses a whole taxonomy branch via the forward reference "Details are discussed in Section [n]."
- Cross-reference forms: "(see Section [n])", "(Section [n])", "Details are discussed in Section [n]." Results section does not restate any question.

## Results ladder
- Review pattern: derive mechanism (equation chain + signal flow graph) -> state consequence -> attach the cited paper's number at a condition with attribution -> judgment or limitation. Interpretation precedes evidence.
- Observation verbs: "shows", "demonstrates", "exhibits", "is reported", "can be observed", "is achieved". Mechanism verbs: "is owed to", "is caused by", "the reason is that", "results from", "originates from", "depends on".
- Attribution of cited numbers: "is reported to operate at [value] [n]", "The authors have operated the system at [value]", "[Performance] is reported by [Author] above [value] [n]". Own-group evidence: oscillogram with "demonstrates".
- Anomaly handling: a secondary mechanism sentence ("The overshoot of [trace] is a secondary effect which is owed to [absence of adjustment]").
- Ladder ends with a bounded claim carrying a condition ("provided that", "unless [condition]") or an application recommendation.

## Future work derivation
- [fundamental-model observability fails at the limit condition] -> [exploit physical anisotropies; methods have "recently emerged"] -> traced to the limitation derived in the fundamentals section and restated in the summary. Placement: final sentence of the summary. Derived, one sentence.
- [data-acquisition errors currently masked by drift] -> [will "require more attention" as flux-integration solutions evolve] -> traced to a limitation with a forward reference. Placement: mid-body cross-cutting subsection.
- [side effects of one carrier-injection class keep growing; commissioning dependence "persists"] -> no remedy stated -> traced to a taxonomy cell's limitation. Placement: category-section end.
- No future-work section, no list; items are single sentences scattered at section ends; not a wish list, each is tied to a stated limitation.

## Section endings and synthesis
- Category sections end with (a) a reported performance number at a condition from the cited source, or (b) a one-sentence limitation or trade-off; a full synthesis paragraph appears only twice ("To summarize, ..." and the "Current publications ... show that" closer), plus a cost/application-fit paragraph ending the open-loop category.
- Final synthesis walks the branches in taxonomy order, one paragraph each with its trade-off, embeds the only comparison chart with a conditions caveat, and relates categories by performance envelope (operating range vs dynamics) and cost/implementability; closes with the newest branch as outlook. No limitations-of-this-review paragraph.

## Language signals
- Register: third person; "this paper" for self-reference; "we" only inside derivations ("we have ([n])", "we obtain"), never "we propose"; named authors as grammatical subjects for cited methods ("[Author] et al. [n] select/use/propose"). Present tense, passive dominant ("is derived", "is obtained", "is reported"); active with inanimate subjects ("Fig. [n] shows", "The equation shows that"). Formal, textbook-like. Sentence length mean about 20 words, spread 8 to 40, with frequent short declaratives ("The result is ([n])."). Real paragraphs 4 to 8 sentences; derivation paragraphs longer.
- Section openers: Introduction "[Technology class] has reached the status of [maturity]."; fundamentals "The use of [representation] is an efficient method for [modeling task] [n]."; category "Control with [category] is preferred in combination with [model]."; named-author method subsection "In the approach of [Author] et al. [n], [quantity] are derived from [model] and used as [role]." / "A [scheme] based on [model] is described by [Author] [n]."; problem-driven subsection "As [signal level] reduces at [condition], [error class] become significant [n]."; results-demo subsection "The oscillogram in Fig. [n] demonstrates [performance] at [condition]."; summary "A large variety of [schemes] are used in [context]."
- Gap/limitation shapes: "is difficult to apply in practice since [mechanism]"; "suffer from certain drawbacks"; "constitutes a basic limitation for [method class]"; "is not observable at [condition]"; "becomes necessarily inaccurate below [condition]"; "is lost at [condition]"; "are generally avoided due to [cost]"; "is not suited for [task] owing to [property]"; "may not be guaranteed for every [device]"; "Although [system] has [components], [property] is not established. The reason is that [mechanism]." Proportion: nearly every method subsection carries one limitation sentence, stated flat and followed by a mechanism rather than a hedge.
- Contribution phrasing: prose, one task-worded sentence in the Introduction; abstract states the representational device ("The overview in this paper uses [tool] to provide [description]"); no numbered list.
- Transitions: "therefore" and "hence" very frequent (hence mostly before equations); "however" moderate; distinctive frequent forms "Against this,", "Other than [X],", "In fact,", sentence-initial "Also,", "Note that", "Particularly,", "The reason is that" (about six times); rarer "Still,", "Even so,", "In total,", "Reversely,", "Likewise", "Different from that,", "To summarize,". Anaphoric "Such [noun]" / "This [noun]" linkers are the dominant paragraph glue; paragraphs link by content (equation chains, figure regions) far more than by connectives; subsection openers link by naming the previous method's limitation.
- Hedging: "may" for possible effects and unproven generality; "can be" for capability claims; attribution ("is reported", "The authors have operated") as the hedge on cited numbers; "should be considered approximate, since [conditions] may differ" on the comparison chart; "bear great promise" for outlook. Flat: physics derivations ("It is obvious that", "One can see from"), limitations, and general judgments ("are generally avoided").
- Callout templates: figure "The resulting [diagram] is shown in Fig. [n]." / "Fig. [n] shows that [claim]." / "An inspection of Fig. [n] shows that [claim]." / "[claim], as illustrated in Fig. [n]." / "(see Fig. [n])" / "The [upper portion / shaded area / left-hand side] of Fig. [n] shows [element]."; equation "[Step] yields ([n])" / "from which ([n]) is obtained." / "The result is ([n])." / "Equation ([n]) can be directly verified from [figure]." / "The right-hand side of ([n]) is independent of [variable], indicating that [claim]."; table: not observed.
- Comparison sentence shapes: "[Method] ensures [property] at the expense of [property], which is adequate for [applications] and tolerable for [others] if [condition]."; "[Error] may be even higher than with those methods that [do X]."; "Other than in [method A], there are no [component] that create [limit]."; "[Structure B] is less straightforward than its equivalent at [A], although well interpretable."; "A faster algorithm relies on [principle] [n]."; conditions attached as "at [speed]", "above [frequency]", "at rated load", "when [saturation condition]".
- Conclusion shape: single summary-and-comparison section; no restatement of contributions; branch-by-branch trade-off paragraphs in taxonomy order; one comparison chart with a conditions caveat; closes with the newest branch as outlook; no explicit future-work list and no self-limitations paragraph.
- Generic connective phrases: "depending on the problem at hand"; "to summarize,"; "the reason is that"; "against this,"; "other than in"; "as shown in Fig."; "provided that"; "as the speed reduces"; "in a practical implementation"; "is reported to operate at".

## Roles shown
- intro-context: 2
- literature-category: 2 (Introduction branches, each with an embedded limitation clause)
- limitation: about 15 (embedded in method subsections)
- gap: not observed as a standalone paragraph (implicit clauses inside 2 category paragraphs)
- approach-and-contributions: 1 (plus abstract)
- contribution-list: not observed
- research-questions: not observed (1 rhetorical question in a fundamentals subsection)
- organization: 1 (one sentence)
- method-objective: about 6
- model-or-assumption: about 4
- mechanism: about 40 (dominant role)
- design-implication: about 6
- setup: about 2 (implementation-detail paragraphs)
- results: about 8 (oscillogram paragraphs)
- comparison: 1 paragraph plus scattered comparative sentences
- discussion-or-limitation: about 10
- conclusion: 1 section, about 6 paragraphs
- taxonomy-overview: 1 (spread over 3 Introduction paragraphs)
- category-opener: about 9
- cross-cutting-comparison: 1 section, about 8 paragraphs (theme-organized low-speed section)
- synthesis: about 4
- research-agenda: 1 sentence only (thin)
