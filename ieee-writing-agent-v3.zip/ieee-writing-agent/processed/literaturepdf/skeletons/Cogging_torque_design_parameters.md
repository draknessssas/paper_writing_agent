# Skeleton: Cogging_torque_design_parameters
- Title: Influence of Design Parameters on Cogging Torque in Permanent Magnet Machines; venue: IEEE Transactions on Energy Conversion, Vol. 15, No. 4; year: December 2000
- Type: research article. Evidence: single-topic analytical parametric study; sections are named by design parameter, each built from equation(s) plus parametric figures; no survey structure, no taxonomy, no method comparison table.
- Approximate paragraph count: ~18 body paragraphs (inferred; see damage note) plus abstract; taxonomy figure/table [n]; comparison tables [n]; explicit RQs or hypotheses [n]; future-work section or paragraph [n]
- Extraction damage: paragraphs merged into page-sized blocks (boundaries below are inferred from content); all equations and inline symbols dropped, leaving "(n) where , is" gaps; figure captions, table titles, page headers, copyright/download notices and the manuscript-received footnote are inlined mid-sentence; table bodies dropped (titles only); author line parsed as a heading; section numerals lost; conclusion split across a page break.

## Section list
1. Abstract (in Front Matter)
2. Introduction
3. Analysis Techniques
4. Choice of Slot and Pole Number Combination
5. Use of Auxiliary Teeth and Slots
6. Optimal Magnet Pole-Arc
7. Skewing
8. Stator Slot Opening
9. Conclusion
10. References (followed by author biographies)
Flat structure: no subsections anywhere.

## Paragraph map
Paragraph numbers are inferred logical paragraphs, not the extractor's page blocks.

| Section | Para | Function | First-sentence template | What follows the claim | Citation pattern | Figures/tables referenced |
|---|---|---|---|---|---|---|
| Introduction | 1 | intro-context (definition, manifestation, motivation) | "[Phenomenon] results from the interaction of [source A] and [source B] due to [cause]" | mechanism sentence (how it manifests, what it costs), then a motivation sentence carrying the cluster | cluster of 4 | none |
| Introduction | 2 | approach-and-contributions (objective and scope) | "In the paper, the effect of [parameter] on [quantity] is investigated, and its relationship with [other parameters] is considered, with respect to [machine class]" | none (parameter list in prose, scope clause) | none | none |
| Analysis Techniques | 1 | mechanism | "[Quantity] is produced predominantly as a result of [mechanism] [ref], a typical [waveform] being shown in Fig. [n]" | figure callout, then mechanism sentences (stable vs unstable positions, where extrema occur) | single | Fig. 1 |
| Analysis Techniques | 2 | literature-category + limitation (calculation methods and their demands) | "[Quantity] can be calculated analytically or numerically in a variety of ways, such as by [method A] and [method B]" | limitation sentence with cluster, then restatement ("In other words, [requirement A] ... whilst [requirement B] ...") | cluster of 3 (includes self) | none |
| Analysis Techniques | 3 | model-or-assumption (own prior model, its assumption, capability list; method-objective clause) | "The authors have employed a variety of [technique class] to predict [quantity] in [machine class] [self-ref]" | self-citation, assumption clause ("albeit with the assumption of [simplification]"), self-assessment, enumerated list a)–f) | named-self single | none |
| Analysis Techniques | 4 | setup + validation | "Throughout, the calculations are for [machine type] in which [dimensions] are [values]" | number+condition (geometry, material property), then figure callout (analytical vs numerical vs measured) | none | Fig. 2 |
| Slot/pole combination | 1 | model-or-assumption (general expression) | "[Quantity] can be expressed in the general form: ([n]) where [symbol] is [definition]" | equation, second equation with symbol definitions | none | none |
| Slot/pole combination | 2 | mechanism, then indicator introduced | "In general, the larger [quantity A] and the smaller [quantity B], then the smaller will be [output]" | equation (indicator definition), then hedged empirical statement | none | none |
| Slot/pole combination | 3 | results (assumption, callout, observation, mechanism) | "In order to demonstrate the influence of [parameter] on [quantity], it is assumed that [assumption]" | figure/table callout, flat observation ("It is obvious, from both ..."), mechanism sentence ("This is due to the fact that ...") | none | Fig. 3, Fig. 4, Table I |
| Slot/pole combination | 4 | results, then design-implication | "Fig. [n] shows the variation of [quantity] with [parameter] for [machine type], Table [m] shows the variation of [factor] with [parameter]" | callout, observation ("It will be noted that ..."), mechanism ("the reason for this is obvious, in that ..."), implication ("Thus, [option] is preferable for [goal]") | none | Fig. 5, Table II |
| Auxiliary teeth/slots | 1 | design-implication | "A knowledge of [finding] makes it possible to reduce [quantity] by introducing [design feature] [ref], Figs. [n] and [m]" | figure callout (pointed only), then a design rule ("However, [count] should always be chosen so as to [goal]") | single | Figs. 6, 7 |
| Magnet pole-arc | 1 | model-or-assumption, then design-implication | "[Parameter] is a particularly important parameter in regard to [quantity], and it has been found that, when [simplification], the optimum [ratio] is: ([n])" | equation, practical correction with second equation, number+condition ("typically ranges ... depending on [parameter]"), implication ("Hence, in practice [value] is usually the preferred value") | none | none |
| Magnet pole-arc | 2 | results | "Equation ([n]) shows that the optimal [ratio] depends on [parameter]" | example cases, table callout, figure callout, two "It should be noted" observations, model caveat reconciling table and figure | none | Table III, Fig. 8, Fig. 9 |
| Magnet pole-arc | 3 | discussion-or-limitation (scope qualification) | "Obviously, the larger [factor] then the greater [count of optima], while, as described earlier, the higher [factor] the larger [quantity]" | qualification sentence ("Of course, the choice of [parameter] also depends on [other performance factors]") | none | none |
| Skewing | 1 | model-or-assumption (known technique, condition from equations) | "It is well-known that [technique] can reduce [quantity], as will be obvious from ([n]) and ([m])" | contrast with common practice, condition equation, optimal-value equation | none | none |
| Skewing | 2 | results (worked examples) | "For example, for [case] the only optimal [parameter] is [value], since [condition]" | three worked cases, figure callout ("This is illustrated in Figs. [n] and [m], which show ..."), observation ("It will be noted that ...") | none | Figs. 10, 11 |
| Slot opening | 1 | results | "[Parameter] can also have a significant effect on the level of [quantity]" | figure callout ("For example, Fig. [n] shows the variation of ..."), observation with ratio comparison, closing rule ("Again, it is evident that ...") | none | Fig. 12 |
| Conclusion | 1 | conclusion | "Certain [parameters] can have a very significant effect on [quantity], in particular [parameter]" | per-parameter findings in section order; indicator restated as a selection aid ("It can, therefore, be used to aid ..."); ends "It has been found that ... while ..." | none | none |

## Summary-to-judgment turns
1. Analysis Techniques, para 2, mid-paragraph. Marker: "However, they require [demanding condition] [refs], particularly for [target]" followed by "In other words, [requirement A] is required in [method A], whilst [requirement B] is essential to [method B]". Backing: cluster of 3 (including self-citations). Strength: moderate-strong (require, essential).
2. Analysis Techniques, para 3, last sentences. Marker: "It provided a very reliable [tool] for predicting [quantity], and underpins [this investigation]". Backing: self-citation plus the validation figure in the next paragraph. Strength: strong, unhedged self-assessment.
3. Slot/pole combination, para 2, end. Marker: "Although there is no formal basis for [relation], it has been found that [trend]". Backing: own calculations shown in the following figures. Strength: explicit hedge, then confident.
4. Slot/pole combination, paras 3–4, after each callout. Marker: "It is obvious, from both Fig. [n] and Table [m], that [claim]" and "Again, the reason for this is obvious, in that [mechanism]", closing with "Thus, [option] is preferable for [goal]". Backing: figure and table read jointly, then a mechanism sentence. Strength: strong, flat certainty adverbs.
5. Skewing, para 1. Marker: "Although it is common practice to [do X], ([n]) and ([m]) indicate that this is not always essential, since [reason]". Backing: the two governing equations. Strength: moderate (not always essential).

## Figure and table roles
- Mechanism-illustration figure (typical waveform): carries the claim about where the quantity vanishes and peaks; claim stated first, callout as a participial tail of the same sentence; interpreted (positions explained physically).
- Validation figure (analytical vs numerical vs measured): carries the model-credibility claim; claim asserted in the preceding paragraph, callout after; merely pointed at ("are shown in Fig. [n]"); no interpretation and no numbers in text.
- Topology and design-feature illustration figures: no claim; pointed at as appositives ("..., Fig. [n]" / "..., Figs. [n] and [m]"); never interpreted.
- Parametric-variation figures (quantity vs one parameter for several cases): carry the main results; callout first, claim after ("It is obvious / It will be noted / It is evident"); interpreted through mechanism and implication; typically read jointly with a factor table ("from both Fig. [n] and Table [m]").
- Waveform-effect figures: carry secondary observations; callout first, one "It should be noted" observation after; lightly interpreted.
- Indicator-value tables (factor per case): evidence for the trend; introduced "as shown in Table [n]" or "Table [n] shows the variation of ..."; walked through jointly with the paired figure; bodies lost in extraction.
- Optimal-value table: carries equation outputs for example cases; "are given in Table [n]"; followed by a caveat reconciling table values against figure values via a model assumption.
- Totals: 12 figures, 3 tables; no taxonomy figure; no comparison table.

## Introduction closing chain
- Paragraph count: 1 (the Introduction has 2 inferred paragraphs; the second is the whole chain).
- Gap form: not observed as a gap. Motivation is a standing design goal stated in one sentence with a cluster of 4; no prior-work categories; no limitation of prior work inside the Introduction (the method limitation is deferred to the technique section).
- Contribution form: prose, task-worded ("is investigated", "is considered"), one sentence; one objective plus an enumerated list of related parameters and a scope clause; no count. The abstract gives the result-worded version ("It is shown that ...", "[indicator] has been introduced to indicate ...").
- Organization paragraph: not observed.
- Mapping to sections: each enumerated parameter becomes one section heading, though not in the listed order; the capability list in the technique section (items a–f) is broader than the sections that follow.

## Taxonomy (reviews only; else "n/a")
n/a (research article).

## Comparison
n/a as a method comparison: no comparison table, no rubric. Design-option comparisons occur inside results paragraphs only: dimension kinds are geometric parameter, winding-topology class, parity of a count, and slot/pole combination; conditions handled by "similar [machine]", "equivalent [machine]", and "assuming that the other [parameters] remain constant"; one trade-off stated (maximize one quantity vs minimize another, resolved with "as high as possible ... usually the preferred value"); winners declared elsewhere ("is preferable", "should always be chosen so as to"); comparisons feed direct design recommendations.

## Research questions
n/a. Not explicit. The Introduction objective sentence ("the effect of [X] on [Y] is investigated") acts as the implicit question; each parameter is answered in its own section; the conclusion restates findings per parameter in section order; no forward cross-references, only back-references ("as described earlier", "Again").

## Results ladder
- Rungs and lengths: observation 1–2 sentences; mechanism 1 sentence; implication 1 sentence. Full three-rung ladder in 2 of 5 results paragraphs; 2 end at observation; 1 ends at a model caveat.
- Observation verbs: shows, variation, increases, reduces, exhibit, undergoes, "will be noted", "is evident", "is obvious".
- Mechanism markers: "This is due to the fact that", "the reason for this is obvious, in that", "since", "due to the periodicity of".
- Implication markers: "Thus, [option] is preferable", "Hence, in practice [value] is usually preferred", "should always be chosen so as to", "Again, it is evident that [low factor] always results in [low quantity]".
- Interpretation placement: immediately after the callout, same paragraph; order callout, observation, mechanism, implication.
- Anomaly handling: table-vs-figure discrepancy attributed to a model assumption ("since the results in Fig. [n] are derived from a [model] which accounts for [effect], ... slightly higher than ... Table [m], which assumes [simplification]"); a waveform change is flagged with "It should be noted" and not explained; the indicator's lack of formal basis is conceded once.
- Ladder ends: a design preference, or a scope qualification ("Of course, the choice ... also depends on [other factors]").

## Future work derivation
not observed. No future-work item anywhere; the conclusion restates findings only, without limitations or next steps. [NEED: future-work pattern from another paper]

## Section endings and synthesis (reviews only; else "n/a")
n/a.

## Language signals
- Register: impersonal; never "we". Self-reference is third person ("The authors have employed ...", "they extended ...") and "In the paper" / "described in this paper". Passive dominant everywhere ("is investigated", "is considered", "it is assumed", "it has been found", "are shown"). Present tense for mechanism and results, present perfect for own prior work and the introduced indicator, past once for the model extension. Formal, British spelling ("whilst"). Sentence length: mean ~28–30 words, spread ~12 to ~65 (long multi-clause sentences with embedded lists and conditions). Paragraphs: 3–8 sentences; three sections are single paragraphs.
- Section openers:
  - Introduction: "[Phenomenon] results from the interaction of [A] and [B] due to [cause]"
  - Technique/method: "[Quantity] is produced predominantly as a result of [mechanism] [ref]"
  - Parameter/results section: "[Parameter] is a particularly important parameter in regard to [quantity]" / "[Parameter] can also have a significant effect on [quantity]" / "It is well-known that [technique] can reduce [quantity]" / "[Quantity] can be expressed in the general form: ([n])"
  - Design-feature section: "A knowledge of [finding] makes it possible to reduce [quantity] by [feature] [ref]"
  - Conclusion: "Certain [parameters] can have a very significant effect on [quantity], in particular [parameter]"
- Gap/limitation shapes: "However, they require [demanding condition] [refs], particularly for [target]"; "albeit with the assumption of [simplification]"; "Although there is no formal basis for [relation], it has been found that ..."; "when [effect] is neglected ... In practice, however, due to [effect], ... should be increased slightly"; "Of course, the choice ... also depends on [other factors]". Verbs: require, assume, neglect, depends. Proportion: about four limitation sentences in the whole paper; own-model limitation is a single clause; limitations sit inside technique and results paragraphs, never in the conclusion.
- Contribution phrasing: prose, task-worded, single sentence in the Introduction; result-worded in the abstract ("It is shown that [finding]", "[indicator] has been introduced to indicate [quality]"); the conclusion repeats the indicator as a tool ("can, therefore, be used to aid ...").
- Transitions: "However" (~7, most frequent, often opening a contrast mid-paragraph), "In general" (~4), "For example" (3), "Hence"/"Thus" (3), "Again" (2), "In practice" (2), "Similarly", "In other words", "Clearly", "Obviously", "Of course", "Most recently", "Throughout", "As for" (1 each). Sections link by content (a new parameter each time) rather than by connectives; within paragraphs connectives are dense; back-references via "as described earlier", "also", "Again".
- Hedging: analytical-model trends take "in general", "usually", "typically", "approximately", "about", "slightly", "essentially the same"; equation-backed claims are flat ("Equation ([n]) shows that", "as will be obvious from"); figure/table-backed claims are flat and strong ("It is obvious", "It is evident", "It will be noted"); common knowledge marked "It is well-known that", "it is common practice to"; the indicator is hedged once ("no formal basis"); own model rated strongly ("very reliable"); recommendations use "is preferable", "usually the preferred value", "should always be chosen". Note for profiler: certainty adverbs (obvious/obviously, clearly, evident) appear about six times; likely conflicts with prose-quality norms, knowledge files win.
- Callout templates:
  - Figures: "Fig. [n] shows the variation of [quantity] with [parameter] for [case]"; "[items] are shown in Fig. [n]"; "This is illustrated in Figs. [n] and [m], which show the effect of [parameter] on [quantity]"; "It is obvious, from both Fig. [n] and Table [m], that [claim]"; "It will be noted that [observation]"; "It should (also) be noted that [observation]"; appositive "[feature] [ref], Figs. [n] and [m]".
  - Tables: "as shown in Table [n]"; "[values] are given in Table [n]"; "Table [n] shows the variation of [factor] with [parameter]".
  - Equations: "[Quantity] can be expressed in the general form: ([n]) where [symbol] is [definition]"; "Equation ([n]) shows that [dependency]"; "as will be obvious from ([n]) and ([m])"; "([n]) and ([m]) indicate that [claim], since [reason]"; "the optimal [parameter] which eliminates [quantity] is: ([n])".
- Comparison sentence shapes: "[quantity] in [case A] is usually about [ratio] of that in a similar [case B]"; "[case A] will generally produce about [ratio] the [quantity] as equivalent [case B]"; "For all [cases], [quantity] increases with [parameter]"; "all [cases with property] exhibit essentially the same [quantity]"; conditions attached by "for which [values]", "similar", "equivalent", "assuming that the other [parameters] remain constant".
- Conclusion shape: one paragraph (page-split); opens with the strongest general finding; then one finding per parameter in section order; the introduced indicator restated as a selection aid with "therefore"; ends with a paired "It has been found that ... while ..." sentence; no limitations, no future work, no citations, only approximate ratios as numbers.
- Generic connective phrases (max eight words each):
  - "In general, the larger ... the larger"
  - "It will be noted that"
  - "It should also be noted that"
  - "This is due to the fact that"
  - "Again, the reason for this is"
  - "as described earlier"
  - "In practice, however"
  - "as will be obvious from"
  - "For all combinations"
  - "assuming that the other parameters remain constant"

## Roles shown
- intro-context: 1
- approach-and-contributions: 1 (objective and scope; task-worded)
- literature-category: 1 (shares its paragraph with limitation)
- limitation: 1 (same paragraph as above)
- model-or-assumption: 4 (technique section 1; slot/pole 1; pole-arc 1; skewing 1)
- mechanism: 2 standalone, plus embedded mechanism sentences in 3 results paragraphs
- setup: 1 (includes the validation callout)
- results: 5
- design-implication: 1 standalone, plus closing implication sentences in 3 other paragraphs
- discussion-or-limitation: 1
- comparison: 0 standalone; ratio comparisons embedded in 2 results paragraphs and the conclusion
- conclusion: 1
- abstract: 1 (result-worded)
- not observed: gap, contribution-list, research-questions, organization, method-objective (as a standalone paragraph; one clause only), taxonomy-overview, category-opener, cross-cutting-comparison, synthesis, research-agenda
