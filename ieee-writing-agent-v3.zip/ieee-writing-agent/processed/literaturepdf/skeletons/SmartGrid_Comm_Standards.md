# Skeleton: SmartGrid_Comm_Standards
- Title: Smart Grid Technologies: Communication Technologies and Standards; venue: IEEE Transactions on Industrial Informatics (vol./no. as printed); year: 2011
- Type: small comparative review (with catalogue/tutorial character in the standards section). Evidence: five technology subsections each split into fixed advantages/disadvantages blocks, one overview table per body section, standards listed as bullets grouped by application domain; no method, no experiments, no taxonomy figure.
- Approximate paragraph count: about 40 prose paragraphs plus about 25 bulleted standard entries; taxonomy figure/table: n (two overview tables, values not recovered); comparison tables: y (one, headers not recovered); explicit RQs: n at paper level (a local two-question device inside one subsection); future-work: y (one sentence in the conclusion, no section)
- Extraction damage: Intro P1 merged with funding/affiliation footnote and an affiliation line became a noise heading; paragraph breaks lost (each Pn is a page chunk, Intro boundaries below are inferred); Table I/II values dropped (captions only); Section II heading split over two lines; the fourth requirements subheading and the fifth standards subheading merged into body text; running headers, page markers, copyright lines embedded; author bios merged into References; no equations in the paper.

## Section list
1. Abstract
2. I. Introduction
3. II. Communications technologies (section intro + 5 technology subsections, each with numbered "Advantages" / "Disadvantages" sub-blocks)
4. III. Communications requirements (section intro + 4 subsections, one per requirement property; the fourth contains the question-pair device and a routing-literature walk-through)
5. IV. Standards (section intro + 9 subsections by application domain, each a bulleted list of standards)
6. V. Conclusion (single paragraph, includes the future-work sentence)
7. References

## Paragraph map
| Section | Para | Function | First-sentence template | What follows the claim | Citation pattern | Figures/tables referenced |
|---|---|---|---|---|---|---|
| I | P1 | intro-context | "[System] has remained unchanged for [duration]." | number+condition (growth statistic, agency source) | single | none |
| I | P2 | driver-accumulation (own label: deficiencies of the studied system) | "[Current system] is very complex and ill-suited to [needs]." | list of deficiencies with cite; closes "Consequently, [new X] is urgently needed" | single x3, one per fact | none |
| I | P3 | intro-context (concept definition) | "To realize [capabilities], a new concept, [X], has emerged." | definition sentence, then benefit sentences each with cite | cluster of 2, then singles | none |
| I | P4 | mechanism | "[Old system] lacks [capability], while [new system] has [capabilities], as illustrated in Fig. [n]." | figure callout, then mechanism sentence, then consequence with cite | single; cluster of 2 | Fig. 1 |
| I | P5 | intro-context (activity landscape) | "[Regions] have started [R&D] on [applications]." | example (funding figure with cite) | single x2 | none |
| I | P6 | intro-context to definition | "In addition to [projects], many [actors] are taking [steps]." | mechanism/definition sentence with cite | single | none |
| I | P7 | approach-and-contributions + organization | "In this paper, a [adj] review on [topic] is presented." | one roadmap sentence per section | none | none |
| II | P1 | taxonomy-overview (motivation) | "[Component] is the key component of [system] [cites]." | citation cluster, then mechanism (data volume, need to define requirements) | cluster of 3, single | none |
| II | P2 | taxonomy-overview (axis 1) | "Different [technologies] supported by two main [media], i.e., [A] and [B], can be used for [purpose]." | trade-off sentences: "In some instances... However... On the other hand..." | none | none |
| II | P3 | taxonomy-overview (axis 2) + announcement | "Basically, two types of [infrastructure] are needed for [function]." | attributed option list ("As suggested in [ref]"), limiting-factor list, "In the following..." and table pointer | single | Table I |
| II.A | P1 | category-opener | "[Technology] is a [kind] technology that is relatively low in [properties]." | application list, endorsement with cite, deployment examples | single x2 (standards body; self-authored tech report) | none |
| II.A | P2 | comparison (advantages block) | "1) Advantages: [Technology] has [spec list] [cite]." | number+condition (specs), then suitability verdict "is considered as a good option for [uses]" | single x3 | none |
| II.A | P3 | limitation (disadvantages block) | "2) Disadvantages: There are some constraints on [technology] for practical implementations, such as [list] [cite]." | mechanism ("Hence, these concerns... increase the possibility of...") then remedy ("should be implemented") | single x2 | none |
| II.B–E | all | same triad repeats (opener, advantages, disadvantages) | "[Technology] is a [kind] that uses [existing infrastructure] to [function]." | example (named deployments, mostly uncited or one tech report) | single, reused; often none | none |
| II.E | last | cross-cutting-comparison / synthesis | "To conclude, [class A] are costly for [deployment] but [benefit]." | contrast sentence "On the other hand, [class B]... but..." | none | none |
| III | P1 | requirements-overview (own label) | "[Infrastructure] between [stages] requires [property list] [cite]." | second requirement sentence; "In the following, major [requirements] are presented." | single | none |
| III.A | P1 | design-implication | "[Secure X] are extremely vital for [actors], especially for [purposes] [cite]." | prescription ("should be developed") | single | none |
| III.B | P1 | comparison + design-implication | "Providing [property] has become one of the most prioritized requirements for [actors]." | causes with cite; class-A vs class-B trade-off (same cite twice); hybrid recommendation | single, repeated | none |
| III.C | P1 | design-implication | "[System] should be [property] enough to facilitate [operation] [cite]." | mechanism (many nodes joining), then "Hence, ... should handle ..." | single | none |
| III.D | P1 | research-questions (local) | "The [communication] between [A] and [B] is a key issue of [system]." | mechanism, "must be provided", then "This incurs two important questions unique to [domain]" + two bullets "How to [define/ensure] [X]" | none | none |
| III.D | P2–P3 | mechanism (answers) | "To answer the first question, [mechanism] must be investigated." | procedural chain (Then..., Finally...) with cite | single each | none |
| III.D | P4 | mechanism | "A [requirement] usually includes specifications, like [list]." | procedure, then cite | single | none |
| III.D | P5 | design-implication (expectation) | "To efficiently link together [components], a powerful [infrastructure] will be provided." | "It is expected that..." twice; standards mention | single | none |
| III.D | P6 | literature-category | "One of the challenges of employing [tech] in [context] is [problem]." | mechanism + cluster; then paper-by-paper "In [ref], [approach] is presented"; one judgment sentence | cluster of 2, then single x4 (sentence-initial bracket as agent) | none |
| IV | P1 | gap | "There are many [solutions] for [system] that have been developed or are still in development." | "However, the key challenge is that [system] is lacking [X]..."; objective list with cite; regional examples; SDO list | single, repeated | none |
| IV | P2 | taxonomy-overview (announcement) | "An overview of [items] are given in Table [n]." | "In the following, the details of these [items] are explained." | none | Table II |
| IV.A–I | bullets | category-opener (bulleted) | "[Standard]: [Standard] is a [kind] standard for [scope]." | scope description; occasionally one cite | none / single | none |
| V | P1 | conclusion | "[Topic] has been conceived as an evolution of [system] due to [driver], but with the additional aim to [goals]." | mechanism ("To this end..."), then "In this paper, [X] have been discussed", open-issues assertion, future-work sentence | none | none |

## Summary-to-judgment turns
1. Section II intro, para 2, mid-paragraph: "In some instances, [A] have some advantages over [B], such as [list]. However, [drawback]. On the other hand, [B]..."; backed by property argument only; hedged ("some", "may cause").
2. Section II intro, para 3, after the attributed option list: "Nevertheless, there are key limiting factors that should be taken into account, such as [list]"; backed by a factor list; moderate; closes "[choice] that fits one [environment] may not suit the other".
3. Every disadvantages block (5x), block start: "There are some constraints on [X] for practical implementations, such as..." / "[X] can be counted as the major challenges of [Y]" / "[X] may not be acceptable for [use]"; backed by one cite plus a "Hence, ..." consequence; hedged-to-moderate; ends in a prescriptive remedy.
4. End of the last technology subsection: "To conclude, [class A]... but...; On the other hand, [class B]... but..."; backed by the accumulated subsections, no cite; flat declarative.
5. Standards section opener, sentence 2: "However, the key challenge is that [system] is lacking [X] and this situation prevents [Y]"; backed by argument plus one cite; strong ("critical prerequisite").

## Figure and table roles
- Architecture figure (one): carries the system-overview/mechanism claim; claim stated before the callout in the same sentence ("..., as illustrated in Fig. [n]"); pointed at, one descriptive sentence follows; the caption is itself a full claim sentence.
- Overview/comparison table of categories (one): summary of the category section; pointed at once at the end of the section intro ("can be found in Table [n]"); never interpreted or walked through, the subsections are the prose; headers [NEED: table headers; dropped in extraction].
- Overview table of standards (one): summary of the field; pointed at immediately before the bulleted subsections ("are given in Table [n]. In the following..."); not interpreted; values dropped.
- No result figures, no equations, no mechanism diagrams beyond the architecture figure.

## Introduction closing chain
- Chain length: 1 paragraph (approach and organization merged), about 5 sentences.
- Gap form: no prior-work gap; motivation accumulates over the context paragraphs (deficiencies of the current system, need for a new infrastructure, need for communications); no review of prior surveys, no novelty statement. The abstract carries an objective statement ("The main objective of this paper is to [provide X] as well as to [discuss Y]") and an expected-impact sentence ("It is expected that this [paper] will [provide X]"), neither repeated in the Introduction.
- Contribution form: prose, one sentence, task-worded ("a [adj] review on [topic] is presented"), count 1; no numbered list.
- Organization paragraph: present, merged into the same paragraph; one sentence per body section with verbs "describes / mentions / are reviewed in / is concluded in"; maps sections to topics only, not to contributions or to the categories set up earlier.

## Taxonomy
- Axes: (1) by transmission medium, two values, announced in the section intro; (2) by data-flow tier, two values, attributed to a cited source ("As suggested in [ref]") and not used to organize subsections; the subsections themselves are organized per technology instance; (3) Section III by requirement property (four values); (4) Section IV by application domain (nine values), then by standard within each.
- Justification: minimal; axis 1 stated as given ("two main [media]"), axis 2 attributed, axis 4 unjustified.
- Exclusive vs matrix: exclusive lists; axes 1 and 2 form an implicit matrix never tabulated in prose (the overview table may do this; unrecoverable).
- Depth: section, category, fixed advantages/disadvantages sub-blocks (three levels); standards: section, domain, bullet (three levels).
- Announcement templates: "Different [items] supported by two main [axis values], i.e., [A] and [B], can be used for [purpose]."; "In the following, [items] along with their advantages and disadvantages are briefly explained."; "An overview of [items] can be found in Table [n]."
- Placement: announcement, then table pointer, then first category subsection immediately follows (table sits at the boundary).
- Category sections open with a definition sentence ("[Technology] is a [kind] technology that [property]") followed by application list and deployment examples; they close with the disadvantages block, which ends on a remedy/hybrid/prescription sentence; no per-category synthesis.
- Cross-cutting themes (cost, coverage, bandwidth, security, environment): recur inside every advantages/disadvantages block rather than owning sections in II; Section III then re-slices the same material by property; the hybrid wired-plus-wireless remedy recurs in disadvantages blocks and in III.B.
- Reuse: axis 1 reused in the II.E synthesis and in III.B; not reused in the conclusion or in future work.

## Comparison
- Dimension kinds: deployment/operating cost, coverage/range, data rate/bandwidth, security, reliability/availability, interference/noise susceptibility, scalability, deployment environment (urban/rural, indoor/outdoor), dependence on existing infrastructure or third parties, standardization status.
- Table introduction template: "An overview of [items] can be found in Table [n]." (end of section intro; not interpreted afterwards).
- Trade-offs vs winner: trade-offs stated per technology; no global winner; several technologies receive a hedged fit-for-application verdict ("[tech] can be the best candidate as [role] for [uses]", "[tech] can be considered as a promising [X] for [uses]"); the closing synthesis is a two-class trade-off.
- Differing conditions: handled by attaching an environment or application qualifier ("in [urban] areas", "for [mission-critical] applications"); no normalization; numbers never set against a baseline.
- Rubric: not observed.
- Recommendation: hybrid of the two medium classes recommended in III.B ("To provide [properties] at the same time with appropriate [cost], a hybrid [X] can be used"); per-technology application matches elsewhere.

## Research questions
- Paper-level RQs: not observed. Local device in III.D: two bulleted "How to [define/ensure] [X] in [context]" questions, introduced by "This incurs two important questions unique to [domain]."
- Answered in the next two paragraphs, same subsection; cross-reference by ordinal: "To answer the first question, [X] must be investigated." / "To answer the second question, [methods] are focused on."
- No results section; no restatement. The abstract promises open research issues; the conclusion only asserts they exist ("Clearly, there are many important open [issues]") -> [NEED: enumerated open issues; not present].

## Results ladder
- Review mode: evidence from cited work is mostly reported, not interpreted. Two report shapes: (a) deployment examples, named vendors/projects, uncited or citing one self-authored technical report, then an advantages/disadvantages verdict; (b) paper-by-paper walk-through "In [ref], [approach] is presented" with a single closing judgment ("These [approaches] present high performance for [application]: they close the gap between [A] and [B]"), backed by argument, no numbers.
- Inside disadvantages blocks a three-rung mini-ladder: constraint list -> consequence ("Hence, ...") -> remedy ("should be implemented"), 1 to 2 sentences per rung.
- Observation/report verbs: is, has, provides, supports, is presented, is chosen, uses, performs up to. Mechanism verbs: due to, since, hence, may cause, result in, depends on, restricts. Implication verbs: should be, must be, can be considered, can be a good choice.
- Spec numbers reported with condition and cite, never against a baseline; anomalies/counter-evidence: not observed; ladder ends in a prescription or a fit-for-application verdict.

## Future work derivation
1. Conclusion, final sentence: [topics outside this review's scope: grid characteristics, architectures, actors, pilots, applications, ICT research challenges] -> [a follow-up complete overview] -> untraced (authors' own scope extension; wish-list). Template: "Future work includes [list], in order to [aim]."
2. Conclusion, preceding sentence: [open research issues exist] -> [nothing stated] -> untraced; [NEED: items].
3. In-body prescriptions (not labelled future work): II.A disadvantages: [interference] -> [detection/avoidance schemes, energy-efficient routing "should be implemented"] -> traced to the limitation in the same block; III.A: [attack exposure] -> [security mechanisms and standardization "should be developed"] -> traced to the requirement; III.B: [cost vs capacity trade-off] -> [hybrid of both classes] -> traced to axis 1; IV.P1: [missing standards] -> [adoption of interoperability standards, "critical prerequisite"] -> traced to the gap.
- Placement: one sentence at the end of the conclusion plus scattered "should/must" sentences in the body; no own section. Verdict: the conclusion item is a wish list; the body prescriptions are derived.

## Section endings and synthesis
- Technology subsections end with the disadvantages block, closing on a remedy or hybrid sentence; no per-category synthesis paragraph. Only the final subsection appends a two-sentence cross-category trade-off ("To conclude, [A]... but...; On the other hand, [B]... but...").
- Requirement subsections end with a prescription ("should", "must") or a recommendation; the last one ends on a description of the last cited protocol (no synthesis, abrupt).
- Standards section: no synthesis; ends with the last bullet group.
- Final synthesis (conclusion): restates motivation, lists what was discussed, asserts open issues, states future scope; does not relate categories to each other or to a research agenda.

## Language signals
- Register: "this paper" only, "we" not observed; meta-statements in passive ("is presented", "are explained", "have been discussed", "can be found in"); descriptions in present active; developments in present perfect ("has emerged", "have started"); planned deployments in future ("will be integrated", "will be provided"). Formal but loose (non-native constructions, list-heavy). Sentence length: mean about 24 words, spread about 8 to 55, many list sentences over 35 words. Paragraph length: Intro 5 to 9 sentences; category openers 5 to 8; advantages/disadvantages blocks 3 to 6; requirement subsections 2 to 7; standard bullets 1 to 4; conclusion about 7.
- Section openers: Introduction "[System] has remained unchanged for [duration]."; survey section "[Component] is the key component of [system] [cites]."; category "[Technology] is a [kind] technology that [defining property]."; advantages "1) Advantages: [Technology] has/is [property list]."; disadvantages "2) Disadvantages: There are some [constraints] on [technology] for [use], such as [list]."; requirements section "[Infrastructure] between [stages] requires [property list] [cite]."; requirement subsection "[Property] has become one of the most prioritized requirements for [actors]." or "[System] should be [property] enough to [function] [cite]."; standards section "There are many [solutions] for [system] that have been developed or are still in development."; standard bullet "[Standard]: [Standard] is a [kind] standard for [scope]."; conclusion "[Topic] has been conceived as an evolution of [system] due to [driver]."
- Gap/limitation shapes: "is lacking [X] and this situation prevents [Y]" (strong); "There are some constraints on [X] for [use], such as..."; "[X] may not be acceptable for [use]"; "[X] can be counted as the major challenges of [Y]"; "[X] restricts [tech] for applications that need [property]"; "[choice] that fits one [environment] may not suit the other". Verbs: lack, prevent, limit, restrict, cause, may not, cannot be implemented, depends on. Proportion: about one third of each technology subsection (the whole disadvantages block); Intro deficiencies of the studied system about one paragraph; limitation of prior surveys not observed.
- Contribution phrasing: prose, one sentence, task-worded, count 1: "In this paper, a [adj] review on [topic] is presented."; abstract: "This paper addresses [issues] primarily in terms of [aspect]."; "The main objective of this paper is to provide [X]."; "It is expected that this [paper] will [provide X]." Numbered list not observed.
- Transitions (rough counts): Hence ~8; However ~7; Also ~5; Furthermore ~4; In addition ~4; On the other hand ~4; For example ~4; Moreover ~3; In the following ~3; Therefore ~2; To this end 2; Basically 2; Consequently, Nevertheless, Importantly, To conclude, Clearly 1 each; procedural Then/Finally in the question-answer paragraphs. Subsections are content-linked (definition openers, no back-reference); Intro paragraphs and III.D answers are connective-linked ("To realize [X]", "To this end", "In addition to", "To answer the [ordinal] question").
- Hedging: "can be considered as", "can be a good option", "seem as a promising", "may cause", "may not", "in some instances", "some", "relatively", "It is expected that" attach to suitability verdicts and forward-looking deployment claims. Flat: definitions, spec numbers with cite, deployment facts (often uncited), the standards gap, and the conclusion ("Clearly", "extremely critical", "vital"). Intensifiers with flat claims: "very critical", "extremely vital", "huge amount", "very important".
- Callout templates: figure "[claim], as illustrated in Fig. [n]."; table "An overview of [items] can be found in Table [n]." / "An overview of [items] are given in Table [n]. In the following, the details of these [items] are explained."; equations not observed; spec numbers "[Tech] performs up to [rate]" / "[Tech] has [n] channels in [band], each with [width]".
- Comparison shapes: "In some instances, [A] have some advantages over [B], such as [list]."; "On the other hand, [B] do not have [problem]..."; "Compared to [X], [Y] may handle [situation] better due to [reason]."; "[A] are costly for [use] but [benefit]; [B] can reduce [cost], but provide constrained [property]."; "[Tech] is an alternative solution to [tech] that handles [problem] since [reason]."; "[Feature list] highlight why [tech] can be the best candidate as [role] for [uses]." Numbers against a baseline: not observed.
- Conclusion shape: one paragraph, four moves: motivation restated (present perfect) -> "In this paper, [X] have been discussed. [Y] is introduced and [Z] are presented." -> "Clearly, there are many important open [issues] for [goal]." -> "Future work includes [list], in order to [aim]." No citations, no numbers, no recommendation.
- Generic connective phrases: "In the following, [X] are briefly explained"; "An overview of [X] can be found in"; "To this end,"; "On the other hand,"; "as illustrated in Fig. [n]"; "Hence, it is very critical for"; "can be considered as a promising technology"; "In this paper, [X] have been discussed"; "There are some constraints on [X]"; "To conclude, [A] ... but ...".

## Roles shown
- intro-context: 4 (I.P1, I.P3, I.P5, I.P6)
- driver-accumulation (own label; deficiencies of the studied system, not of prior work): 1 (I.P2)
- mechanism: 4 paragraphs (I.P4, III.D P2–P4) plus consequence sentences embedded in 5 disadvantages blocks
- approach-and-contributions: 1 (I.P7, one sentence, merged with organization)
- organization: 1 (same paragraph)
- taxonomy-overview: 4 (II.P1–P3, IV.P2)
- category-opener: 5 prose (II.A–E) plus 9 bulleted groups (IV.A–I)
- comparison: 6 (5 advantages blocks, III.B trade-off)
- limitation: 5 (disadvantages blocks; limitations of technologies, not of prior work)
- cross-cutting-comparison: 2 (II.E close, III.B)
- synthesis: 1 (II.E close, two sentences, partial)
- gap: 1 (IV.P1, standards gap)
- literature-category: 1 (III.D P6, paper-by-paper walk-through)
- research-questions: 1 (III.D P1, local device, answered in place)
- design-implication: 5 (III.A, III.B, III.C, III.D P5, plus remedy closes inside disadvantages blocks)
- conclusion: 1
- abstract: 1 (motivation -> definition -> objective -> expected impact)
- caption: 1 claim-bearing figure caption recovered; table captions title-only
- Not observed: contribution-list, method-objective, model-or-assumption, setup, results, discussion-or-limitation (as a separate paragraph), research-agenda (asserted, not enumerated)
