# Skeleton: Soft_Magnetic_Status_Trends
- Title: "Soft Magnetic Material Status and Trends in Electric Machines"; venue: IEEE Transactions on Industrial Electronics (vol. 64, no. 3); year: 2017 (as printed)
- Type: small comparative review (status/overview paper). Evidence: abstract announces "an overview on the history and trends"; body is organized as one subsection per material family compared on a shared property framework, then one application subsection per material; no taxonomy figure; roughly 8 text pages.
- Approximate paragraph count: ~40 (true breaks estimated; extractor merged them); taxonomy figure/table [n]; comparison tables [partial: one specification table comparing two standards; no method-comparison table]; explicit RQs or hypotheses [n]; future-work section or paragraph [n as a section; outlook paragraphs embedded in the last body subsection and the conclusion]
- Extraction damage: two-column merge produced one block per page; affiliation footnote and copyright lines injected mid-Introduction; subsection headings (B, C, D, E, 2)) inlined inside blocks; Table I values and all figure captions inlined into running text; one heading split across heading/body; one heading is a sentence start; no equations in the paper.

## Section list
1. I Introduction
2. II Overview of material property parameters used in machine design (four cross-material property figures)
3. III Trends in established material classes: A [alloy family 1]; B [alloy family 2] with sub-trends 1) composition-driven loss reduction, 2) thickness-driven loss reduction (Table I); C [alloy family 3]; D [alloy family 4] (Figs. 5–6)
4. IV Emerging material classes for future designs: A [two related classes sharing a production route] (Fig. 7); B [class with a different form factor]
5. V Machines built with emerging or nonstandard materials: A–D one subsection per material variant; E design solutions and manufacturing technologies (cross-cutting)
6. VI Conclusion
7. References; author biographies

## Paragraph map
| Section | Para | Function | First-sentence template | What follows the claim | Citation pattern | Figures/tables referenced |
|---|---|---|---|---|---|---|
| I Intro | P1 | intro-context (historical) | "When [pioneer] showed [phenomenon] in [year], [field] began" | example (dated chronological examples) | single per fact, then cluster of 3 | none |
| I Intro | P2 (may share block with P1) | intro-context / literature-category (status and trends) | "From [period] to today, [class] remains [status]" | citation cluster (each trend sentence closed by a citation) | single, then cluster of 2 | none |
| I Intro | P3 | approach-and-contributions + organization (two functions, one paragraph) | "This paper briefly summarizes [scope] where [objects] are [applied or studied]" | none (section-by-section roadmap) | none | none |
| II Overview | P1 | setup + gap (design-choice motivation) | "For [application], [class] is by far the most common [choice]" | number+condition (market shares), then numbered parameter list | cluster of 2 | none |
| II Overview | P2 | mechanism + cross-cutting-comparison | "The possible [performance metric] of [device] is mainly determined by [property]" | mechanism sentence, figure callout, data-provenance citation cluster | cluster of ~9 in three grouped sub-clusters | Fig. 1 (provenance for Figs. 1–4) |
| II Overview | P3 | mechanism + cross-cutting-comparison | "Next to [property], [loss quantity] is a key factor in [design]" | mechanism sentence (loss components, frequency scaling), then figure callout | none | Figs. 2, 3 |
| II Overview | P4 | mechanism + design-implication | "[Property] of [material] is related to [intrinsic attribute]" | mechanism sentence, then parenthetical examples | none | none |
| II Overview | P5 | mechanism (process) | "To fully utilize [properties], [process] is often applied [before or after step]" | figure callout, then caveat note | none | Fig. 4 |
| III opener | P1 | category-opener (section level) + organization | "The typical [material form] for [application] are [form] with [dimension range]" | mechanism sentence, then announcement sentence | none | none |
| III.A | P1 | category-opener + comparison + judgment turn | "[Family] are [definition] with [composition bound]" | definition, then summary-to-judgment turn backed by standards cluster | cluster of 3 | none |
| III.B | P1 | category-opener + mechanism (use domains) | "The most widely used [material] in [application] is [composition]" | definition of two variants, then contrast of application domains | single | none |
| III.B | P2 | mechanism (alloying effects) | "[Variant] are [definition] with [composition range], processed to [property goal]" | mechanism sentences: each element -> benefit + downside | single, single | none |
| III.B | P3 | design-implication (delivery conditions) | "For [application], [variant] provide [qualitative rating] for all [attributes]" | example (two conditions defined), then trade-off statement | none | none |
| III.B | P4 | taxonomy-overview (sub-trend announcement) | "The current trends in [material] focus on [goal], with emphasis on [driver]" | none (announcement) | none | none |
| III.B.1 | P1 | category-opener + limitation + mechanism (two processes) | "[Variant] are developed to increase [property] and thus [reduce loss]" | number+condition, "However" drawback, two process examples each with cost caveat | single x5 | none |
| III.B.2 | P1 | category-opener + literature-category (standards) | "Another trend to reduce [loss] in [material] is [dimension change]" | number+condition, history, standards narrative with table callout, pointer to further research | single x3 | Table I |
| III.C | P1 | category-opener + comparison (cost vs performance) | "[Family] is generally the most expensive [class] due to [composition]" | number+condition with citation, then application examples | single, then cluster of 2 | none |
| III.C | P2 | design-implication + mechanism (process trade-off) | "[Family] have the highest [mechanical property] of common [class] and therefore [use]" | example (applications), mechanism sentences with number+condition | single, cluster of 2, single | none |
| III.D | P1 | category-opener + comparison + figure interpretation | "[Family] laminations are a good choice if [property] is key, e.g., [application]" | mechanism sentence, "However" drawback, number+condition, applications, two interpreted figure callouts | single, cluster of 2 | Figs. 5, 6 |
| IV opener | P1 | taxonomy-overview + discussion-or-limitation (comparability caveat) | "With increasing [demands] for [application], more [emerging class] find their way into [component]" | list of included subclasses, caveat argument, methodological decision | none | none |
| IV.A | P1 | category-opener + mechanism (production process) | "[Class] have the advantage of very low [loss] due to [structure] and [cost]" | mechanism sentences (process steps), number+condition | single, single | none |
| IV.B | P1 | category-opener + limitation | "[Class] consist of [microstructure description]" | definition, advantage, "However" limitation, electromagnetic pros and cons | cluster of 2, single, cluster of 2 | none |
| V opener | P1 | intro-context (application axis) + organization | "The main focus for future [devices] in [sector] is unquestionably [driver]" | figure callout with citation cluster, second trend, announcement sentence | cluster of 2 | Fig. 8 |
| V.A | P1 | category-opener + literature-category | "The challenges in handling [form] make [complex geometries] difficult" | design-implication, then per-study reports "In [refs], a [machine] with [feature] is presented" | single, cluster of 2, single, cluster of 3 | none |
| V.B | P1 | category-opener + design-implication | "The main advantage of [material] in [application] is [geometric capability]" | example (topology list) with citations | single, cluster of 2, single, single | none |
| V.B | P2 | design-implication (problem -> candidate solution) | "[Machine type] are very attractive for [performance] at [cost] due to [structure]" | "However" limitation, mechanism, hedged proposal, further concept examples | cluster of 2 x3 | none |
| V.C | P1 | literature-category + judgment turn | "Several projects have investigated [material] for [application] where [flux condition]" | per-study reports, then hedged confound judgment | single x3 | none |
| V.D | P1 | literature-category | "[Variant] with [composition] are typically considered for [property] and [property]" | target application, per-study reports | single x2 | none |
| V.E | P1 | synthesis (mutual-dependence argument) | "The impressive [effort] would not have had its impetus without [long-standing research]" | argument sentences, no evidence | none | none |
| V.E | P2 | synthesis + design-implication + prediction | "Developments in [manufacturing], such as [example], once [constraint], are now widely used" | example list, then prediction | none | none |
| V.E | P3 | discussion-or-limitation (machinability) | "[Property] of [materials] is a key aspect of controlling [costs]" | example, "Unfortunately" limitation, industry response | none | none |
| V.E | P4 | research-agenda (emerging manufacturing route) | "Still looking at [technologies], [actors] are also looking at [technology] with the goal of [goal]" | "However ... still in the beginning stages", then conditional prediction | cluster of 2 | none |
| V.E | P5 | literature-category (survey of activities) | "In the field of [technology], most [private results] are unpublished, but [n] activities report results" | per-study one-line reports | single x3 | none |
| V.E | P6 | research-agenda | "Research on [materials by technology] will necessarily be directed toward [selection problem]" | reasoning sentence, then prediction | none | none |
| VI Conclusion | P1 | conclusion (restatement + designer implication + call to collaborate) | "This paper presented the highly active [field]" | design-implication sentences | none | none |

## Summary-to-judgment turns
1. III.A, mid-paragraph: "[Class] have traditionally been considered [negative], although a closer look at [standards] reveals [comparable property]"; backing: citation cluster of 3 (standards); strength: moderate-firm ("reveals").
2. IV opener, whole paragraph: "It can often be the case that [properties], when tested to [standards], may not compare well against [baseline]" -> "This makes it difficult to compare [A] to [B]" -> "For this reason, [descriptions] can only be [qualitative]"; backing: argument (test-condition mismatch), no citation; strength: hedged premise, firm methodological decision.
3. V.C, last sentence: "However, in this comparison, it seems [A] is only performing better due to [confound]"; backing: argument about the cited study's design; strength: hedged ("it seems").
4. V.E P2, end: "From this dual viewpoint, [use of X] can lead to [improvement]" -> "In this context, it is predictable that [class] will surely get [share]"; backing: none (trend argument); strength: strong ("surely", "predictable").
5. II P1, mid-paragraph: "However, the constantly increasing [variety] makes it challenging for [designer] to [choose]" -> "This means, [choice] will become [important]"; backing: preceding market numbers (cluster of 2); strength: flat.

## Figure and table roles
- Property-vs-property maps (2 figures): cross-material overview/comparison; first use pointed at ("A general overview of [property] is presented in Fig. N") with claim after via a data-provenance sentence; second use interpreted after callout ("As shown in Figs. N and M, where [properties] are compared, [class] can be [assessment]").
- Loss-range charts at fixed condition (2 figures): evidence for the framework claim that loss is a key design factor; claim before; pointed, not walked through.
- Process-temperature chart (1 figure): reference data; pointed; a caveat sentence follows.
- Two-material curve comparisons (2 figures): comparison evidence; one callout then interpretation ("the advantageous [properties] of each [class] are clearly shown"); the other claim before ("The advantage of [property] is further shown in Fig. N, where ..."); both interpreted.
- Life-cycle cost breakdown (1 figure): evidence for the application section's motivating claim; claim before ("as shown in Fig. N for [case]"); pointed, with citation cluster of 2.
- Specification table (1): replaces prose listing of criteria; "Table I outlines [criteria] and [range] for each [standard]"; one summary sentence after; walked through minimally.
- Taxonomy figure: not observed.

## Introduction closing chain
- Chain length: 1 paragraph (scope + organization) after 1–2 context paragraphs.
- Gap form: not stated in the Introduction; a one-sentence design-choice motivation appears in Section II P1 instead. No accumulated gap; no limitation of prior work.
- Contribution form: prose, task-worded, one item ("briefly summarizes [scope]"); no numbered list; no result-worded claim.
- Organization paragraph: present, merged with the scope sentence; one sentence per section: "[Topic] is given in Section II. Then, [A] and [B] are presented in Sections III and IV, respectively. Section V focuses on [C], giving an outlook of [trends], before the study is concluded in Section VI".
- Mapping: sections follow the material axis (established, then emerging) then the application axis; the outlook is attached to the application section; the chain refers back to the emerging classes and manufacturing trend introduced in the context paragraph.

## Taxonomy (reviews only; else "n/a")
- Axes: two primary plus a framework. (1) By material class: top split by maturity (established vs emerging), sub-split by alloy family/composition, one family further split by loss-reduction trend kind (composition-driven vs thickness-driven). (2) By application/machine type: one subsection per emerging or nonstandard material variant, plus one cross-cutting subsection on design and manufacturing technologies. Framework: by design-relevant property kind (magnetic, mechanical/acoustic, delivery form, availability, cost), given as a numbered list in Section II and reused as the comparison vocabulary.
- Justification: maturity split justified by test-standard comparability (emerging classes treated qualitatively only); family split justified implicitly by market share in the framework opener.
- Exclusivity: exclusive on the material axis; application axis is a sparse material x application matrix, cells filled only where studies exist; cross-cutting subsection sits outside the matrix.
- Depth: three levels in one branch (section > family > trend); two levels elsewhere.
- Announcement templates: Intro roadmap ("[A] and [B] are presented in Sections X and Y, respectively"); section level "The following gives a short introduction on [items]"; sub-trend "The trends are summarized in the following"; application "In the following sections, [applications] are presented where [materials from Sections X and Y] are incorporated".
- Placement: no taxonomy figure; property-overview figures precede the category sections and act as the comparison frame; re-cited inside a later category section.
- Category open/close: open with a positioning sentence (definition + composition; superlative + reason; or conditional recommendation "good choice if [property] is key"); close with an application list, an interpreted figure callout, a pointer to further research, or a drawback plus market form. No synthesis closers.
- Cross-cutting themes: process (annealing) handled once in the framework then per family; manufacturing, machinability, and the emerging manufacturing route collected in the final cross-cutting subsection.
- Reuse: material axis reused as application-subsection names and referenced back ("materials introduced in Sections X and Y"); property framework recurs as comparison dimensions; the outlook names cells of the material axis (emerging classes) and the cross-cutting manufacturing theme.

## Comparison
- Dimension kinds: magnetic (saturation, coercivity/permeability, loss vs frequency, magnetostriction/noise); mechanical (strength, brittleness, machinability); process (annealing need, delivery condition, thickness); economic (cost, availability/geopolitics); geometric freedom.
- Table/figure introduction templates: "Table I outlines [criteria] and [range] for each [standard]"; "A comparison of [curve] is shown in Fig. N for [conditions]"; "[Ranges] for typical [compositions] at [condition] are shown in Figs. N and M, respectively".
- Trade-offs vs winner: trade-offs per material ("The downside is [property]"; "However, a drawback is [property]"; "[benefit], but [cost]"); per-dimension superlatives only ("highest [property] of all [class] at [condition]"; "generally the most expensive"); no overall winner; conditional fit statements ("limited to [applications] requiring [property]"; "might be a suitable solution to reduce [loss]").
- Condition handling: figures pinned at a stated induction, frequency, and thickness; text attaches "at [frequency]" and "for [thickness] alloys"; emerging classes excluded from quantitative comparison because standard tests differ; one confound in a cited comparison flagged (thickness differs).
- Rubric: informal verbal grades ("very good", "good to very good", "poorest"); no rubric table.
- Recommendation: application-fit lists per material; conclusion delegates final choice to the designer with criteria (performance, cost, availability, time-to-market) and calls for producer collaboration.

## Research questions
n/a (none explicit; no hypotheses; no cross-references of the question-answer kind).

## Results ladder
- Review mode: cited work is mostly reported, not re-analyzed. Report verbs: "is presented in", "is described in", "have investigated", "was achieved", "it is reported that", "the authors concluded". Mechanism verbs: "leads to", "due to", "thus", "determines", "is related to", "increases with", "makes [X] difficult".
- Reported results are qualitative ("a significant reduction of [loss] was achieved") with the source's own conclusion attributed ("the authors concluded that [finding]"). Numbers appear only as material properties with condition and citation, not as study outcomes.
- Interpretation sits (a) in the clause after a figure callout ("clearly shown"; "can be an interesting solution"), (b) as the last sentence of a literature paragraph (confound judgment), (c) as a "Therefore, [material] is preferably used in [geometry]" design implication.
- Anomaly handling: one confound flagged, hedged ("it seems ... only due to [confound]").
- Ladder ends: design implication, application fit, or market/availability form ("Therefore, [materials] are typically available as [form]").

## Future work derivation
1. [emerging manufacturing route still immature] -> [proof of fully functional parts, not prototypes] -> traced to open question raised in Introduction P2; placement V.E P4; pattern "However, [attempts] ... still in the beginning stages" + "If [X] is proven, [Y] will significantly change [Z]".
2. [powder selection for that route unexplored] -> [research on selection criteria and process interactions] -> traced to item 1's limitation; V.E P6; pattern "Research on [X] will necessarily be directed toward [Y]"; ends as prediction ("fascinating research field").
3. [designer faces growing material variety] -> [investigate candidates in detail; collaborate with producers] -> traced to Section II P1 gap; Conclusion; pattern "it is incumbent on [actor] to [action]" / "it is vital for [actors] to [collaborate]".
4. [market uptake of emerging classes] -> [none stated; prediction only] -> untraced; V.E P2; wish-list flavor ("will surely").
5. [standard for the thin variant under revision] -> [updated standard expected] -> traced to the stated limitation that the class lacked a standard; III.B.2 mid-section; status note, not research agenda.
6. [comparison of two loss-reduction variants] -> pointer to an external study ("Further research ... is described in [ref]") -> traced to the two trend cells; pointer, not agenda.
- Placement: no dedicated section; embedded in the last cross-cutting subsection and the conclusion; 1–3 sentences per item; items 1–3 derived, item 4 wish-list.

## Section endings and synthesis (reviews only; else "n/a")
- Category sections do not end with synthesis paragraphs; endings are an application list, an interpreted figure callout, a pointer to further research, a drawback plus market form, or an electromagnetic pros-and-cons pair. The sub-trend list closes with a pointer citation.
- Final synthesis = the cross-cutting subsection V.E: relates the material axis to machine-design research (mutual dependence, no citations), then machinability across materials, then the emerging manufacturing route with a three-study survey and a predictive agenda.
- The conclusion (one paragraph) does not recap categories; it generalizes to designer practice and a collaboration call.

## Language signals
- Register: "This paper" (abstract, Introduction, conclusion); "the authors" once ("to the authors' knowledge"); "our" once; "we" not observed. Tense: present for properties and status; past for history and reported studies ("was achieved", "was used"); future for predictions ("will surely", "will represent"). Voice: passive dominant for reporting ("is presented in [ref]", "are shown in Fig. N"); active for mechanism ("[element] increases [property]"). Formality: formal with occasional evaluative adjectives ("impressive", "fascinating", "unquestionably"). Sentence length: mean ~26 words, spread ~8–60, heavy parenthetical use. Paragraph length: framework paragraphs 4–8 sentences; category paragraphs 8–15; conclusion 3 long sentences.
- Section openers: Introduction "When [pioneer] showed [phenomenon] in [year], [field] began"; framework "For [application], [class] is by far the most common [choice]"; established category "[Family] is generally the most [attribute] due to [reason]" or "[Family] are [definition] with [composition bound]"; emerging category "With increasing [demands], more [class] find their way into [component]"; application section "The main focus for future [devices] is unquestionably [driver]"; application subsection "The main advantage of [material] in [application] is [capability]"; conclusion "This paper presented the highly active [field]".
- Gap/limitation shapes: "However, a drawback is [property]"; "The downside is [property]"; "A major drawback of [material] is [property], which makes [step] difficult"; "However, it has to be noted that [process] is [costly]"; "Unfortunately, [method] of [material] is difficult"; "This limits [use] to [conditions] due to [loss]"; "must be avoided as [reason]". Verbs: "is limited to", "makes it difficult", "limits", "must be avoided". Proportion: about one "However" limitation sentence per material paragraph; none in the Introduction.
- Contribution phrasing: prose, task-worded, single item: "This paper gives an overview on [topic]" (abstract); "This paper briefly summarizes [scope]" (Introduction); "A short overview of [topic] is given in Section II".
- Transitions: "However" (very frequent, ~20+); "Therefore"/"thus" (frequent); "Another [trend/way/concept]" (sub-trend links); "In contrast"; "Next to [X]"; "Furthermore"; "Finally"; "Instead"; "In addition"; "Here,"; "From this dual viewpoint"; "In this context"; "Still looking at [topic]"; "For this reason"; "As a result". Paragraphs link mainly by content (a new material or property named in the first sentence); connective-linked only within sub-trend lists and the cross-cutting subsection.
- Hedging: "typically", "generally", "usually", "often", "may", "can", "might be a suitable solution", "it seems", "It can often be the case", "to the authors' knowledge", "it is predictable that". Hedges attach to reported study results and to the reviewers' own inferences. Flat claims: property superlatives backed by datasheet/textbook clusters, market status ("by far the most common"), figure readings ("clearly shown"), and predictions ("will surely", "will significantly change").
- Callout templates: figures "A general overview of [property] is presented in Fig. N"; "[Ranges] for [conditions] are shown in Figs. N and M, respectively"; "A comparison of [curve] is shown in Fig. N for [conditions]; the advantageous [properties] of each [class] are clearly shown"; "The advantage of [property] is further shown in Fig. N, where [quantity] is presented for [conditions]"; "As shown in Figs. N and M, where [properties] are compared, [class] can be [assessment]"; "as shown in Fig. N for [case] [ref]"; provenance "The data for Figs. N–M is based on [sources]". Tables: "Table I outlines [criteria] and [range] for each [standard]". Equations: not observed.
- Comparison sentence shapes: "[Material] reaches the highest [property] of all [class] at [condition]"; "[Material] have the highest [property] of common [class] and therefore [use]"; "[property] about [factor] greater than typical [baseline]"; "[Material] exhibit [property] comparable to [baseline]"; "[Variant] have slightly lower [property] than [variant], but [benefit]"; "[Material] can compete both with [class A] and [class B]"; "superior [property] compared to [A] and [B]"; "A comparable study for [machine type] for [A] and [B] is presented in [ref]".
- Conclusion shape: one paragraph, three long sentences: "This paper presented [field]" -> "With [trend], it is incumbent on [designer] to [action] considering [criteria]" -> "In addition, as [programs] pursue [goals], it is vital for [actors] to [collaborate]". No findings recap, no numbered future work; ends on a collaboration call.
- Generic connective phrases: "The following gives a short introduction on"; "The trends are summarized in the following"; "In the following sections"; "It should be noted that"; "However, it has to be noted that"; "From the application viewpoint"; "From the electromagnetic point of view"; "well beyond the scope of the present survey"; "to the authors' knowledge"; "Each condition has its selling points".

## Roles shown
- intro-context: 3
- literature-category: 5
- limitation: 0 standalone; embedded "However" limitation sentence in ~10 paragraphs
- gap: 1 (embedded in the framework section, not in the Introduction)
- approach-and-contributions: 1 (shared with organization)
- contribution-list: not observed
- research-questions: not observed
- organization: 1 paragraph plus 3 announcement sentences
- method-objective: not observed (closest: the emerging-class opener declaring qualitative-only treatment)
- model-or-assumption: not observed
- mechanism: 7
- design-implication: 4
- setup: 1 (property-parameter framework)
- results: not observed standalone (reported results embedded in literature-category)
- comparison: 3 (embedded with category-opener)
- discussion-or-limitation: 2
- conclusion: 1
- taxonomy-overview: 3
- category-opener: 10
- cross-cutting-comparison: 2
- synthesis: 2
- research-agenda: 2
- abstract: 1 (three sentences, task-worded)
- caption: recovered inline; noun-phrase captions with the test condition attached
