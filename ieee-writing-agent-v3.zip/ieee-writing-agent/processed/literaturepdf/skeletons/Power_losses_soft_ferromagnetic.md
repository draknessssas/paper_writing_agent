# Skeleton: Power_losses_soft_ferromagnetic
- Title: General Properties of Power Losses in Soft Ferromagnetic Materials; venue: IEEE Transactions on Magnetics; year: 1988 (as printed)
- Type: research article. Evidence: single author reports own measurements on several sample sets, then interprets them with the author's own prior theory; sections run Introduction / theory recap / experimental results and discussion / prediction demonstration / conclusion.
- Approximate paragraph count: ~32 real paragraphs (extraction shows 17 page-chunked blocks); taxonomy figure/table: n; comparison tables: n for methods (one data table with sample properties and measured-vs-calculated columns); explicit RQs or hypotheses: n (aims stated as a "twofold investigation"; one rhetorical question in results); future-work section: n (three scattered future-work sentences, one closing the conclusion)
- Extraction damage: headings for Sections III and IV and all four subsections were not recovered (embedded inline); blocks are page chunks that merge several real paragraphs; Table I dropped into a garbled block plus a noise heading; figure captions interleaved with body text; equations garbled (symbols lost); manuscript footnote and copyright lines merged into Intro P1; references split into noise headings.

## Section list
1. Abstract (Front Matter)
2. I. Introduction
3. II. [Theory-name] interpretation of [loss component] (theory recap, three numbered items)
4. III. Experimental Results and Discussion
   - III.A [material class 1]
   - III.B [material class 2] and other materials following the [linear] law
   - III.C materials not obeying the [linear] law
   - III.D [second loss component]
5. IV. Dependence of [total loss] on [drive amplitude] and [frequency]
6. Conclusion
7. Acknowledgment; References; author biography

## Paragraph map
| Section | Para | Function | First-sentence template | What follows the claim | Citation pattern | Figures/tables referenced |
|---|---|---|---|---|---|---|
| Intro | P1 | intro-context (aim + starting principle) | "This paper aims to advance understanding of [phenomenon] for [audience A] and [audience B]" | equation, then mechanism sentence | cluster of 2, then cluster of 2 | eq. (1) |
| Intro | P2 | literature-category + limitation | "The [simplification] introduced by [principle] is readily appreciated because [reason]" | equation, then limitation sentence, then reframed problem | cluster of 2 | eqs. (2), (3) |
| Intro | P3 | literature-category (named model) | "The long-standing guideline for interpreting [quantity] has been [named model] [ref]" | equation (model prediction) | named-author single | eq. (4) |
| Intro | P4 | limitation -> gap (accumulated) | "Despite its achievements, [named model] turns out to be of limited validity because [idealization]" | citation clusters of contradicting findings, then "no agreement" sentence | cluster of 3, single, cluster of 7, singles | none |
| Intro | P5 | approach-and-contributions (own framework) | "A new framework unifying [effects] was recently proposed by [the author] from [approach]" | citation cluster + forward reference to a section | cluster of 6, then singles/cluster of 2 | none |
| Intro | P6 | contribution-list + organization (inline) | "Starting from these premises, this paper presents [n-fold] investigation" | two task-worded goals, then enumerated result-worded conclusions with section refs | none | none |
| II | P1 | model-or-assumption (theory opener) | "According to [theory] developed in [refs], the mechanism governing [quantity] is [competition of A and B]" | announcement of a numbered summary | cluster of 6 | none |
| II | P2 | mechanism (item 1) | "For each value of [rate], [process] can be described as [n active objects]" | equation | cluster of 2, single | eqs. (5), (6) |
| II | P3 | model-or-assumption -> mechanism (item 2) | "The fundamental property of [quantity] in (eq) is its expected [functional dependence] [ref]" | equation, then mechanism sentence, then link to known fact | single | eq. (7) |
| II | P4 | model-or-assumption (special law, item 3) | "Several [materials] obey the simple [law form] (eq)" | equation chain | none | eqs. (8), (9) |
| II | P5 | method-objective (procedure) | "In the following sections we study [function] across [materials] to clarify [validity]" | procedure steps with equation refs, related-work aside | single, cluster of 2 | none |
| II | P6 | model-or-assumption -> design-implication | "According to [interpretation above], [quantity] should depend explicitly on [variable] only" | worked expectation (curve collapse), forward pointer | none | none |
| III | P1 | setup | "[Quantity] were measured on [sample list], as listed in Table [n]" | apparatus/method sentences, figure/table callout | none | Table I; Figs. 1-10 |
| III.A | P1 | results (fit + agreement) | "Fig. [n](a) reports [quantity] versus [variable] at [k] values of [parameter]" | figure callout, fitted parameter values, equation, agreement statement | single | Fig. 1(a),(b); eqs. (2),(3),(9) |
| III.A | P2 | results -> comparison with literature | "This result leads to a first conclusion about [quantity] in [material]" | equation, then literature contrast, then agreement with refs | cluster of 2, cluster of 3 | eqs. (10), (11) |
| III.A | P3 | discussion (parameter meaning) + future pointer | "The fact that [parameter] is independent of [variable] makes it [intrinsic] rather than [fitted]" | single citation, deferred question, forward pointer | single, cluster of 2 | none |
| III.A | P4 | mechanism | "As to the dependence of [parameter] on [variable], recall that [parameter] represents [meaning]" | mechanism sentences | single | none |
| III.A | P5 | results + mechanism (perturbation test) | "An interesting test of [parameter]'s meaning is [perturbation experiment]" | figure callout, qualitative mechanism, re-plot makes it quantitative | none | Fig. 2(a),(b) |
| III.A | P6 | results (robustness remark) | "As a final remark, [law] still holds for [material] under [treatments] [refs]" | citation cluster | cluster of 2 | none |
| III.B | P1 | category-opener + setup + gap restatement | "Figs. [n],[m] report [quantity] measured on [samples] differing in [property]" | table ref, contradiction with named model, forward pointer | none (model named) | Figs. 3, 4; Table I |
| III.B | P2 | results | "A first result of interest: [law] still holds, as Figs. [n] show" | contrast with previous class, mechanism sentence, equations, prediction check | none | Figs. 3(b),4(b),3(a),4(a); eqs. (12),(13) |
| III.B | P3 | mechanism (model derivation) | "The fundamental problem now is to justify [parameter] on physical grounds" | citation, assumptions, equation chain, table check | cluster of 2, single | eqs. (14)-(17); Table I |
| III.B | P4 | discussion-or-limitation | "The validity and range of (eq) were tested more extensively in [refs]" | citation cluster, then limitation with condition, mechanism of failure | cluster of 3 | none |
| III.B | P5 | results (extension to other materials) | "It is natural to ask whether other [materials] behave per (eq)" | figure/table callout, uncertainty caveat, verdict | none | Figs. 5, 6; Table I |
| III.B | P6 | results (last conforming case) | "Fig. [n] reports a final case obeying [law], that of [material]" | contrast sentence, parameter statement | none | Fig. 7 |
| III.C | P1 | category-opener + results + design-implication | "Although [law] applies widely, no a priori reason guarantees universality" | figure callout, common feature, procedure, accuracy bound | none | Figs. 8-10; eq. (7) |
| III.C | P2 | discussion-or-limitation (future work) | "A proper [microscopic] interpretation of [nonlinear cases] is still lacking" | none | none | none |
| III.D | P1 | results + hedged synthesis | "Having discussed [quantity A], we briefly look at [quantity B] versus [variable]" | figure callout, belief statement, prediction check, deviation noted | single | Fig. 11; Figs. 1-10; eq. (15) |
| IV | P1 | method-objective (practical motive) | "One appealing feature of [representation] is obtaining [full dependence] from [limited input]" | figure callout | none | Fig. 12; Fig. 1(a) |
| IV | P2 | results (validation) + anomaly handling | "To interpret these data, consider what previous sections established about [terms]" | equation, procedure, number+condition, deviations explained | single | Fig. 11, Fig. 12, Figs. 3-6; eq. (18) |
| IV | P3 | design-implication + comparison with empirical rules | "Equation (n) shows two contributions to [dependence], proportional to [x] and [y]" | single citation, then interpretation sentence | single | eqs. (18), (3) |
| Concl | P1 | conclusion + research-agenda (final sentence) | "The interpretation of [results] presented here shows [tool] is promising for [connection]" | section/equation cross-refs, number+condition restated, future-work sentence | none | eqs. (7), (12)-(17); Sections II, IV |

## Summary-to-judgment turns
1. Intro P2, mid-paragraph: "[Model] is, however, too gross a simplification" -> backed by a mechanism sentence and a "generally found" empirical statement; flat, strong.
2. Intro P4, opening and closing: "Despite its achievements, [model] turns out to be of limited validity" ... "no general agreement as to [role] has yet been achieved" -> backed by citation clusters of contradicting findings and proposed mechanisms; flat, moderate-strong.
3. III.A P2: "Thus the statement, often found in the literature [refs], that [claim], seems somewhat inaccurate" then "Our results show, on the contrary, that [finding]" -> backed by own data plus an equation; hedged opener, flat contrast.
4. III.D P1: "We believe that this correspondence is not fortuitous but points at [relationship]" -> backed by a summary figure, an earlier model, and one prior ref; explicitly hedged.
5. IV P3: "This conclusion should be compared with [old empirical rules] [ref]" then "Our treatment provides a physical interpretation to these rules" -> backed by an equation; flat, positive.

## Figure and table roles
- Paired-panel data figures (raw curves left, transformed representation right): carry evidence for a law form and for model-data agreement; callout first, interpretation immediately after ("This representation clearly shows [fact]"; "One can notice the [excellent] agreement"); interpreted, never merely pointed; calculated curves overlaid on measured points; captions are long and interpretive (parameter values and fitting method live in captions).
- Perturbation figure (same sample, different pretreatment): mechanism illustration; qualitative explanation stated after the callout, then the transformed representation is used to make it quantitative.
- Cross-material summary figure: synthesis across all samples; claim stated after the callout and hedged ("We believe ..."); prediction vs data judged "in fair agreement" with one deviation noted.
- Validation figure (prediction from minimal input): evidence for a bounded accuracy claim; callout, procedure, number+condition, then deviations explained by named approximations.
- Table I (sample properties plus measured-vs-calculated columns): introduced in setup ("as listed in Table [n]"), reused twice as evidence ("As shown by the data in Table [n], predictions of (eq) agree [well]"); pointed at, not walked through; replaces prose for the numeric check.

## Introduction closing chain
- Paragraph count: 2 (framework announcement, then contributions); preceded by an accumulated gap across 3 paragraphs.
- Gap form: accumulated (first model too coarse -> refined model of limited validity -> several mechanisms proposed, no agreement); final gap sentence is one "no agreement ... yet" sentence.
- Contribution form: prose within one paragraph; two task-worded goals ("In the first place, we have carried out [study]"; "our second goal has been to interpret [results]") followed by three result-worded conclusions enumerated First / Secondly / Finally; total 2 goals + 3 conclusions.
- Organization paragraph: not observed as a separate paragraph; forward references are inline ("reported in Section [n]"; "As fully discussed in Sections [n] and [m]"; "it will be shown in Section [n]"), plus "here briefly reviewed in Section [n]" in the framework paragraph.
- Mapping: goal 1 -> results section; goal 2 -> results and prediction sections; third conclusion -> prediction section; the material-class split introduced in P4-P5 is reused in the second conclusion.

## Taxonomy (reviews only; else "n/a")
n/a (research article). Note only: results subsections are grouped on one implicit axis, conformity to a law form (obeys / does not obey), with the setup paragraph justifying the order of treatment by representativeness.

## Comparison
- Dimension kinds: model vs experiment (agreement within a tolerance under a stated variable range); own result vs literature statement; material class vs material class (by conformity to a law form, by microstructural scale, by whether a fit parameter depends on drive amplitude).
- Table introduction template: "[Quantity] were measured on [samples], as listed in Table [n]"; later "As shown by the data in Table [n], predictions of (eq) agree [well] with [observed]".
- Trade-offs vs winner: neither; agreement is graded ("excellent", "good", "fair", "within a few percent") and bounded by conditions.
- Differing conditions: each accuracy claim carries its variable range; a low-signal material gets an explicit uncertainty caveat; data scatter attributed to measurement precision.
- Rubric: not observed.
- Feeds a recommendation: yes, the prediction-from-minimal-input procedure is offered for characterization and optimization (Section IV opener, Conclusion).

## Research questions
Not explicit. Aims are stated as a "[n-fold] investigation" with two goals (Intro P6). One rhetorical question in results ("It is natural to ask whether other [materials] behave per (eq)") is answered in the same paragraph by a figure/table callout. Results restate the motivating contradiction rather than a question: "As discussed in the Introduction, [model] would predict [X], in clear contradiction with [data]" then "We will show now how this contradiction can be resolved". Open item (nonlinear cases) handled by a one-sentence future-work paragraph.

## Results ladder
- Rungs per figure (ladder repeats per material class, not once per section): observation 1-3 sentences; mechanism 2-5 sentences; implication 1-2 sentences.
- Observation verbs: reports, shows, is given, is found, obtain, increases, decreases, is obeyed, is fulfilled, reduce to (a single curve), is confirmed, is reproduced.
- Mechanism verbs/markers: "Physically, this simply means", indicates, "can be explained qualitatively by", "this explains why", "as expected from", "are due to the fact that", "arise from", implies, "points at".
- Implication markers: "This result leads to a first conclusion"; "has [immediate] practical consequences, since it implies"; "makes it an intrinsic parameter rather than"; "should be of interest in [application]".
- Interpretation placement: immediately after each callout within the same paragraph; the full causal derivation gets its own paragraph (III.B P3) between observation and validation; some mechanism deferred by forward pointer ("will be discussed in the next subsection").
- Anomaly handling: deviations attributed to named approximations with the condition where each fails (IV P2); scatter attributed to precision; large uncertainty acknowledged for one low-signal case; non-conforming materials get their own subsection and a shared feature is extracted; one residual deviation simply noted.
- Ending: bounded claim (accuracy within a tolerance above a frequency threshold, for the data presented) plus a practical implication and a physical reading of old empirical rules.

## Future work derivation
1. [microstructural meaning of a fit parameter in one material class is unverified] -> [further study, "future paper"] -> traced to open question raised in that paragraph (III.A P3); placement: mid-results.
2. [no microscopic interpretation for nonlinear cases] -> ["future investigations"] -> traced to limitation (model derivation covers only the linear case); placement: one-sentence paragraph closing III.C.
3. [general microstructural models of the key function across materials] -> [develop them; "main objective of future investigations"] -> traced to the admitted limitation in the same conclusion paragraph ("even where we are not yet able to predict [X] from a microscopic model"); placement: final sentence of the conclusion.
- One stated validity boundary (picture "expected to fail when [condition]", III.B P4) is not converted into a future-work item (untraced).
- Derived, not wish-list; pattern "[X] is still lacking / needs further study -> future paper"; "what it would take" named only generically.

## Section endings and synthesis (reviews only; else "n/a")
n/a. Observed anyway: subsections end with a forward pointer, a bounded remark with a citation, or a one-sentence future-work; the last results subsection functions as a hedged cross-material synthesis around one summary figure.

## Language signals
- Register: "we" throughout despite single authorship; "the author" (third person) once for prior work; "the present paper" / "this paper"; generic "one" ("permits one to"). Intro: present + future ("we shall examine", "will be shown"), present perfect for own past work. Theory: present, mixed active "we" and impersonal passive ("can be described", "is expected"). Setup: past passive ("were measured", "was obtained"). Results: present ("reports", "shows", "we obtain", "we find") with past passive for procedures ("were calculated"). Conclusion: present perfect + present. Highly formal; long subordinated sentences with parentheticals and equation numbers used as nouns; sentence length mean ~30 words, spread ~9-60; paragraphs 4-12 sentences (one 1-sentence future-work paragraph, one ~15-sentence derivation).
- Section openers: Intro "This paper aims to advance understanding of [phenomenon] for [audiences]"; theory "According to [theory] developed in [refs], the mechanism governing [quantity] is [X]"; setup "[Quantity] were measured on [samples], as listed in Table [n]"; results subsection "Fig. [n] reports [quantity] versus [variable] at [conditions]" or "Having discussed [A], we briefly look at [B]"; prediction section "One appealing feature of [representation] is [capability]"; conclusion "The interpretation of [results] presented here has shown that [tool] provides [benefit]".
- Gap/limitation shapes: "[model] is, however, too gross a simplification"; "[model] turns out to be of limited validity because [idealization]"; "it is commonly found that [contrary observation] [refs]"; "[observation] cannot be easily explained in terms of (eq)"; "attempts have been made to [link X to Y] [ref]"; "no general agreement as to [role] has yet been achieved"; body: "It is worth remarking, however, that [picture] is expected to fail when [condition]"; "[interpretation] is, at present, still lacking"; "The deviations at [condition] are due to [approximation failing]". Verbs: turns out, cannot be explained, has yet been achieved, is expected to fail, is lacking, needs further study. Proportion: one Intro paragraph of ~6 sentences plus one limitation sentence in P2 (~1/5 of Intro); body limitations are single sentences or a one-sentence paragraph.
- Contribution phrasing: prose, enumerated inside one paragraph (In the first place / second goal; First / Secondly / Finally); goals task-worded, conclusions result-worded; 2 + 3 items; inline section forward references; abstract repeats the enumeration with "In particular, we show that" / "Finally, [procedure] is discussed".
- Transitions: "However," (~8), "In fact," (~6), "In particular," (~5), "In this connection," (3), "As to [X]," (3), "therefore" (3), "On the other hand," (2), "Actually," (2), "Finally," (2), "Thus" (1), "Anyway," (1), "Of course," (1), "Incidentally," (1), "Notice that" (1). Paragraphs are mostly content-linked by anaphora on the previous result ("This result leads to", "These results can be explained", "The fact that [X] makes it", "Starting from these premises", "Having discussed [A]"); connective-led paragraph openers are rare ("As a final remark", "Although").
- Hedging: own fit vs own data: flat and strong ("clearly shows", "strictly followed", "excellent agreement", "well confirmed", "it is evident"); predictions across materials: graded ("in good agreement", "in fair agreement", "essentially valid", "to a good approximation", "approximately"); physical interpretation: hedged ("a possible interpretation", "a possible key", "can be explained qualitatively", "We believe ... not fortuitous", "suggests a possible mechanism", "should", "is expected to", "under reasonable assumptions"); literature judgments: one hedged ("seems somewhat inaccurate"), others flat ("too gross", "of limited validity"). Accuracy claims always carry a variable range and "for the data presented". Boosters: "certainly", "definitely", "by no means", "straightforwardly".
- Callout templates: figures "Fig. [n](a) reports [quantity] versus [variable] at [conditions]"; "The corresponding representation in [plane] is given in Fig. [n](b)"; "This representation clearly shows [fact], already stressed in [refs]"; "The [curves] in Fig. [n] were obtained by this procedure"; "One can notice the [excellent] agreement with [data]"; "It can be seen from these figures and Table [n] that [claim]"; "We see from Fig. [n] that, despite [caveat], [prediction] agrees [fairly]". Tables: "as listed in Table [n]"; "(see Table [n] for further information)"; "As shown by the data in Table [n], predictions of (eq) agree [well]". Equations: "[Model] predicts (eq)"; "By expressing [quantity] as (eq), the central problem becomes [X]"; "Equations (n) and (m) lead to (eq)"; "Equation (n) implies that, for [condition], [quantity] can be approximated as (eq)"; "Equations (n) and (m) have a number of remarkable consequences"; "From (n), (m), (k), we obtain (eq)"; "Equation (n) predicts that [quantity] should be proportional to [variable]".
- Comparison shapes: model vs data "[prediction] is well confirmed, apart from [scatter], by Figs. [n]"; "the agreement between (eq) and [data set] is within [tolerance] when [condition]"; "reproduced, in all cases, with an accuracy within [tolerance]"; own vs literature "Thus the statement, often found in the literature [refs], that [claim], seems somewhat inaccurate"; "This conclusion is in good agreement with the results reported in [refs]"; "Our treatment provides a physical interpretation to [empirical rules]"; class vs class "contrary to the case of [class A], [term] is now predominant"; "Although [property] is completely different from [class A], we find a rather similar behavior of [function]".
- Conclusion shape: one long paragraph; opens with what the interpretation "has shown"; restates findings in paper order with section and equation cross-references; repeats the headline accuracy with its condition; concedes the unpredicted cases with "However, even in the cases where we are not yet able to [X]"; ends with a single future-work sentence. No separate limitation paragraph.
- Generic connective phrases: "In this connection,"; "As fully discussed in [refs],"; "It is worth remarking, however, that"; "As previously pointed out,"; "On the other hand,"; "It is evident that"; "It can be seen that"; "It is interesting to notice that"; "Starting from these premises,"; "As a final remark, we point out that".

## Roles shown
- intro-context: 1
- literature-category: 2
- limitation: 2 (one shared with a literature-category paragraph)
- gap: 1 (accumulated; final sentence of the limitation paragraph)
- approach-and-contributions: 1
- contribution-list: 1
- organization: 0 separate (inline forward references in 2 Intro paragraphs)
- method-objective: 2
- model-or-assumption: 5
- mechanism: 3 (plus 1 shared with results)
- design-implication: 3
- setup: 2 (one shared with category-opener)
- results: 9
- comparison: 2 (own result vs literature statement)
- discussion-or-limitation: 4
- conclusion: 1
- research-agenda: 1 sentence in conclusion plus 2 sentences in results (no paragraph)
- category-opener: 3 (results subsections)
- synthesis: 1 (cross-material, hedged)
- research-questions, taxonomy-overview, cross-cutting-comparison: not observed
