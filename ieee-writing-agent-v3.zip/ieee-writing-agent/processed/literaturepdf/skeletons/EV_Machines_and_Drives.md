# Skeleton: EV_Machines_and_Drives
- Title: "Electrical Machines and Drives for Electric, Hybrid, and Fuel Cell Vehicles"; venue: Proceedings of the IEEE (invited paper); year: 2007 (as printed)
- Type: small comparative review with an embedded one-family taxonomy layer. Evidence: abstract frames the paper as reviewing the relative merits of three technology families against requirement dimensions listed in the Introduction; the emphasized family then gets a component-location topology taxonomy plus a numbered design-issue list; over a hundred references; no comparison table; no own experiments.
- Approximate paragraph count: 36 extracted blocks (page-chunks); ~60 true paragraphs inferred. Taxonomy figure/table: y (schematic gallery figures per category; no tree diagram, no table). Comparison tables: n (paper has no tables). Explicit RQs/hypotheses: n. Future-work section/paragraph: n.
- Extraction damage: paragraph breaks lost within pages (each block is a page chunk); several headings split mid-phrase with the remainder opening the next block; numbered design-issue sub-headings embedded inline; figure captions, running headers and copyright lines interleaved into body text; equations garbled; reference author-name fragments produced noise headings; dashes rendered as "V" and quotation marks as "B"/"[".

## Section list
1. Introduction
2. Technology family A section (the "most mature" family): 2.1 basic characteristics; 2.2 design for the application; 2.3 efficiency-and-noise operation
3. Technology family B section: 3.1 features; 3.2 operational characteristics; 3.3 extended-range operation; 3.4 noise-and-ripple reduction
4. Technology family C section (the emphasized family): 4.1 drive-mode comparison; 4.2 topology taxonomy by component location (three groups, seven lettered sub-cells); 4.3 design and control issues (six numbered issues); 4.4 recent developments (two numbered items)
5. Conclusion
6. Acknowledgment; References

## Paragraph map
| Section | Para | Function | First-sentence template | What follows the claim | Citation pattern | Figures/tables referenced |
|---|---|---|---|---|---|---|
| Introduction | I-1 (inferred) | intro-context | "[Technology class] is a key enabling technology for [application]" | bulleted requirement list (7 items) after a citation cluster; two add-on requirements | cluster of 3 | none |
| Introduction | I-2 | design-implication | "On [duty cycle], [device] operates most frequently at [condition]" | consequence sentence ("Therefore ... should be designed to ...") then figure callout | none | requirement-curve figure |
| Introduction | I-3 | literature-category / taxonomy-overview | "[A], [B], and [C] have all been employed in [application]" | gallery-figure callout; idealized-curve callout; region-by-region mechanism sentences; "However" remedy with single citations | single, then a pair | family gallery figure; idealized-characteristic figure |
| Introduction | I-4 | gap (weak) + design-implication | "In general, however, [aspects] for [the N options] differ significantly" | forward reference to the paper; principle sentence; "Hence, [approach] is essential" | none | none |
| Introduction | I-5 | approach-and-contributions | "This paper describes [scope] and reports [scope], with particular reference to [emphasis]" | none (paragraph ends) | none | none |
| 4.1 drive-mode comparison | D-1 | category-opener + comparison | "Due to [inherent feature], [class] are inherently [property] [cluster]" | classification by waveform (single, figure); mode definitions "In a [mode A] drive ..., while in [mode B] ..."; "Ideally ... In practice, however ..."; "Similar to [family A] drives, ..."; drive schematic callout | cluster of 10, single | waveform figure; drive schematic |
| 4.1 | D-2 | comparison | "In both [mode A] and [mode B] drives, [requirement] is necessary, although [resolution] differs" | paired contrast (low-cost option vs high-cost option); winding disposition per mode with figure panels; "However, [option] results in [cost] while [option] makes [manufacture] harder"; "Hence, it is often preferable to [measure] [single]"; forward reference to a later subsection | single x2 | winding-disposition figure; characteristic figure |
| 4.1 | D-3 | comparison (verdict) | "[Mode B] motors are relatively easy to control and exhibit excellent [performance] [cluster]" | "In contrast, [mode A] ... generally more complex"; "As was shown in [pair], above [threshold] [metric] in [B] is higher than [A], irrespective of [condition] (Fig.)"; high-speed mechanism; "However, by employing [strategy], [capability] can be improved, although [cost] [cluster], as illustrated in Figs. N and M" | cluster of 3, pair, cluster of 5 | three comparative-characteristic figures |
| 4.2 taxonomy | X-0 | taxonomy-overview | "In this section, the basic [items] of [class], classified according to [axis], are described" | none (single sentence) | none | none |
| 4.2.1 group 1 | X-1 | category-opener | "A [group] machine may have either [option] or [option], while [component] may be [position] or [position]" | sub-cell a): "This is the most widely used topology [Fig.]"; "However, since [property], they exhibit [drawback]" chain; forward reference; variant "Fig. N shows a schematic of ..." | none | gallery figure panels |
| 4.2.1 sub-cell b) | X-2 | category-opener -> mechanism -> example | "Fig. N shows examples of [class] in which [component] are [position]" | since/due-to chain -> "Therefore, generally, ... eminently appropriate for [mode] [pair]" -> "Indeed, a variant ... employed in [product] [single], Fig. N" -> variants with singles -> "By way of example, Fig. N shows [device] [single]" | pair, singles x4, pair | gallery panels; field-plot figure; prototype figure |
| 4.2.2 group 2 | X-3 | category-opener | "When [component] are located on [position], [counterpart] must have [geometry], similar to [other family]" | structural description; "Irrespective of their location, however, [torque mechanism]"; "Compared with conventional ..., generally, it is easier to [thermal benefit]" | none | none |
| 4.2.2 sub-cell a) | X-4 | mechanism -> limitation | "The machine topology shown in Fig. N(a) is referred to as [name]" | count rule; waveform -> "Thus, more suitable for [mode]"; "However, [remedy]"; "Further, it will be noted ..."; "Therefore, [issue] not significant"; "However, a major disadvantage is ... [single], although, as reported in [single], ..." | single x3 | gallery panel |
| 4.2.2 sub-cell b) | X-5 | mechanism -> limitation | "This machine topology is also commonly referred to as [name] [Fig.] [cites]" | operating mechanism; "Thus, [quantity] is [shape], while [waveform] essentially [shape]"; drawbacks stacked with "while / In addition / Further, since ..." | pair | gallery panel |
| 4.2.2 sub-cell c) | X-6 | mechanism -> design-implication | "This machine topology is also referred to as [name] [Fig.] [cites]" | structure; "Thus, [feature] may be readily incorporated, so that [benefit] [single]"; "In addition, in contrast to conventional ..."; "As a consequence ..."; "Therefore, since ..., [capability] is significantly higher than [sibling cell] [single]"; closes "eminently suitable for [mode]" | cluster of 3, single x2 | gallery panel |
| 4.2.3 other, a) | X-7 | category-opener -> limitation | "[Group] machines have [defining feature] [cites] and can comprise [config], [config], or [config]" | "In each case, [issue]"; "As with conventional ..., although more difficult to [manufacture]"; "Thus ... more common. However, while this eliminates [issue], it exposes [component]. Hence ... Further, since ..., which may limit [capability]" | pair | none |
| 4.2.3 other, b) | X-8 | category-opener -> limitation | "Generally, [group] machines have [feature], all of which [mechanism]" | "This enables [benefit] [cluster]. However, they have [drawbacks] [pair]. This impacts significantly on [system cost], which has inhibited its application" | cluster of 5, pair | none |
| 4.3 design issues, opener | T-0 | method-objective | "As stated earlier, [application] machines are required to have [property list]" | section-purpose sentence; "However, they often contradict each other"; example pair of conflicts | none | none |
| 4.3 issue 1 | T-1 | model-or-assumption -> design-implication | "The general [quantity] equation for [class], which has [components], is given by [eq]" | equation; symbol definitions; four design measures each "as illustrated in Fig. N" | pair x2 | four mechanism-illustration figures |
| 4.3 issue 2 | T-2 | model-or-assumption -> comparison | "It is well known [cites] that [capability], defined as [ratio], under [constraints], is achieved when [condition]" | equation; "Although ... generally ... since ..."; figure callout; single-paper examples "in [n] ... was achieved with [design]"; closing category verdict "much easier to achieve with [category], since ..." | pair, then single x3 | parametric-curve figure (two panels) |
| 4.3 issue 3 | T-3 | mechanism -> design-implication | "Operation in [mode] is a necessary requirement for [application], while [material] is the most commonly employed" | "However, [requirement]"; "one means of ... is to [measure]"; figure callout; side-effect "However"; category verdict; "Nevertheless, it has been shown [single] that ..." | single | design-measure figure (two panels) |
| 4.3 issue 4 | T-4 | mechanism + limitation | "[Class] are usually considered to have negligible [loss]" | "However, ... may be important in [subclass]"; cause list a)-c) [single]; "In general, however, ... Nevertheless ..."; when-it-matters list a)-d) [single]; remedy [single] | single x3 | none |
| 4.3 issue 5 | T-5 | cross-cutting-comparison | "Due to [fixed excitation], [loss] increases with [speed], while [loss] under [condition] is generally [range] higher" | "However, ... depends on [topology], as illustrated in Fig. N"; per-category ranking sentences with single citations | single x3 (one pair) | comparative-curve figure |
| 4.3 issue 6 | T-6 | discussion-or-limitation | "An important consideration when operating in [mode] is the consequence of [fault] [cites]" | "In this regard, [category] may be advantageous, since ..."; closes "However, ... remains a challenging issue" | pair | none |
| Conclusion | C-1 | conclusion | "The [aspects] for [A], [B], and [C] for [application] have been reviewed, with emphasis on [dimensions]" | reason-for-emphasis ("Given that they offer [advantage] ..."); "Various [topologies] have been highlighted ..."; even-handed verdict "In general, however, all [N] ... can meet [requirements], and each has merits" | none | none |
| Future work | -- | not observed | -- | -- | -- | -- |

## Summary-to-judgment turns
1. Editorial deck, abstract and conclusion: "[A] and [B] can provide [requirement], but [C] offer higher [metric]"; backed only by the body's qualitative review; flat and unhedged in the deck, softened in the conclusion by "In general, however, ... each has merits".
2. Family-section openers: "Of the [N] [options] under consideration, [X] are the most [attribute]"; no backing (bare assertion); flat.
3. End of a technique catalog (noise subsection; fault-tolerance issue): "In general, however, [issue] remain(s) a significant issue" / "[issue] remains a challenging issue"; backed by the preceding catalog in which every technique was paired with a "However" limitation; moderate, hedged by "in general".
4. Mid-catalog single-paper singling-out: "However, the method proposed in [n] is arguably the most effective, in that [mechanism]" immediately followed by "However, it has limitations [n], since [condition]"; backed by one citation plus a counter-citation; hedged ("arguably") then bounded. Same shape for cited results: "However, the machines under consideration had [limitation]".
5. End of a since/due-to chain in a category cell or operation subsection: "Therefore, generally, such [topologies] are eminently appropriate for [mode] [pair]" / "Clearly, the foregoing [characteristics] are appropriate for [application]"; backed by the mechanism chain plus a citation pair (or nothing for "Clearly"); strong adverbs tempered by "generally".

## Figure and table roles
- Requirement and idealized-characteristic curves (Introduction): carry the operating-envelope claim; claim stated before the callout ("are illustrated in Fig. N"); interpreted region by region after the callout; back-referenced later as "As was shown in Fig. N".
- Topology gallery schematics (per family, per taxonomy cell): are the taxonomy artifact (gallery, not tree); pointed at in brackets appended to the naming sentence "[name] [Fig. N(x)]"; the text then explains mechanism, not the picture.
- Prototype/example machines: "By way of example, Fig. N shows [device] developed for [application] [single]"; evidence-by-example; ratings live in the caption, not the prose; pointed at, lightly interpreted.
- Characteristic curves from cited work: evidence for a comparative claim; claim stated first, callout in parentheses or "as illustrated in Figs. N and M"; one is walked through with an enumerated observation list "It will be observed that: 1) ...; 2) ...; 3) ..."; the rest merely pointed at.
- Design-measure illustrations: mechanism illustration; "[measure], as illustrated in Fig. N" appended to the design-implication sentence; pointed at, not interpreted.
- Equations: introduced "[quantity] is given by [eq]" then "where [symbols] ..."; interpreted as proportionality/design levers in the following sentences; back-referenced "As will be evident from (n), ..." and "easier to satisfy (n)".
- Tables: not observed.

## Introduction closing chain
- Paragraph count: 1 inferred (breaks lost); three moves in three consecutive sentences plus one scope sentence.
- Gap form: one sentence, weak, contrast-with-"however" ("[aspects] differ significantly, as will be discussed"); no literature gap, no "no prior review" claim; supplemented by a design-principle sentence ("cannot be undertaken in isolation" -> "Hence, [approach] is essential").
- Contribution form: prose, one sentence, task-worded ("describes [scope] and reports [scope]"), two items; emphasis clause ("with particular reference to [family]"); no numbering, no novelty claim.
- Organization paragraph: not observed; forward references only ("as will be discussed in this paper", "as will be discussed later", "Section [n]").
- Mapping to sections: implicit; the three families enumerated in I-3 become the three main sections in the same order; the emphasized family gets the deepest subsection tree.

## Taxonomy
- Axes: (1) top level by technology family / operating principle (three cells, exclusive, one level, enumerated in the Introduction); (2) within the emphasized family, by drive/control mode paired with waveform shape (two cells; matrix-like, since the text says any machine may be operated in either mode with performance compromised); (3) by component location (announced explicitly; exclusive; depth 3: field orientation -> which member carries the component -> position on that member; plus an "other" bucket for non-radial cells); (4) a numbered design-issue list (six issues) and a recent-developments list (two items) that are dimension lists, not taxonomy.
- Justification: minimal; the location axis is stated as the criterion without argument; the family split is justified by "have all been employed" plus "design considerations differ significantly".
- Announcement template: "In this section, the basic [items] of [class], classified according to [axis], are described."
- Placement: gallery figures per group appear after the announcement and are cited inside the cells; the top-level family gallery sits in the Introduction beside the enumeration.
- Category opening: defining structural sentence ("When [component] are located on [position], [counterpart] must have [geometry]") or a positioning sentence ("most widely used", "most mature"); sub-cells open "This [item] is also referred to as [name] [Fig.] [cites]". Closing: a suitability verdict for an operating mode ("eminently suitable for [mode]") or a drawback that limits adoption ("which has inhibited its application"); no synthesis paragraph.
- Cross-cutting themes (losses, demagnetization robustness, extended-speed capability, fault tolerance): handled in a separate numbered-issue section after the taxonomy, each issue containing per-cell comparative sentences ("In general, [cell A] have the lowest ...; [cell B] generally have significantly higher ...").
- Reuse: location cells reused as comparison anchors in every design issue and in recent developments; conclusion reuses only the family level ("various topologies have been highlighted").

## Comparison
- Dimension kinds: performance metrics (torque/power density, efficiency, speed-range ratio, overload capability); robustness (thermal, fault tolerance, demagnetization); manufacturability and cost; noise/vibration/ripple; control complexity; sensor requirement; converter rating and power factor.
- Table introduction: n/a (no table). Comparison carried by bulleted feature lists per family (with "However" inside bullets) and prose contrasts: "Compared with [baseline], [subject] [verb] [attribute]"; "In contrast, [B] is generally more complex"; "[X] exhibits a much wider [metric] than [Y], which compares to [Z] for [W] [cite]"; "the higher the [X], the higher the [Y]".
- Trade-offs vs winner: predominantly trade-offs ("requires a compromise between [A] and [B]", "albeit", "although"); a soft winner is declared in the deck and abstract, then the conclusion is even-handed.
- Differing conditions: attached inline ("for a given [rating]", "when [parameters] were fixed and [parameter] varied", "under [constraint]", "irrespective of whether [condition]"); a cited result is bounded immediately by "However, the machines under consideration had [limitation]".
- Rubric: not observed.
- Recommendation: per-cell suitability statements ("more suitable for [mode]") and design guidance ("should be designed such that [condition]", "it is again beneficial to minimize [quantity]").

## Research questions
n/a (none explicit; no hypotheses; sections answer the requirement list from the Introduction implicitly).

## Results ladder
Review version: cited evidence is interpreted, not reported. Pattern per claim: claim -> citation -> mechanism -> design implication. Observation verbs: "shows", "was shown", "was achieved", "exhibits", "increases with", "reduces", "results in". Mechanism markers: "since", "due to", "result from", "as a consequence", "in turn", "thereby". Implication markers: "therefore", "thus", "hence", "should be designed", "is beneficial", "is advantageous", "is preferable". Interpretation sits in the same sentence or the next one; one figure gets an enumerated observation list. Anomaly/qualification handling: "However" immediately after a favourable claim; "although", "albeit", "to some degree", "nevertheless". The ladder ends in design guidance or a suitability verdict; numbers, where present, are bounded by their condition and never aggregated.

## Future work derivation
- Future-work section or paragraph: not observed; conclusion contains none.
- Open-issue closers in the body (untraced to any agenda): [noise emissions of one family] -> [what it would take: not stated] -> traced to limitation (catalog of partial remedies); [inverter-fault consequence in extended-speed mode] -> [not stated] -> traced to limitation; [optimal operating level must be found experimentally] -> [a general analytical method, implied] -> traced to limitation. Placement: last sentence of a subsection or numbered issue. Neither wish-list nor derived agenda: problems are flagged and left.

## Section endings and synthesis
- Category sections end with a verdict sentence, not a synthesis paragraph: "Clearly, the foregoing [characteristics] are appropriate for [application]"; "In general, however, [issue] remain(s) a significant issue"; "In general, however, it is much easier to achieve [capability] with [category], since ..."; one mid-section "In summary, not only is [A] ..., but [B] ..." recap.
- Final synthesis: one paragraph relating families by restating scope, giving the reason for emphasis on one family, and an even-handed verdict; no per-family synthesis, no table.

## Language signals
- Register: "this paper" (Introduction only); "the authors" only in the acknowledgment; never "we". Present tense for mechanisms and general tendencies; past tense for cited results ("it was shown that", "was achieved", "was described in"); present perfect in the conclusion ("have been reviewed", "has been given"). Passive dominates reporting ("is given by", "may be employed", "has been shown", "are described"); active for physical mechanisms. High formality with "viz.", "i.e.", "e.g.", "albeit", "hence", "thereby", "in turn". Sentence length mean ~30 words, spread ~8-70, many multi-clause chains with "while/since/although/which". Inferred paragraphs 4-8 sentences; extracted blocks 10-25.
- Section openers: family section "Of the [N] [options] under consideration, [X] are the most [attribute]" then "In this section, [items] are briefly reviewed and [items] highlighted"; features subsection "The [aspects] of [X] are well-documented [cites], and may be summarized as follows"; operation subsection "[X] are usually operated in [mode], although [alternative] may be advantageous under [conditions]"; capability subsection "[X] is capable of [capability], typically up to [range] [cite]"; problem subsection "The [problem] radiated from [X] is often cited as a major disadvantage"; taxonomy announcement as above; design-issue section "As stated earlier, [application] machines are required to have [property list]"; recent-developments item "[Class] which have [feature] have been the subject of recent research"; conclusion "The [aspects] for [A], [B], and [C] for [application] have been reviewed".
- Gap/limitation shapes: sentence-initial "However, [drawback]" dominates (several per paragraph); concessive "although / albeit / while" clauses; "a major disadvantage is that ..."; "is often cited as a major disadvantage"; "which has inhibited its application"; "remains a challenging/significant issue"; "it has limitations [cite], since ... much less effective with [condition]"; "no general and simple [method] is available". Proportion: nearly every advantage sentence is paired with a limitation; roughly two of every five sentences in category cells are concessive.
- Contribution phrasing: one prose sentence, task-worded, two items, with an emphasis clause; no numbered list, no novelty claim.
- Transitions: "However" (dominant, sentence-initial, also "In general, however," "Generally speaking, however," "Nevertheless"); "Thus / Therefore / Hence" (implication, frequent); "Further / In addition / Also" (accumulation, frequent); "In contrast / Comparatively / Compared with / Similar to / On the other hand" (comparison, moderate); "For example / By way of example / e.g." (moderate); "Indeed / Clearly" (emphasis, rare); "As stated earlier / as will be discussed later / As was shown in Fig." (cross-reference, moderate); "In summary / Finally" (closure, rare). Paragraphs link mainly by content (topic noun in first sentence); sub-cells link by lettered/numbered labels.
- Hedging: "generally", "in general", "usually", "typically", "relatively", "may", "can", "tends to", "essentially", "to some degree" attach to class-wide tendency claims; cited specific results are flat past tense; mechanism claims are flat present tense; strong verdicts use "Clearly", "eminently", "significantly", "It is well known"; single-paper superlatives are hedged with "arguably".
- Callout templates: figure appended "[claim], as illustrated in Fig. N." / "[claim] (Fig. N)." / "[name] [Fig. N(x)]"; figure leading "Fig. N shows a schematic of [item]." / "By way of example, Fig. N shows [item] developed for [application] [cite]." / "Typical [items] are shown in Fig. N, together with [item]."; figure interpreted "It will be observed that: 1) [obs]; 2) [obs]; 3) [obs]."; back-reference "As was shown in Fig. N, [restated claim]."; equation "[Quantity] is given by [eq] where [symbols] ..." then "As will be evident from (n), [proportionality]."; table: not observed.
- Comparison shapes: "Compared with [baseline], [subject] [verb] [attribute]."; "[X] exhibits a much wider [metric] than [Y], which compares to [Z] for [W] [cite]" with the setup condition attached ("when [parameters] were fixed"); "the higher the [X], the higher the [Y]"; "[metric] in [mode B] is higher than [mode A], irrespective of [condition]"; "although it can still be higher than that of [reference class]"; "Similar to [X], [Y] ..."; "In contrast, [B] is generally more complex."
- Conclusion shape: one paragraph, four sentences: scope in present perfect -> reason for emphasis -> what was highlighted -> even-handed verdict; no numbers, no limitations of the review, no future work.
- Generic connective phrases: "By way of example,"; "As stated earlier,"; "as will be discussed later"; "In general, however,"; "It is well known that"; "It will be observed that"; "as illustrated in Fig."; "irrespective of whether"; "In this regard,"; "Of the [N] ... under consideration".

## Roles shown
- intro-context: 1
- literature-category: 1 (plus 3 per-family feature paragraphs of the same shape)
- limitation: 3 (paragraph-level; sentence-level in nearly every paragraph)
- gap: 1 (weak)
- approach-and-contributions: 1
- contribution-list: not observed
- research-questions: not observed
- organization: not observed (forward references only)
- method-objective: 3 (section-opening scope sentences)
- model-or-assumption: 3 (equation paragraphs)
- mechanism: ~15
- design-implication: ~10
- setup: not observed
- results: not observed (no own results)
- comparison: ~6
- discussion-or-limitation: 3
- conclusion: 1
- abstract (own label): 1 (four passive task-worded sentences ending "Finally, [methods] are described")
- taxonomy-overview: 1 (plus the Introduction enumeration)
- category-opener: ~13 (3 family, 3 group, 7 sub-cell)
- cross-cutting-comparison: ~6 (design-issue items)
- synthesis: 2 (sentence-level verdicts and one "In summary" recap; no synthesis paragraph)
- research-agenda: not observed
