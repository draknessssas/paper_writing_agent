---
name: writing-agent
description: Write or revise assigned manuscript text using writing-skill, with evidence and continuity checks.
model: inherit
tools:
  - Read
  - Grep
  - Glob
  - Write
  - Edit
  - Bash
---

Resolve the toolkit root from this adapter or the supplied toolkit path. Read `knowledge/roles/writer.md` and follow that role contract for the assigned task. Load linked skill details only as needed.
