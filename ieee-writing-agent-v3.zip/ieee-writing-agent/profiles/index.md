# Writing profile index

This index routes to existing profiles; it does not add new corpus findings. Source corpus: 13 papers processed on 2026-09-11. Full source notes and skeletons remain unchanged. Read relevant headings using search/section extraction, not both profiles in full for every paragraph.

Active selection comes from `active_profile.yml`. `language_style.md` and `argument_architecture.md` are descriptive writing preferences. Current user requirements and `knowledge/prose_quality.md` govern evidence, uncertainty and required disclosure even when an older profile uses imperative wording.

| Task | Read these existing headings |
|---|---|
| Local grammar or compression | Relevant Register / Transitions / Hedging calibration in language_style.md only if needed |
| Literature category or comparison | Architecture A3–A5, B2; language Comparison shapes |
| Taxonomy or review synthesis | Architecture B1, B7 and A4/A5 |
| Introduction gap/contribution | Architecture A7, B3; language Gap and limitation shapes / Contribution phrasing |
| Results interpretation | Architecture A3, B5; language Hedging calibration / Comparison shapes |
| Future work | Architecture B6; language Conclusion shapes |
| Captions/callouts | Language Callout templates; architecture A6; consult built-in moves for sparse coverage |
| Choosing a less familiar role | Architecture Role coverage first, then the relevant heading |

Coverage: 22 calibrated roles, 2 thin (research questions, captions), 1 not learnable here (response to reviewers). “Calibrated” describes sample coverage, not universal correctness. Corpus spans IEEE engineering and electricity forecasting; use the relevant paper type rather than mixing every habit.

## Existing files

- [Language profile](language_style.md)
- [Argument architecture](argument_architecture.md)
- [Per-paper skeletons](../processed/literaturepdf/skeletons/)
- [Built-in role examples](../skills/writing-skill/references/section-moves.md)

`author_style` is empty by default and no author profile is needed for normal writing. To use one, run `style-profiler <folder> author` and point `author_style` in `active_profile.yml` at the file it writes. The pre-2026-09 profiles built by the retired TPEL profilers were removed on 2026-09-14; they were never read by these skills and are recoverable from git history (`git show ed7d60d:profiles/author_style/current.md`).
