# Language Style Profile

## Source corpus
- Folder: `/home/draknessssas/Review_DT/literaturepdf` (13 papers); processed text in `processed/literaturepdf/`; per-paper skeletons in `processed/literaturepdf/skeletons/`.
- Venues: IEEE Transactions (Industrial Electronics, Industrial Informatics, Magnetics, Energy Conversion), IEEE Communications Surveys and Tutorials, IEEE Access, Proceedings of the IEEE, International Journal of Forecasting, Energy Economics, Applied Energy; 1988 to 2021.
- Two sub-corpora: electric machines, drives, magnetic materials, smart grid (9 IEEE papers, tagged [IEEE]) and electricity price forecasting (4 Elsevier papers, tagged [EE]). For a review of electric machine drives the [IEEE] habits are the closer match.
- Date generated: 2026-09-11.
- Extraction risks: paragraph breaks lost in most PDFs, so paragraph lengths are estimates; equations garbled; captions inlined; sentence-length figures are analyst estimates, not counts.

## Register
- Person: [IEEE] impersonal. "This paper" or "this survey" for self-reference (five papers), "the authors" in third person for the writers' own prior work and opinions ("it is the belief of the authors that"; "to the authors' best knowledge"), "we" absent or confined to derivations ("we obtain (n)"). [EE] and the two tutorial surveys use "we" throughout ("we consider", "we observe", "we believe"), including a single-author review.
- Tense: present for mechanisms, definitions, and what figures show; present or present perfect for the state of the field ("have been proposed"); past for procedures and for specific cited results ("it was shown that", "was achieved"); present perfect for the conclusion's restatement ("This paper has reviewed", "we have conducted"); future only for forecasts and forward references.
- Voice: [IEEE] passive dominant for reporting ("is presented in [n]", "are summarized in [n]", "is given by", "has been shown"), active with inanimate subjects for mechanisms and callouts ("Fig. [n] shows", "The equation shows that", "[element] increases [property]"). [EE] active with "we"; passive for conventions and naming ("is denoted by").
- Formality: high, with "i.e.", "e.g.", "viz.", "albeit", "hence", "thereby"; evaluative adjectives appear in judgments of the field ("excellent", "very effective", "impressive", "very limited") and are hedged when applied to the writers' own work.
- Sentence length: mean about 25 words (range of means 20 to 30 across papers); spread 8 to 60, long tails from symbol lists, enumerations, and bracketed figure pointers; short declaratives after equations ("The result is (n).").
- Paragraph length: research articles 4 to 9 sentences, results paragraphs up to 12 with bulleted observation lists; reviews 5 to 15 sentences, catalogue paragraphs up to 20; conclusions 1 paragraph of 4 to 7 sentences or a bullet list; numbered and bulleted lists replace paragraphs freely in both sub-corpora.

## Section openers (slot templates)
- Introduction: "[Technology] has reached the status of [maturity]." / "[Phenomenon] results from the interaction of [A] and [B] due to [cause]." / "[Drivers] are making [technology] increasingly competitive for [use]." / "When [pioneer] showed [phenomenon] in [year], [field] began." / "There is no consensus in [literature] on [design choice]." / "[System] has remained unchanged for [duration]."
- Survey or review section: "Of the [n] [options] under consideration, [X] are the most [attribute]." then "In this section, [items] are briefly reviewed and [items] highlighted." / "In this section, we explore [topic]. We first classify [works] according to [axis A] and then according to [axis B]." / "The following gives a short introduction on [items]."
- Category or family: "[Family] are [definition] with [property]." / "[Family] is generally the most [attribute] due to [reason]." / "[Category] are widely investigated for [application] because of [merits]; however, [restriction] [ref]." / "The block diagram of the [scheme] is shown in Fig. [n](a)."
- Fundamentals or theory: "The use of [representation] is an efficient method for [modeling task] [ref]." / "According to [theory] developed in [refs], the mechanism governing [quantity] is [X]." / "In the standard version of [reference scheme], [quantity] is used as [role]."
- Method or model: "As indicated in the Introduction, [goal] is to propose [artifact] for [task]." / "The [ordinal] [model] for [task] is [architecture]." / "Our choice of [models] is guided by [literature] and [aim]."
- Setup: "[Quantity] were measured on [samples], as listed in Table [n]." / "For each of [n] datasets we have [test length]." / "Throughout, the calculations are for [machine type] in which [dimensions] are [values]."
- Results: "Fig. [n](a) reports [quantity] versus [variable] at [conditions]." / "In Table [n] we can clearly see [pattern]." / "Table [n] compares [models] in terms of [metrics]." / "The oscillogram in Fig. [n] demonstrates [performance] at [condition]."
- Discussion: "To discuss [results], we distinguish between [n] topics: [list]." / "Something worth discussing is why [X]." / "Throughout the text, we have mostly considered [choice]."
- Future directions: "In the previous sections, we have looked back at [period] of [topic]. Now, it is time to look ahead." / "Although [system] is promising, we still face many challenges."
- Conclusion: "This paper has reviewed [topic] for [application]." / "The [aspects] for [A], [B], and [C] for [application] have been reviewed, with emphasis on [dimensions]." / "We have conducted an extensive [study] to address [question]." / "In this paper, [n] [models] to [task] are proposed." / "Certain [parameters] can have a very significant effect on [quantity], in particular [parameter]."

## Gap and limitation shapes
- Absence: "there has been no [thorough] study to date"; "there has not yet been, to our knowledge, an attempt to [X]"; "The literature misses a systematic [comparison]"; "an objective [comparison] is currently missing, to the best of our knowledge"; "To the best of our knowledge, only [n] papers have [done X]"; "[Topic] has barely been touched upon"; "[Practice] has been neglected / downplayed in the literature".
- Inadequacy of prior work: "Despite its achievements, [model] turns out to be of limited validity because [idealization]"; "[model] is, however, too gross a simplification"; "[ref] proposes [X] but is only compared against [simple baselines]"; "the test dataset only comprises [short period]"; "[studies] either avoid [comparison] [refs] or resort to [outdated practice] [refs]"; "even the largest [prior efforts] have been limited to [n], so a conclusion on [X] cannot be drawn"; "the results are not truly comparable unless [condition]".
- Drawback of a method (reviews): "However, [drawback]"; "a major disadvantage is that [X]"; "is often cited as a major disadvantage"; "However, the price for [benefit] is [cost]"; "is difficult to apply in practice since [mechanism]"; "suffer from certain drawbacks"; "which has inhibited its application"; "remains a challenging / significant issue"; "Due to [constraint], [approach] is not always possible"; "[X] requires [Y] and, therefore, [parameters] must be known".
- Own limitation (articles): "Although there is no formal basis for [relation], it has been found that [trend]"; "these are just hypotheses; further research is necessary"; "[picture] is expected to fail when [condition]"; "[interpretation] is, at present, still lacking"; "The current evidence supports [X]; [Y] is not the focus of this study".
- Verbs: require, assume, neglect, limit, restrict, depend on, cannot, lacks, misses, remains open, has not been shown, turns out, is limited to, is not observable.
- Proportion and placement: in reviews nearly every advantage sentence is paired with a "However" limitation and every category paragraph ends with one; in articles about one limitation sentence per literature paragraph and a handful of own-limitation sentences inside results or discussion, never a separate limitations paragraph.

## Contribution phrasing
- [IEEE] reviews: one prose sentence, task-worded, 1 to 2 items: "This paper describes [scope] and reports [scope], with particular reference to [emphasis]."; "The purpose of this paper is to give [review] and to put in evidence [differences]."; "This paper briefly summarizes [scope] where [objects] are [applied]."; with inline pointers "i) [item] (Section n); ii) ..."; or "Our survey complements [prior surveys] in that we: 1) [task]; and 2) [task]. The novelty of this survey is in [aspects]."
- [EE] and benchmark papers: "the main contribution of this paper is to propose [artifact]" followed by a numbered task-worded list and one result-worded sentence ("leads to improvements that are statistically significant"); "We tackle [problems] via [n] contributions: 1) We analyze ...; 2) We propose ...; 3) We provide ..." each with the artifact's location.
- Research articles [IEEE]: "In the paper, the effect of [parameter] on [quantity] is investigated, and its relationship with [parameters] is considered, with respect to [class]."; "Starting from these premises, this paper presents a [n-fold] investigation. In the first place, ... Our second goal has been to ... First, ... Secondly, ... Finally, ..." with section pointers; the abstract carries the result-worded version ("It is shown that [finding]").
- Conclusions restate with present perfect and past participles: "have been reviewed / systematically presented / briefly examined / indicated"; "we have shown that [finding] but [trade-off]".

## Transitions
- Contrast: "However" is the dominant connective in every paper (often 20 to 60 uses), sentence-initial and mid-sentence; "In general, however,"; "Nevertheless"; "In contrast" / "Contrarily" / "Instead"; "On the other hand" ([EE] paired "On the one hand ... On the other hand").
- Consequence: "Therefore" / "Thus" / "Hence" (very frequent in [IEEE], often before an equation or a design rule); "As a result"; "Consequently".
- Accumulation: "Moreover" / "In addition" / "Furthermore" / "Further" / "Also"; "Besides" ([IEEE] reviews).
- Example and specificity: "For example" / "For instance" / "By way of example"; "In particular" / "Particularly" / "More specifically" / "In detail".
- Attention markers (frequent, but see conflicts below): "Note that"; "It should be noted that"; "It is important to note that"; "Recall that".
- Cross-reference as transition: "As stated earlier"; "As mentioned in Section [n]"; "As will be discussed later"; "As was shown in Fig. [n]"; "see Section [n]"; "As indicated in the Introduction".
- Enumeration and closure: "First, ... Second, ... Third, ..."; "Finally,"; "In summary," / "In brief," / "To summarize," / "Summing up,".
- Linking mode: paragraphs link mainly by content (the topic noun or the scheme name opens the paragraph; "This result leads to"; "Having discussed [A], we now"); connective-led openers are common inside enumerations and in the forecasting papers; category subsections link by lettered or numbered labels and by naming the previous method's limitation.

## Hedging calibration
- Flat (no hedge): definitions; mechanisms derived from equations ("Equation (n) shows that"); readings of the writers' own tables and figures ("we can clearly see", "It is obvious from Fig. [n] and Table [m]"); cited findings with attribution and condition; recommendations and design rules ("should", "is preferable", "must be avoided", "we strongly suggest"); judgments about the field in reviews ("very limited", "cannot be established"); significance-test outcomes.
- One hedge, tied to an evidence gap: mechanisms not directly measured ("a plausible explanation may be", "this may be related to", "probably due to", "seems to"); class-wide tendencies ("generally", "typically", "usually", "in general", "tends to"); emerging-technology promise ("potentially", "can be expected", "may be compromised"); the writers' own picks and forecasts ("it seems", "arguably", "we believe", "it is expected that"); gap claims ("to the authors' best knowledge").
- Anomaly markers: "Somewhat surprisingly", "Interestingly", "in contrast to [prior]", followed by a hedged cause.
- Where claims are flat but the knowledge files require evidence: certainty adverbs ("obviously", "clearly", "it is evident", "it is well known", "without a doubt") appear in the older [IEEE] papers and in field judgments; `knowledge/prose_quality.md` treats these as audit items, replace with the number, the figure, or the reference.
- Numbers always carry a condition ("at [frequency]", "for [market, period]", "along [cycle]", "under the same specifications", "for the data presented") and, for measurements, the instrument or method.

## Callout templates (figures, tables, equations)
- Figures, callout first (results): "Fig. [n](a) reports [quantity] versus [variable] at [conditions]." / "In Fig. [n], we plot [quantity] over [period]." / "The oscillogram in Fig. [n] demonstrates [performance] at [condition]." / "To illustrate [observation], we depict in Figs. [n] and [m] [quantity]." then "It will be noted that [observation]." / "As we can see, [observation]." / "It will be observed that: 1) [obs]; 2) [obs]; 3) [obs]."
- Figures, claim first (reviews): "[claim], as illustrated in Fig. [n]." / "[claim] (Fig. [n])." / "[name] [Fig. [n](x)]" / "This is illustrated in Figs. [n] and [m], which show the effect of [parameter] on [quantity]." / "The advantage of [property] is further shown in Fig. [n], where [quantity] is presented for [conditions]."
- Figure reading guides for complex plots: encoding sentence -> worked example -> observations ("Looking closely at Fig. [n] we observe [result]").
- Taxonomy and structure figures: "Fig. [n] gives a schematic overview of the [methodologies] applied to [problem]." / "Fig. [n] shows the detailed classification of these [n] systems." / "The block diagram of [X] is shown in Fig. [n](a)." / "The resulting [diagram] is shown in Fig. [n]."
- Tables: "Table [n] compares [items] in terms of [metrics]." then "Several observations can be made:" / "[Values] are reported for all [n] datasets in Table [n]." / "as shown in Table [n]" / "[values] are given in Table [n]" / "An overview of [items] can be found in Table [n]." / "As shown by the data in Table [n], predictions of (n) agree [well] with [observed]."
- Equations: "[Quantity] can be expressed in the general form: (n) where [symbol] is [definition]." / "[Quantity] is given by (n), where [symbols] ..." / "Equation (n) shows that [dependency]." / "It follows from (n) that (m)." / "From (n), (m), and (k), we obtain (j)." / "As will be evident from (n), [proportionality]." / "Comparing (n) with (m), it is clear that [X]." / "[Step] yields (n)." / "The result is (n)."
- Back-references: "As was shown in Fig. [n], [restated claim]." / "see Table [n] and compare with Tables [m] and [k]" / "note that [method] is also best in Table [n]".

## Comparison shapes
- Trade-off: "[A] has higher [x] in [region], but lower [x] in [other region] [ref]." / "[benefit] at the price of [cost]." / "However, the price for [benefit] is [cost]." / "requires a compromise between [A] and [B]."
- Against a baseline with condition: "Compared with [baseline], [subject] [verb] [attribute] at [condition], because of [feature]." / "[X] exhibits a much wider [metric] than [Y], which compares to [Z] for [W] [ref]." / "[method] reduces [time] by up to [magnitude] with respect to [baseline]." / "[quantity] in [case A] is usually about [ratio] of that in a similar [case B]."
- Statistical: "[A] is statistically significantly better than [B] except [C]." / "The difference is significant at [level] (according to [test]) for [horizons]." / "the forecasts of [A] are not significantly worse than those of [B]."
- No uniform winner: "[A] does not uniformly outperform [B] across all [conditions]." / "[A] more often outperforms [B] in [periods], whereas [B] ... in [periods]." / "In general, however, all [n] ... can meet [requirements], and each has merits."
- Cross-study: "This is in contrast to what [Author] concludes." / "This confirms the findings of [Author]." / "On the other hand, [Authors] reach opposite conclusions, at least for [condition]." / "However, only the results for [common sample] are comparable."
- Class versus class: "In contrast to [A], [B] [property]." / "[A] can be reproduced by [B] when [setting] [ref]." / "[A] are fully competitive with [B] in terms of [dimensions]." / "Similar to [X], [Y] ..."

## Limitation phrasing and placement
- Reviews: a limitation sentence closes nearly every category paragraph and follows every advantage; family-level limitations are collected once as a list ("The well-known disadvantages of [family] are: [list]") at the hinge to the next family; the review's own scope limits are stated once in the Introduction ("However, some references are included concerning [out-of-scope item]") or in a methodological decision ("For this reason, [descriptions] can only be [qualitative]").
- Articles: own limitations are single sentences inside results or discussion, attached to the claim they bound ("within [tolerance] above [threshold], for the data presented"; "might not be appropriate if [data property]"); a hypothesis is labelled as one; no separate limitations paragraph in any of the four articles.

## Conclusion shapes
- Review, five moves: "This paper has reviewed [topic]" plus positioning against the reference method -> bulleted feature summary "can be summarized as follows" -> taxonomy restated with past participles -> per-family application recommendation ("[Family] is preferred for [application] ... Therefore, it is well suited for [applications]. Instead, ...") -> one attributed outlook sentence.
- Review, recap plus lessons: importance-led opener -> scope recap -> branch-by-branch recap in taxonomy order with one judgment or forecast each -> numbered lessons by perspective with examples and back-references -> "In summary, there is no doubt that [X]. However, [long way to go]."
- Review, bullets: one scope sentence -> "The following aspects were highlighted:" -> one bullet per section.
- Review, minimal: two sentences of hope addressed to the community; or three long sentences generalizing to designer practice and a collaboration call; no recap.
- Article: aim restated in present perfect -> hedged headline finding -> practical implication -> per-condition findings each with a hedged mechanism and a suggestion -> recommendation ("we strongly suggest") -> closing methodological note or numbered future-work sentences ("In future work, ... First, ... Second, ..."). One article restates findings per parameter in section order with no limitations and no future work.

## Generic connective phrases (max eight words each)
- "To the best of our knowledge,"
- "As stated earlier,"
- "As mentioned in Section [n],"
- "as will be discussed later"
- "In general, however,"
- "By way of example,"
- "In this regard,"
- "In this respect,"
- "In this context,"
- "With that in mind,"
- "On the other hand,"
- "The reason is that"
- "This is due to the fact that"
- "A plausible explanation may be that"
- "Having discussed [X], we now"
- "In the following, [X] are briefly explained"
- "The purpose of this paper is to"
- "as illustrated in Fig. [n]"
- "It follows from (n) that"
- "Several observations can be made:"
- "To summarize," / "In brief," / "Summing up,"
- "provided that [condition]"
- "irrespective of whether [condition]"
- "at least in the context of"
- "it remains an open question whether"
- "A complete solution along this line is desired"

## Do not imitate
- Domain facts, numbers, results, prototype or dataset specifics, citations, and any sentence longer than eight words from any paper.
- Phrases the corpus uses that the knowledge files ban or audit: "It is worth noting that", "It should be noted that", "It can be seen that", "It is obvious that", "It is well known that", "Note that" as a paragraph opener, "In this paper, we" outside the contribution statement, "With the rapid development of", "more and more", "firstly / secondly", "obviously / clearly" as evidence substitutes. Use the number, the figure, or the reference instead.

## Operational rules for writing-skill
1. Default register for machine-drive and materials manuscripts: impersonal, "this article" (register the choice in the terminology registry), passive for reporting and citing ("is presented in [n]"), active with inanimate subjects for mechanisms and callouts; "we" only inside derivations. Switch to the "we" register only when the brief asks or the target venue is a forecasting or economics journal.
2. Open results paragraphs with the callout and the condition; open category paragraphs with the definition or positioning sentence; open literature paragraphs with the family label and the cluster; never open with an attention marker or a "however".
3. Pair every advantage with its limitation in review prose, once, and close each category paragraph with the judgment turn; keep the field judgments flat and the manuscript's own picks hedged once.
4. Attach a condition to every number and an attribution to every cited number; state trade-offs rather than winners unless the conditions are matched or a significance test backs the claim.
5. Prefer content-linked paragraph openers (the topic noun) over connective-linked ones; keep "However" for genuine contrast; replace "Therefore/Thus/Hence" chains with one implication sentence per paragraph.
6. Contributions in a review are one task-worded prose sentence with section pointers; in an empirical article a numbered list of results or questions; conclusions restate in present perfect and recap in taxonomy order.
7. Where this profile and `knowledge/prose_quality.md` or `knowledge/ieee_editorial_conventions.md` disagree (certainty adverbs, attention-marker openers, ordinal adverbs, dash use), the knowledge files win.
